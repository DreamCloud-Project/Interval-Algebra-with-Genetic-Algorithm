#ifndef IA_TREE_H
#define IA_TREE_H

#include <vector>
#include <map>
#include "JobTreeNode.h"

namespace IntervalAlgebra
{
	using namespace std;
	extern map<IAResource*,Time*> mapCoreTime;


class TreeNode
   {
   public:
	   TreeNode();
		~TreeNode();
		JobTreeNode* t;
		vector<TreeNode*> children;
		void AddChildren(TreeNode *tn);
		void AddChildrenToEachParent(TreeNode *tn, int Iteration);
		Job* FindTheEarliestReadyJob(TreeNode* RootTreeNode,Job* JobIn=NULL,int iteration=-1);
		Job* FindTheEarliestReadyJobForCore(TreeNode* RootTreeNode,Job* JobIn=NULL,IAResource *CoreIn=NULL,int iteration=-1);
		Job* FindTheEarliestReadyJobButNotOriginatedFrom(TreeNode* RootTreeNode,string OriginalIDOfthePreviousJobID,Job* JobIn=NULL,int iteration=-1);
		Job* FindTheEarliestReadyJobButNotOriginatedFromForCore(TreeNode* RootTreeNode,string OriginalIDOfthePreviousJobID,Job* JobIn=NULL,IAResource *CoreIn=NULL,int iteration=-1);
		Job* FindTheEarliestReadyJobOfTheHighestPriority(TreeNode* RootTreeNode,Time *CurrentTime, Job* JobIn=NULL, unsigned int HighestPriority=0,int iteration=-1);
		Job* FindTheEarliestReadyJobOfTheHighestPriorityForCore(TreeNode* RootTreeNode,Time *CurrentTime, Job* JobIn, unsigned int HighestPriority,IAResource* CoreIn=NULL,int iteration=-1);
		Job* FindTheEarliestReadyJobOfTheHighestPriorityAndPriorityHigherThan(TreeNode* RootTreeNode,Job* ReferenceJob,Job* JobIn=NULL, unsigned int HighestPriority=0,int iteration=-1);
		Job* FindTheEarliestReadyJobOfTheHighestPriorityAndPriorityHigherThanForCore(TreeNode* RootTreeNode,Job* ReferenceJob,IAResource* CoreIn=NULL,Job* JobIn=NULL, unsigned int HighestPriority=0,int iteration=-1);
		Job* FindJobExecutedByCoreAtTime(TreeNode* RootTreeNode,Job* ReferenceJob,IAResource *CoreIn,Time* TimeIn,int iteration=-1);

		int VisitedAtIteration;

		void RemoveFromThisNode();
		Time* GetTheLatestEndTimeOfChildren(TreeNode* RootTreeNode,Job* JobIn);
		TreeNode* FindNodeWithJob(Job* JobIn);
		TreeNode* FindNodeWithJobFromRoot(TreeNode* RootTreeNode,Job* JobIn);
		Time* FindTheLatestEndTimeOfChildren();
		Time* FindTheEarliestNonAllocatedTime(IAResource *CoreIn=NULL);
		Time* DetermineStartTime(Job* JobIn);
		Time* DetermineTheLatestEndTimeOfChildren(TreeNode* RootTreeNode,Job* JobIn);
		Time* GetReadyTime(TreeNode* RootTreeNode,Job* JobIn);
		void CopyChildrenFrom(TreeNode* NewChildTreeNode);
		void ClearChildren();
		Time* DetermineTheEarliestNonAllocatedTimeForCore(TreeNode* RootTreeNode,IAResource *CoreIn);
		Time* DetermineTheEarliestNonAllocatedTimeForExecutingCores(TreeNode* RootTreeNode,Job* JobIn);
		Time* DetermineTheEarliestNonAllocatedTimeForExecutingCores(Job* JobIn);
   };

	extern map<Job*,TreeNode*> mapJob_TreeNode;
	extern multimap<Job*,TreeNode*> multimapJob_ParentTreeNode;

}

#endif // IA_TREE_H