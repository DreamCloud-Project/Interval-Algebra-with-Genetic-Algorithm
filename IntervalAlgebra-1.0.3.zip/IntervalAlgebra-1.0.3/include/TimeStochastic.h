#ifndef IA_TIMESTOCHASTIC_H
#define IA_TIMESTOCHASTIC_H

#include "Types.h"
#include "IATime.h"
#include "TimeDeterministic.h"
#include "Pdf.h"
#include <iostream>

using namespace std;

namespace IntervalAlgebra
{
   using namespace std;

	class TimeStochastic : public Time {
		Pdf *Value;
	public:
		TimeStochastic(TimeUnit UnitIn=ms);
		~TimeStochastic();


		ostream& DoPrint(std::ostream& os) const {
			os << *Value << ' ';
			switch (Unit) {
			case fs:
				os << "fs" ;
				break;
			case ps:
				os << "ps" ;
				break;
			case ns:
				os << "ns" ;
				break;
			case us:
				os << "us" ;
				break;
			case ms:
				os << "ms" ;
				break;
			case s:
				os << "s" ;
				break;
			default:
				break;
			}
			return os;

		}

		const bool operator == (Time &t);

		const bool operator < (Time &t);
		
		const bool operator <= (Time &t);

		const bool operator > (Time &t);


		TimeUnit GetUnit() {
			return Unit;
		}


		long long GetValue() {
			return Value->GetXAboveThreshold();
		}

		long long GetValueInUnit(TimeUnit TimeUnitIn);


		virtual bool IsStochastic() {
			return true;
		}

		void CreateExpDistribution(int Xmin,int Xmax,double Lambda);
		void CreateUniformDistribution(int Xmin,int Xmax);
		void CreateWeibullDistribution(int Xmin,int Xmax,double Remain);
		void CreateWeibullDistribution(int Xmin,int Xmax,double Shape, double Scale);
		void CreateNormalDistribution(int Xmin,int Xmax,double Mean,double Variance);


		void SetThreshold(double ThresholdIn);
		double GetThreshold();
		void Convolute(TimeStochastic *Time1, TimeStochastic *Time2);
		Pdf* GetPdf();
		TimeStochastic* Add(TimeStochastic &t1);
		void AddConstantTime(TimeStochastic *t1,TimeDeterministic *t2);
		void SubConstantTime(TimeStochastic *t1,TimeDeterministic *t2);
		void ConvertTo(TimeUnit TimeUnitIn);
		virtual long long GetWorstCaseValue();
		virtual long long GetBestCaseValue();
		virtual long long GetWorstCaseValueInUnit(TimeUnit TimeUnitIn);
		virtual long long GetBestCaseValueInUnit(TimeUnit TimeUnitIn);
		virtual void MultipleValueByConst(double ConstIn);

		Time* Clone();

		friend TimeStochastic* Add(TimeStochastic &t1,TimeStochastic &t2);
		friend TimeStochastic* Shift(TimeStochastic &t1,TimeDeterministic &t2);


	};


}

#endif
