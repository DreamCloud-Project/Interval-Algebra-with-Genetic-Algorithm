#ifndef IA_TIMEDETERMINISTIC_H
#define IA_TIMEDETERMINISTIC_H

#include "Types.h"
#include "IATime.h"
#include <iostream>
using namespace std;

namespace IntervalAlgebra
{
   using namespace std;

	class TimeDeterministic : public Time {
		long long Value;
	public:
		TimeDeterministic(long long ValueIn,TimeUnit UnitIn=ms);
		~TimeDeterministic();


		ostream& DoPrint(std::ostream& os) const {
			os <<  Value << ' ';
			switch (Unit) {
			case fs:
				os << "fs" ;
				break;
			case ps:
				os << "ps" ;
				break;
			case ns:
				os << "ns" ;
				break;
			case us:
				os << "us" ;
				break;
			case ms:
				os << "ms" ;
				break;
			case s:
				os << "s" ;
				break;
			default:
				break;
			}
			return os;

		}

		void ConvertTo(TimeUnit TimeUnitIn);

		const bool operator == (Time &t) {
			bool result;
			result=!(*this<t ||*this>t);
			return result;
		}



		const bool operator > (Time &t);
		const bool operator <= (Time &t);
		const bool operator < (Time &t);



		TimeUnit GetUnit() {
			return Unit;
		}


		long long GetValue() {
			return Value;
		}

		long long GetValueInUnit(TimeUnit TimeUnitIn);

		virtual bool IsStochastic() {
			return false;
		}

		virtual long long GetWorstCaseValue();
		virtual long long GetBestCaseValue();
		virtual long long GetWorstCaseValueInUnit(TimeUnit TimeUnitIn);
		virtual long long GetBestCaseValueInUnit(TimeUnit TimeUnitIn);
		virtual void MultipleValueByConst(double ConstIn);

		Time* Clone();

		friend TimeDeterministic* Add(TimeDeterministic &t1,TimeDeterministic &t2);

	};


}

#endif // IA_TIMEDETERMINISTIC_H
