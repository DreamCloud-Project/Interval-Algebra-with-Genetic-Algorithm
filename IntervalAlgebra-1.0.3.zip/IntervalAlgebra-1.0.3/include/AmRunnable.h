#ifndef IA_RUNNABLE_H
#define IA_RUNNABLE_H

#include <iostream>
#include <string>
#include <vector>
#include "AmInstruction.h"


namespace IntervalAlgebra
{
   using namespace std;

	class Runnable {
		string Name;
		string Tags;
		string ID;
		vector<Instruction*> Instructions;
		int Size;
	public:
		Runnable(string NameIn);
		~Runnable();
		void SetName(string NameIn);
		string GetName();
		void SetTags(string TagsIn);
		string GetTags();
		int GetSize();
		void SetSize(int SizeIn);
		void AddInstruction(Instruction *InstructionIn);
		void Print();
		void SetID(string IDIn);
		string GetID();
		int GetWCETInTick();
		int GetBCETInTick();

		bool CheckIfIncludesExecutionCyclesDeviationInstruction();
		string GetTheFirstDeviationType();
		double GetTheFirstDeviationRemainPromille();
		double GetTheFirstDeviationStandardDeviation();
		int GetTheFirstDeviationLowerBound();
		int GetTheFirstDeviationUpperBound();
		int GetTheFirstDeviationMean();
		int GetNoOfInstructions();
		string GetNameOfInstruction(int Index);
		string GetLabelNameOfLabelAccessInstruction(int Index);
		bool CheckIfWriteAccessInstruction(int Index);
	}; 


}

#endif // IA_RUNNABLE_H