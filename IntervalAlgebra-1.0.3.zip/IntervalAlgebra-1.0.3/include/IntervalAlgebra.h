// IntervalAlgebra.h

#ifndef IA_INTERVALALGEBRA_H
#define IA_INTERVALALGEBRA_H
#include <vector>
#include <list>
#include <map>
#include "Types.h"
#include "Job.h"
#include "Scheduler.h"

#pragma once

    #pragma warning (disable : 4251)

#ifdef COMPILE_MYLIBRARY
	#define MYLIBRARY_EXPORT __declspec(dllexport)
#else
	#define MYLIBRARY_EXPORT __declspec(dllimport)
#endif



#include <string>

	using namespace std;
	using namespace IntervalAlgebra;

   class JobStruct{
   public:
	   int TID;
	   string TaskName;
	   pair<int,string> SubmissionTime;
	   pair<int,string> ExecutionTime;
	   pair<int,string> Deadline;
	   list<int> ChildrenTids;

   };


   	class TestUnit {
	private:
		static double ComputeTotalUtilisation(IAResource *CoreIn);
		static bool IsLHSCoreUtilizationLowerThanRHSCore(IAResource* lhs, IAResource* rhs);
		static vector<Job*>* AllJobs;
		static double ComputeSigma(vector<Job*> *AllJobs,IAResource* CoreIn);
		static int selectProcessorsForNextCluster(vector<Job*> *AllJobs,vector<IAResource*> *AllCores, int q,int i,int m);
		static int SplitTask(vector<Job*> *AllJobs,vector<IAResource*> *AllCores, int j, int q, int k_prim,int m,TimeUnit MyUnit);

		map<string,Job*> CTJobMap;
		map<string,IAResource*> CTJobCoreMap;
		vector<IAResource*> CTCores;
		Scheduler *CTSchedulerFIFO;

		list<string> CTTransactionTasks;
		bool CTTransactionMode;

	public:
		TestUnit();
		pair<double,double> TestAmalthea(vector<int> &CoreAssignment, int nNoOfCores = 1);
		double TestAmaltheaPriorities(vector<int> &TaskPriorities);
		pair<double,double> TestAmaltheaNoC(vector<int> &CoreAssignment,vector<int> &LabelAssignment,int XSize, int YSize, int IdleCores=0, vector<int> *PModeAssignment=NULL);
		pair<double,double> TestAmaltheaTriCore(vector<int> &CoreAssignment,vector<int> &LabelAssignment, int NoOfCores, int NoOfMemories, vector<int> *PModeAssignment=NULL);
		pair<double,double> TestAmaltheaNoCNoLabelMapping(vector<int> &CoreAssignment,int NoCXSize, int NoCYSize, int IdleCores=0, vector<int> *PModeAssignment=NULL);
		pair<double,double> TestCoresBus(vector<int> &CoreAssignment, int CoresNo, vector<int> *PModeAssignment=NULL);
		pair<double,double> TestCoresBusPart2(vector<int> &CoreAssignment, int CoresNo, vector<int> *PModeAssignment=NULL);
		pair<double,double> TestCoresBusPart2Tasks(vector<int> &CoreAssignment, int CoresNo, vector<int> *PModeAssignment=NULL);

		double TestAmaltheaNoCPriorities(vector<int> &TaskPriorities,int NoCXSize, int NoCYSize);
		double TestPeriodicAmalthea(vector<int> &CoreAssignment);
		double TestSemiPartitioning();
		double TestSemiPartitioningAmalthea(vector<int> *CoreAssignment,bool ReturnSize=false);
		double TestPeriodicTDMAmalthea(vector<int> &CoreAssignment);
		void ParseAmalthea(string &FileName);
		double TestStochasticAmalthea(vector<int> &CoreAssignment);
		void FillJobStructure(list<JobStruct> &JobStructIn);


		void CTBeginTransaction();
		void CTCommitTransaction();
		void CTRollbackTransaction();
		
		Time* CTCreateTimeDeterministic(long long,TimeUnit);
		void CTCreateJob(string *NameIn);
		void CTRemoveJob(string *NameIn);
		void CTUpdateExecutionTime(string *NameIn,int ValueIn);
		void CTUpdateReleaseTime(string *NameIn,int ValueIn);
		void CTSetExecutionTimeForExecutingResource(string *NameIn,long long MyTimeVal,TimeUnit MyTimeUnit);
		void CTSetReleaseTime(string *NameIn,long long MyTimeVal,TimeUnit MyTimeUnit);
		void CTSetDeadline(string *NameIn,long long MyTimeVal,TimeUnit MyTimeUnit);
		bool CTCheckSchedulabilityFIFO();
		void CTSetNoOfCores(int NoOfProcessorsIn);
		void CTRemoveCores();

		void CTAssignJobToCore(string *NameIn,int PUChosen);
		void CTRemoveJobFromCore(string *NameIn,int PUChosen);

		void CTInitCheckSchedulabilityIncrementalFIFO();
		bool CTCheckSchedulabilityIncrementalFIFO(string *NameIn);
		void CTRemoveCheckSchedulabilityIncrementalFIFO();
		bool CTTryAddParentJobName(string *NameIn,string *ParentJobName);


		bool RealTimeAnalysisAmalthea(vector<int> &CoreAssignment);
		int GetNoOfRunnables();
		int GetNoOfCores();
		int GetNoOfLabels();
		int GetNoOfTasks();
		int GetIndexOfRunnable(string NameIn);
		int GetIndexOfLabel(string NameIn);
	};

#endif // IA_INTERVALALGEBRA_H
