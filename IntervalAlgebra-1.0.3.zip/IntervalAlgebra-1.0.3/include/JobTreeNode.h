#ifndef IA_JOBTREENODE_H
#define IA_JOBTREENODE_H

#include "Job.h"
#include "TimeDeterministic.h"
#include "TimeStochastic.h"

namespace IntervalAlgebra
{

	class JobTreeNode {
		Job *Job1;
		

	public:
		~JobTreeNode();
		JobTreeNode(Job *JobIn);
		JobTreeNode();
		Job* GetJobA();
		void SetJobA(Job* JobIn);
		bool IsReady();
		bool IsScheduled();

	};

}

#endif // IA_JOBTREENODE_H