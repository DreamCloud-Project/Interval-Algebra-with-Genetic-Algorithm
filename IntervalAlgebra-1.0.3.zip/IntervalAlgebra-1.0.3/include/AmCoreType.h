#ifndef IA_CORETYPE_H
#define IA_CORETYPE_H

#include <iostream>
#include <list>



namespace IntervalAlgebra
{
   using namespace std;

	class CoreType {
		string Name;
		string ID;
		int InstructionsPerCycle;
	public:
		CoreType(string NameIn);
		~CoreType() {cout << "DestrCoreType" << endl;};
		void SetName(string NameIn);
		string GetName();
		void SetInstructionsPerCycle(int InstructionsPerCycleIn);
		int GetInstructionsPerCycle();
		void SetID(string IDIn);
		string GetID();
	}; 


}

#endif // IA_CORETYPE_H