#ifndef IA_AMTYPES_H
#define IA_AMTYPES_H



using namespace std;

namespace IntervalAlgebra
{

#define AmNoTime pair<int,string>(0,"")

}
#define DEBUG_NEW new(_NORMAL_BLOCK, THIS_FILE, __LINE__)
#endif // IA_AMTYPES_H