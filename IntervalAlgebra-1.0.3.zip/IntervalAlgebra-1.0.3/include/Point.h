#ifndef IA_POINT_H
#define IA_POINT_H

#include <iostream>
#include <list>


namespace IntervalAlgebra
{
   using namespace std;

	class Point {
		unsigned long long X;
		double Y;
	public:
		Point(unsigned long long XIn, double YIn);
		void SetX(unsigned long long XIn);
		void SetY(double YIn);
		unsigned long long GetX();
		double GetY();
		void Print();
		void DivideYBy(double Divisor);
		void AddToX(unsigned long long ConstantIn);

	}; 


}

#endif // IA_POINT_H		