#ifndef IA_AMALTHEASYSTEM_H
#define IA_AMALTHEASYSTEM_H

#include <iostream>
#include <vector>
#include <map>
#include "AmLabel.h"
#include "AmRunnable.h"
#include "AmTask.h"
#include "AmStimulus.h"
#include "AmQuartz.h"
#include "AmCoreType.h"
#include "AmCore.h"
#include "AmMicrocontroller.h"
#include "Job.h"

namespace IntervalAlgebra
{
   
using namespace std;


	class AmaltheaSystem {
	public:
		static AmaltheaSystem* instance();		//singleton

		AmaltheaSystem();
		~AmaltheaSystem();

		void AddLabel(Label* LabelIn);
		void AddLabel(Label* LabelIn, string IDIn);
		Label* GetLabel(int Index);
		int GetNoOfLabels();
		void PrintAllLabels();
		Label* GetLabel(string IDIn);
		Label* GetLabelByName(string NameIn);
		int GetIndexOfLabel(Label* LabelIn);


		void AddRunnable(Runnable *RunnableIn);
		void AddRunnable(Runnable* RunnableIn,string IDIn);
		Runnable* GetRunnable(int Index);
		Runnable* GetRunnableByID(string IDIn);
		Runnable* GetRunnableByName(string Name);
		int GetNoOfRunnables();
		int GetIndexOfRunnable(Runnable* RunnableIn);


		void AddStimulus(Stimulus *StimulusIn);
		void AddStimulus(Stimulus* StimulusIn,string IDIn);
		Stimulus* GetStimulus(int Index);
		Stimulus* GetStimulus(string IDIn);
		int GetNoOfStimuli();


		void AddTask(Task *TaskIn);
		Task* GetTask(int Index);
		int GetNoOfTasks();

		void AddCoreType(CoreType* CoreTypeIn, string IDIn);
		CoreType* GetCoreType(string IDIn);

		void AddQuartz(Quartz* QuartzIn, string IDIn);
		Quartz* GetQuartz(string IDIn);

		void AddAmCore(AmCore* CoreIn, string IDIn);
		AmCore* GetAmCore(string IDIn);
		AmCore* GetAmCore(int Index);
		int GetNoOfAmCores();


		void PrintAllTasks();
		void AddTaskDependencesFromStimuli();
		void AddJobToStimuliSourcesIfNecessary(Task* TaskIn,Job* JobIn) ;
		void AddJobToStimuliDestinationsIfNecessary(Task* TaskIn,Job* JobIn);
		void ClearJobs();
		Label* GetLabelWithIndex(int Index);
		void AddLabelsDest(Label* MyLabel, Runnable *Runnable);
		void AddLabelsSource(Label* MyLabel, Runnable *Runnable);
		Runnable* GetLabelsDest(Label* MyLabel);
		Runnable* GetLabelsSource(Label* MyLabel);
		pair<int,string> GetHyperPeriod();

	private:
		static AmaltheaSystem* pInstance;
		vector<Label*> Labels;
		vector<Runnable*> Runnables;
		vector<Stimulus*> Stimuli;
		map<string,Label*> LabelsMap;
		map<string,Label*> LabelsNameMap;
		map<Label*,Runnable*> LabelsSource;
		map<Label*,Runnable*> LabelsDest;
		map<string,Runnable*> RunnablesByIDMap;
		map<string,Runnable*> RunnablesByNameMap;
		map<string,Stimulus*> StimuliMap;
		vector<Task*> Tasks;
		map<string,CoreType*> CoreTypesMap;
		map<string,Quartz*> QuartzsMap;
		map<string,AmCore*> CoresMap;
		vector<AmCore*> Cores;

		string GetLowerAmUnit(string Unit1,string Unit2);
		string GetLowestUnitAmTime(vector<pair<int,string> >* AmTimeIn);
		void ConvertAmTimeVectorToUnit(vector<pair<int,string> >* AmTimeVector,string Unit);
		void ConvertAmTimeToUnit(pair<int,string> *AmTimeIn,string DestUnit);
		static int ComputeGreatestDommonDivisor(int a, int b);
		static int ComputeLeastCommonMultiple(int a, int b);
		static int GetFirstElement( const std::pair<int, string> &p );

	}; 


}

#endif // IA_AMALTHEASYSTEM_H