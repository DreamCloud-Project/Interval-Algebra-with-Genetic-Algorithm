#ifndef IA_SCHEDULERTDM_H
#define IA_SCHEDULERTDM_H

#include <string>
#include <list>

#include "IATime.h"
#include "Job.h"
#include "JobTree.h"
#include "Scheduler.h"

namespace IntervalAlgebra
{
   using namespace std;

	class SchedulerTDM : public Scheduler {

	public:
		SchedulerTDM(Time *QuantumIn);

		void Schedule();
		Time *Quantum;
		Time* GetQuantum();


	}; 


}

#endif // IA_SCHEDULERTDM_H
