#ifndef IA_SCHEDULERPRIORITYNONPREEMPTIVE_H
#define IA_SCHEDULERPRIORITYNONPREEMPTIVE_H

#include <string>
#include <list>

#include "Job.h"
#include "JobTree.h"
#include "Scheduler.h"


namespace IntervalAlgebra
{
   using namespace std;

	class SchedulerPriorityNonPreemptive : public Scheduler {
	private:
		vector<Time*> CurrentTime;

	public:
		SchedulerPriorityNonPreemptive();
		void Schedule();
	}; 


}

#endif // IA_SCHEDULERPRIORITYNONPREEMPTIVE_H