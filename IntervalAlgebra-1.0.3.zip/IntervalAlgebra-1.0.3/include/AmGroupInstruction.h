#ifndef IA_GROUPINSTRUCTION_H
#define IA_GROUPINSTRUCTION_H

#include <iostream>
#include <list>
#include "AmInstruction.h"

namespace IntervalAlgebra
{
   using namespace std;

	class GroupInstruction : public Instruction {
		string Name;
	public:
		GroupInstruction(string NameIn);




	}; 


}

#endif // IA_GROUPINSTRUCTION_H