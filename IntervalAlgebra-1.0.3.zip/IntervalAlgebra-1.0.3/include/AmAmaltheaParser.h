#ifndef XML_PARSER_HPP
#define XML_PARSER_HPP
/**
 *  @file
 *  Class "AmaltheaParser" provides the functions to read the XML data.
 *  @version 1.0
 */

#include <xercesc/dom/DOM.hpp>
#include <xercesc/dom/DOMDocument.hpp>
#include <xercesc/dom/DOMDocumentType.hpp>
#include <xercesc/dom/DOMElement.hpp>
#include <xercesc/dom/DOMImplementation.hpp>
#include <xercesc/dom/DOMImplementationLS.hpp>
#include <xercesc/dom/DOMNodeIterator.hpp>
#include <xercesc/dom/DOMNodeList.hpp>
#include <xercesc/dom/DOMText.hpp>

#include <xercesc/parsers/XercesDOMParser.hpp>
#include <xercesc/util/XMLUni.hpp>

#include <string>
#include <stdexcept>
#include "AmLabel.h" 
#include "AmRunnable.h"
#include "AmRemoteAccessInstruction.h"
#include "AmExecutionCyclesConstantInstruction.h"
#include "AmExecutionCyclesDeviationInstruction.h"
#include "AmGroupInstruction.h"
#include "AmTask.h"
#include "AmStimulus.h"
#include "AmCoreType.h"
#include "AmCore.h"
#include "AmMicrocontroller.h"
#include "AmQuartz.h"



#include "AmAmaltheaSystem.h"

// Error codes

enum {
   ERROR_ARGS = 1, 
   ERROR_XERCES_INIT,
   ERROR_PARSE,
   ERROR_EMPTY_DOCUMENT
};

using namespace IntervalAlgebra;
using namespace std;
using namespace xercesc;


class AmaltheaParser
{
public:
	AmaltheaParser();
	~AmaltheaParser();
	void ParseAmaltheaFile(string& FileName,AmaltheaSystem* MySystem);
	string GetAttributeAsString(DOMElement* MyElement,XMLCh* MyAttr);
	void ParseAmaltheaFileLabels(DOMNodeList* const children, AmaltheaSystem* MyAmaltheaSystem);
	void ParseAmaltheaFileStimuli(DOMNodeList* const children , AmaltheaSystem* MyAmaltheaSystem);
	void ParseAmaltheaFileRunnable(DOMNodeList* const children , AmaltheaSystem* MyAmaltheaSystem);
	void ParseAmaltheaFileTasks(DOMNodeList* const children , AmaltheaSystem* MyAmaltheaSystem);
	void ParseAmaltheaFileHWModel(DOMNodeList* const children , AmaltheaSystem* MyAmaltheaSystem);
	int ParseAmaltheaFileHWModelForCoresNo(DOMNodeList* const children , AmaltheaSystem* MyAmaltheaSystem);
	int	ParseAmaltheaFileRunnableForNo(DOMNodeList* const children , AmaltheaSystem* MyAmaltheaSystem);

	void FillExecutionCyclesDeviationInstruction(DOMElement* currentElementLev2, ExecutionCyclesDeviationInstruction *MyExecutionCyclesDeviationInstruction);
	void FillRemoteAccessInstruction(DOMElement* currentElementLev2,RemoteAccessInstruction *MyRemoteAccessInstruction,AmaltheaSystem *MyAmaltheaSystem,Runnable *MyRunnable);
	void FillExecutionCyclesConstantInstruction(DOMElement* currentElementLev2,ExecutionCyclesConstantInstruction *MyExecutionCyclesConstantInstruction);
	void AnalyseGroup(DOMElement* currentElementLev2,AmaltheaSystem *MyAmaltheaSystem,Runnable *MyRunnable);

	DOMNodeList* GetElementWithTagswModel(DOMNode* root);
	DOMNodeList* GetElementWithTaghwModel(DOMNode* root);
	DOMNodeList* GetElementWithTagStimuliModel(DOMNode* root);
 

private:
   xercesc::XercesDOMParser *m_Parser;

   // Internal class use only. Hold Xerces data in UTF-16 SMLCh type.

	XMLCh* TAG_root;

	XMLCh* TAG_labels;
	XMLCh* TAG_runnables;
	XMLCh* TAG_remoteAccesses;
	XMLCh* TAG_deviation;
	XMLCh* TAG_lowerBound;
	XMLCh* TAG_upperBound;
	XMLCh* TAG_distribution;
	XMLCh* TAG_mean;
	XMLCh* TAG_sd;

	XMLCh* TAG_tasks;
	XMLCh* TAG_deadline;
	XMLCh* TAG_callGraph;
	XMLCh* TAG_graphEntries;
	XMLCh* TAG_calls;
	XMLCh* TAG_swModel;
	XMLCh* TAG_runnableItems;

	XMLCh* TAG_size;
	XMLCh* TAG_items;
	XMLCh* TAG_runnableItem;


	XMLCh* TAG_stimuliModel;
	XMLCh* TAG_stimuli;
	XMLCh* TAG_offset;
	XMLCh* TAG_recurrence;
	XMLCh* TAG_hwModel;
	XMLCh* TAG_coreTypes;
	XMLCh* TAG_system;
	XMLCh* TAG_ecus;
	XMLCh* TAG_quartzes;
	XMLCh* TAG_microcontrollers;
	XMLCh* TAG_cores;
	XMLCh* TAG_prescaler;
	XMLCh* TAG_stimuli_stimuliModel;
	XMLCh* TAG_hw_hwModel;
	XMLCh* TAG_sw_swModel;
	XMLCh* TAG_stimulus;


	XMLCh* ATTR_name;
	XMLCh* ATTR_xsi_type;
	XMLCh* ATTR_data;
	XMLCh* ATTR_value;
	XMLCh* ATTR_pRemainPromille;
	XMLCh* ATTR_tags;
	XMLCh* ATTR_numberBits;
	XMLCh* ATTR_access;

	XMLCh* ATTR_priority;
	XMLCh* ATTR_multipleTaskActivationLimit;
	XMLCh* ATTR_unit;
	XMLCh* ATTR_runnable;
	XMLCh* ATTR_preemption;
	XMLCh* ATTR_xmi_id;
	XMLCh* ATTR_stimuli;
	XMLCh* ATTR_instructionsPerCycle;
	XMLCh* ATTR_frequency;
	XMLCh* ATTR_coreType;
	XMLCh* ATTR_quartz;
	XMLCh* ATTR_stimulus;
	XMLCh* ATTR_href;

};
#endif