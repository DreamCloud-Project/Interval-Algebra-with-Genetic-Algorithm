#ifndef IA_JOB_H
#define IA_JOB_H

#pragma warning (disable:4786)
#include<list>
#include<utility>
#include<iostream>
#include<string>
#include<vector>
#include<algorithm>
#include "TimeDeterministic.h"
#include "TimeStochastic.h"
#include "IAResource.h"


namespace IntervalAlgebra
{
	using namespace std;



	class Job {
		string ID;
		string OriginalID;
		Time *ReleaseTime;
		Time *Period;
		Time *Deadline;
		list<Job*> *DependentOn;
		Time *StartTime;
		Time *EndTime;
		bool Ready;
		bool Scheduled;
		int Slice;
		list<IAResource*> ExecutingCore;
		list<int> PMode;


		unsigned int Priority;
		list<pair<IAResource*, Time*> > AllowedResourcesExecutionTime; //resource type, execution time
		int DependencyLevel;
	


		void SetStartTime(Time *t);
		void SetEndTime(Time *t);


	public:
		list<Job*> SynchrNoC;


		Job(string ID);
		Job(string ID, Time *ExecutionTime);
		Job(const Job &JobIn);

		~Job();
		list<Job*>* GetDependentOn() {return DependentOn;}
		void SetPeriod(Time* t);
		Time* GetPeriod();
		void SetDependenciesFrom(Job* JobIn);
		void SetAllowedResourcesExecutionTimeFrom(Job const &JobIn);
		string GetOriginalName();
		void SetOriginalName(string NameIn);
		string GetName();
		void SetName(string NameIn);
		void SetReady(bool ReadyIn);
		void SetDependencyLevel(int Level);
		int GetDependencyLevel();
		bool DependsDirectlyOn(Job*);
		static bool IsLHSUtilizationHigherThanRHS(Job* lhs, Job* rhs);
		double ComputeUtilisation();
		bool IsReady();
		bool GetReadyWithoutComputingIt();
		bool IsScheduled();
		void SetScheduled(bool ScheduledIn);
		Time* GetReleaseTime();
		void SetReleaseTime(Time* t);
		void SetStartAndEndTime(Time *t);
		void ClearStartAndEndTime();
		Time* GetStartTime();
		Time* GetEndTime();
		Time* GetExecutionTime(IAResource* rt);
		Time* GetExecutionTimeForExecutingResource();
		Time* GetExecutionTimeForTheSlowestResource();
		Time* GetExecutionTimeForTheFastestResource();
		double GetDynamicEnergyForResource(IAResource *CoreIn,TimeUnit MyTimeUnit=ms);
		double GetDynamicEnergyForExecutingResourcesAndAllocatedTasks(TimeUnit MyTimeUnit=ms);

		void AddToReleaseTime(Time* TimeIn);
		void AddToDeadline(Time* TimeIn);
		void AddDependency(Job *JobIn);
		bool IsPeriodic();
		int GetDependentOnListSize();
		Job* GetDependentOnListElement(int NoElement);
		void SetDependentOnListElement(int i,Job *JobIn);
		Job* ExtractPrefix(Time* Length,IAResource* rt);
		void RemovePrefix(Time* Length,IAResource* rt);
		void SetNoOfSlice(int SliceIn);
		int GetNoOfSlice();
		void SetExecutionTimeForResource(Time* Length,IAResource* rt);
		void SetExecutionTimeForExecutingResource(Time* Length);
		void DecreaseExecutionTimeForResourceBy(Time* Length,IAResource* rt);
		void RemoveExecutionTimeForResource(IAResource* rt);
		unsigned int GetPriority();
		void SetPriority(unsigned int PriorityIn);
		void AddDependencySet(list<Job*> *DepJobs);
		void RemoveTimes();
		Time* GetDeadline();
		void SetDeadline(Time* TimeIn);
		void Display();
		void SetStartAndEndTimeForCollapse(Time *tStart, Time *tEnd);
		bool IsPeriodicOrSporadic();
		bool IsStartingJob();
		bool IsEndingJob();
		void AddExecutingCore(IAResource *CoreIn);
		IAResource* GetTheFirstExecutingCore();
		bool CheckIfExecutedByCore(IAResource *CoreIn);
		void SetExecutingCores(list<IAResource*>* CoresListIn);
		list<IAResource*>* GetExecutingCores();
		list<int>* GetExecutingCoresPModes();
		void ClearDependencies();
		bool IsDependentOn(Job* JobIn);
		bool CheckIfDeadlineMet();
		Time* GetLaxity();
		void OverwriteTheFirstExecutingCore(IAResource* CoreIn);
		bool CheckIfReadyAndThenSetReady();
		void RemoveExecutingCores(IAResource* CoreIn);
		void ExchangeDependentOnListElement(Job* JobFrom, Job* JobTo);
		int GetPModeOfResource(IAResource* CoreIn);
		void SetPModeOfResource(IAResource* CoreIn,int PModeIn);
		void SetPModeOfExecutingResources();


	};


}

#endif // IA_JOB_H
