#ifndef IA_RESOURCE_H
#define IA_RESOURCE_H

#include <iostream>
#include <list>
#include "Types.h"
#include "IAResourceType.h"


namespace IntervalAlgebra
{
   using namespace std;

	class IAResource {
		string Name_;
		IAResourceType *ResourceType_;
		int CurrentPMode_;
		int NoOfPModeChanges_;
		pair<double,TimeUnit> StaticEnergyPerTimeUnit_;
		bool IsIdle_;

	public:
		IAResource(string NameIn);
		~IAResource();
		void SetName(string NameIn);
		string GetName();
		void SetResourceType(IAResourceType *ResourceTypeIn);
		void SetResourceType(string ResourceTypeNameIn);
		IAResourceType* GetResourceType();
		void SetDynamicEnergyMultiplierPerClockCycle(double EnergyMultiplierIn);
		double GetDynamicEnergyMultiplierPerClockCycle();
		double GetDynamicEnergyMultiplierPerTimeUnit(TimeUnit UnitIn);
		int GetCurrentPMode();
		void SetCurrentPMode(int PModeIn);
		void SetNoOfPModeChanges(int NoOfPModeChangesIn);
		int GetNoOfPModeChanges();
		double GetStaticEnergyPerTimeUnit(TimeUnit UnitIn);
		void SetStaticEnergyPerTimeUnit(double ValueIn, TimeUnit UnitIn);
		void SetIsIdle(bool IsIdleIn);
		bool GetIsIdle();

	}; 


}


#endif // IA_RESOURCE_H