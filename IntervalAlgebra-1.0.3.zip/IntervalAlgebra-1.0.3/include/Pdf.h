#ifndef IA_PDF_H
#define IA_PDF_H

#include <vector>
#include <iomanip>
#include "Point.h"


namespace IntervalAlgebra
{

	using namespace std;

	class Pdf {
		vector<Point*> Points;
		double Threshold;

		ostream& DoPrint(std::ostream& os) {
			for (std::vector<Point*>::iterator it = Points.begin() ; it != Points.end(); ++it) {
				if(it != Points.begin()) {
					os << "; ";
				}
				os <<  (*it)->GetX() << "  " << setprecision(10) << (*it)->GetY();
			}			
			return os;
		}


	public:
		Pdf();
		~Pdf();
		void CreateExpDistribution(int Xmin,int Xmax,double Lambda);
		void CreateUniformDistribution(int Xmin,int Xmax);
		void CreateWeibullDistribution(int Xmin,int Xmax,double Remain);
		void CreateWeibullDistribution(int Xmin,int Xmax,double Shape, double Scale);
		void CreateNormalDistribution(int Xmin,int Xmax,double Mean,double Variance);
		void AddPoint(Point* PointIn);
		double ComputeGamma(int X,double Lambda);
		double ComputeWeibull(double X,double Shape,double Scale);
		double ComputeNormal(int X,double Mean, double Variance);
		void Print();
		void Convolute(Pdf *Pdf1, Pdf *Pdf2);
		int GetMinX();
		int GetMaxX();
		int GetLength();
		double GetValueNo(int ElementNo);
		double GetValueOfX(int XIn);
		void ClearPdf();
		double GetSumOfAllValues();
		void Normalize();
		void SetThreshold(double ThresholdIn);
		double GetThreshold();
		int GetXAboveThreshold();
		void AddConstant(Pdf* PdfIn,unsigned long long ConstantIn);
		int GetPointsSize();
		Point* GetElement(int NoElement);



		friend ostream& operator<<(ostream& os, Pdf& dt) {
			return dt.DoPrint(os);
		}



	}; 


}

#endif // IA_PDF_H		
