#ifndef IA_AMCORE_H
#define IA_AMCORE_H

#include <iostream>
#include <list>
#include "AmCoreType.h"
#include "AmQuartz.h"

namespace IntervalAlgebra
{
   using namespace std;

	class AmCore {
		string Name;
		string ID;
		CoreType* CoreType_;
		Quartz *Quartz_;
	public:
		AmCore(string NameIn);
		void SetName(string NameIn);
		string GetName();
		void SetCoreType(CoreType* CoreTypeIn);
		CoreType* GetCoreType();
		void SetID(string IDIn);
		string GetID();
		void SetQuartz(Quartz* QuartzIn);
		Quartz* GetQuartz();
		
	}; 
}



#endif // IA_AMCORE_H