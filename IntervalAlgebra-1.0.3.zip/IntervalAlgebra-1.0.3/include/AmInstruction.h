#ifndef IA_INSTRUCTION_H
#define IA_INSTRUCTION_H

#include <iostream>
#include <string>
#include <list>

namespace IntervalAlgebra
{
   using namespace std;

	class Instruction {
		string Name;
	public:
		Instruction(string NameIn);
		virtual ~Instruction() {}
		void SetName(string NameIn);
		string GetName();
		virtual void Print();
	}; 


}

#endif // IA_INSTRUCTION_H