#ifndef IA_MICROCONTROLLER_H
#define IA_MICROCONTROLLER_H

#include <iostream>
#include <list>


namespace IntervalAlgebra
{
   using namespace std;

	class MicroController {
		string Name;
		string ID;
		int Size;
	public:
		MicroController(string NameIn);
		void SetName(string NameIn);
		string GetName();
		void SetSize(int SizeIn);
		int GetSize();
		void SetID(string IDIn);
		string GetID();
	}; 


}

#endif // IA_MICROCONTROLLER_H