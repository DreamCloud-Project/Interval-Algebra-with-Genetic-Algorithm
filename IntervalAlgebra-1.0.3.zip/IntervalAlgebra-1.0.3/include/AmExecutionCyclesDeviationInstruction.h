#ifndef IA_EXECUTIONCYCLESDEVIATIONINSTRUCTION_H
#define IA_EXECUTIONCYCLESDEVIATIONINSTRUCTION_H

#include <iostream>
#include <list>
#include "AmInstruction.h"

namespace IntervalAlgebra
{
   using namespace std;

	class ExecutionCyclesDeviationInstruction : public Instruction {
        double LowerBound;
        double UpperBound;
        string Type;
		double RemainPromille;
		double Mean;
		double SD;

		bool LowerBoundValid;
        bool UpperBoundValid;
		bool RemainPromilleValid;
		bool MeanValid;
		bool SDValid;


	public:
		ExecutionCyclesDeviationInstruction(string NameIn);

		double GetLowerBound();
        double GetUpperBound();
        string GetType();
		double GetRemainPromille();
		double GetMean();
		double GetSD();

		void SetLowerBound(double);
		void SetUpperBound(double);
		void SetType(string);
		void SetRemainPromille(double);
		void SetMean(double);
		void SetSD(double);

		bool GetLowerBoundValid(); 
		bool GetUpperBoundValid();
		bool GetRemainPromilleValid(); 
		bool GetMeanValid();
		bool GetSDValid();

		void Print();


	}; 


}

#endif // IA_EXECUTIONCYCLESDEVIATIONINSTRUCTION_H