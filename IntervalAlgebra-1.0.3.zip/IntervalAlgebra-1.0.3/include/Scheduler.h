#ifndef IA_SCHEDULER_H
#define IA_SCHEDULER_H

#include <string>
#include <list>
#include <map>
#include <algorithm>
#include "Job.h"
#include "JobTree.h"
#include "IAResource.h"
#include "limits.h"


namespace IntervalAlgebra
{
extern map<Job*,TreeNode*> mapJob_TreeNode;

	using namespace std;

	class Scheduler {
		string Name;
		list<Job> ScheduledJobs;
		IAResource *UsedResource;
		int BeforeDeadlineCounter;
		int AfterDeadlineCounter;
		Job *StartJob;
		Job *EndJob;
		map<string,Job*> AllJobsMap;
		bool AllocateTasksUsingPModes_;
		vector<int> TaskPModes_;
		bool EndsWith(string const &Value, string const &Ending);



	protected:
		JobTree *jt1;
		list<Job*> AllJobs;
		list<IAResource*> AllCores;
		Scheduler();
	public:
		virtual ~Scheduler();
		void ClearTaskPModesVector();
		int GetNumberofTaskPModesVectorElements();
		int GetElementFromTaskPModesVectorElements(int IndexIn);
		void SetElementFromTaskPModesVectorElements(int IndexIn,int ValueIn); 
		void SetSizeofTaskPModesVectorElements(int SizeIn);
		void DisplayJobTime();
		void AddJobA(Job* JobIn);
		void AddCore(IAResource* CoreIn);
		IAResource* GetCore(int Index);
		void AddJobs(list<Job*> *Jobs);
		Job* FindJobByName(string NameOfJobNeeded,list<Job*>* AllJobs=NULL);
		void AddEndJob();
		void DisplayJobs(list<Job*> *Jobs);
		void Initialize();
		void DisplayAllJobs();
		void SortJobByTime();
		void DisplayJobTimeWithPriorities();
		void RemoveAllJobs();
		void RemoveTree();
		void IncreaseBeforeDeadlineCounter();
		void IncreaseAfterDeadlineCounter();
		void ResetDeadlineCounters();
		void ComputeDeadlineCounters();
		int GetBeforeDeadlineCounter();
		int GetAfterDeadlineCounter();
		Time* GetTotalLaxity();
		Job* GetEarliestJob();
		Job* GetLatestJob();
		Job* GetLatestFirstJobOfPeriodicTask();
		void Collapse(Job *CollapseJob);
		void Preserve();
		void Finalize();
		int GetTheHighestDependencyLevel(list<Job*> *Jobs);
		void DetermineDependencyLevel(list<Job*> *Jobs);
		int GetDependencyLevel(Job *JobIn);
		void DetermineDependencyLevelOfAllJobs();
		bool UpdatePeriodicDependencies(Job* JobIn,int JobIndexIn,list<Job*>* AllJobs);
		list<Job*>* SplitPeriodicTaskIntoSeriesofSingleAppearanceTask(Job* JobIn, Time *EndSplittingTime);
		void AddPeriodicJob(Job* JobIn,Time *MaxTime,bool AddIfNotSplit=true);
		bool PerformRealTimeAnalysisSingleCore();
		bool PerformRealTimeAnalysisForCore(IAResource* CoreIn);
		bool CheckIfAllTasksArePeriodicOrSporadic();
		bool CheckIfAllTasksArePeriodicOrSporadicForCore(IAResource* CoreIn);
		void FindHigherPrioritiesJob(Job* JobIn,list<Job*> *HigherPriorities);
		void FindHigherPrioritiesJobForCore(Job* JobIn,list<Job*> *HigherPriorities, IAResource* CoreIn);
		JobTree* GetJobTree();
		const list<Job*>&  GetAllJobsList();
		virtual void Schedule()=0;
		void AssignPrioritiesEDF();
		static bool HasLHSEarlierDeadlineThanRHSJob(Job* lhs, Job* rhs);
		void RemoveFromAllJobsAndAllJobsMap(Job *JobIn);
		double GetEnergy();
		TimeUnit GetSmallestUnitFromStartEndTimes(list<Job*> *JobList);
		void SetAllocateTasksUsingPModes(bool AllocateTasksUsingPModesIn);
		bool GetAllocateTasksUsingPModes();



	}; 


}

#endif // IA_SCHEDULER_H
