#ifndef IA_REMOTEACCESSINSTRUCTION_H
#define IA_REMOTEACCESSINSTRUCTION_H

#include <iostream>
#include <list>
#include "AmInstruction.h"
#include "AmLabel.h"

namespace IntervalAlgebra
{
   using namespace std;

	class RemoteAccessInstruction : public Instruction {
		Label* Label_;
		bool Write_;

	public:
		RemoteAccessInstruction(string NameIn);
		~RemoteAccessInstruction();
		void SetLabel(Label* LabelIn);
		Label* GetLabel();
		void SetWrite(bool WriteIn);
		bool GetWrite();
		void Print();

	}; 


}

#endif // IA_REMOTEACCESSINSTRUCTION_H