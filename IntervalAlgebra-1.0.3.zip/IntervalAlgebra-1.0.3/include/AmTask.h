#ifndef IA_TASK_H
#define IA_TASK_H

#include <iostream>
#include <vector>
#include "AmRunnable.h"
#include "AmStimulus.h"


namespace IntervalAlgebra
{
   using namespace std;

	class Task {
		string Name;
		int Priority;
		bool PriorityValid;
		int MultipleTaskActivationLimit;
		bool MultipleTaskActivationLimitValid;
		string Preemption;
		pair<int,string> Deadline;
		vector<Runnable*> Runnables;
		Stimulus *Stimulus_;
	public:
		Task(string NameIn);
		~Task();
		void SetName(string NameIn);
		string GetName();
		int GetPriority();
		void SetPriority(int PriorityIn);
		bool GetPriorityValid();
		int GetMultipleTaskActivationLimit();
		void SetMultipleTaskActivationLimit(int MultipleTaskActivationLimitIn);
		bool GetMultipleTaskActivationLimitValid();
		string GetPreemption();
		void SetPreemption(string PreemptionIn);
		void SetDeadline(pair<int,string> DeadlineIn);
		int GetDeadlineValue();
		string GetDeadlineUnit();
		void AddRunnable(Runnable* RunnableIn);
		Runnable* GetRunnable(int Index);
		int GetNoOfRunnables();
		void Print();
		void SetStimulus(Stimulus* StimulusIn);
		Stimulus* GetStimulus();
		pair<int,string> GetPeriod();



	}; 


}

#endif // IA_TASK_H