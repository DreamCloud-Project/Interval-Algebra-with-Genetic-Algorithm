#ifndef IA_EXECUTIONCYCLESCONSTANTINSTRUCTION_H
#define IA_EXECUTIONCYCLESCONSTANTINSTRUCTION_H

#include <iostream>
#include <list>
#include "AmInstruction.h"

namespace IntervalAlgebra
{
   using namespace std;

	class ExecutionCyclesConstantInstruction : public Instruction {
		int Value;
	public:
		ExecutionCyclesConstantInstruction(string NameIn);
		int GetValue();
        void SetValue(int ValueIn);
		void Print();

	}; 


}

#endif // IA_EXECUTIONCYCLESCONSTANTINSTRUCTION_H