#ifndef IA_RESOURCETYPE_H
#define IA_RESOURCETYPE_H

#include <iostream>
#include <list>
#include "Types.h"

namespace IntervalAlgebra
{
   using namespace std;

	class IAResourceType {
		string Name_;
		double DynamicEnergyMultiplierPerClockCycle_;
		double SwitchingPModeTimePenalty;
		double SwitchingPModeEnergyPenalty;
		list<pair<double,double> > VoltageFrequencyList;
		int MaxFrequencyInHz_;


		void SortVoltageFrequencyListDescending();


	public:
		IAResourceType(string NameIn);
		IAResourceType(IAResourceType& IResourceNameIn);

		int GetNoOfDVFSLevels();
		void AddVoltageFrequencyLevel(double Voltage, double Frequency);
		void SetName(string NameIn);
		string GetName();
		void SetDynamicEnergyMultiplierPerClockCycle(double EnergyMultiplierIn);
		double GetDynamicEnergyMultiplierPerClockCycle();
		double GetSwitchingPModeTimePenalty();
		double GetSwitchingPModeEnergyPenalty();
		void SetSwitchingPModeTimePenalty(double SwitchingPModeTimePenaltyIn);
		void SetSwitchingPModeEnergyPenalty(double SwitchingPModeEnergyPenaltyIn);
		double GetDVFSFrequencyLevel(int LevelIn);
		double GetDVFSVoltageLevel(int LevelIn);
		void SetMaxFrequencyInHz(int MaxFrequencyInHzIn);
		int GetMaxFrequencyInHz();
	}; 


}

#endif // IA_RESOURCETYPE_H