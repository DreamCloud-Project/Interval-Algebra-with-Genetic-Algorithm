#ifndef IA_TYPES_H
#define IA_TYPES_H



using namespace std;

namespace IntervalAlgebra
{
	enum TimeUnit {fs,ps,ns,us,ms,s};
	const double StaticEnergyPercentageWRTDynamicEnergy=0.1;


	const double StaticEnergyCore = 3.8600E-04; //in �J per clockcycle
	const double StaticEnergyLink = 0; //in �J per clockcycle
	


	const double StaticCoreFrequency= 1000000000; //for the values above, as they are provided for one clock cycle

	const double DynamicEnergyCore = 1.3510E-03; //in �J per clockcycle
	const double DynamicEnergyLink = 5.12E-18; //in �J per clockcycle 


	const int ZeroHopDelayinClockCycles=2;
	const int OneHopDelayinClockCycles=4;
	const int OneRouterDelayinClockCycles=5;
	const int FlitSize=32;
			


	struct DeleteObject{
		template<typename T>
		void operator()(const T* ptr) const {
			delete ptr;
		}
	};


}

#define DEBUG_NEW new(_NORMAL_BLOCK, THIS_FILE, __LINE__)
#endif // IA_TYPES_H
