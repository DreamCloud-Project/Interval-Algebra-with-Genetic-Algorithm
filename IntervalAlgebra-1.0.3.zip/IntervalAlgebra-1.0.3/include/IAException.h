#ifndef IA_EXCEPTION_H
#define IA_EXCEPTION_H

#include <exception>

namespace IntervalAlgebra
{

using namespace std;

class CNoExecutionTimeForExecutingCore: public exception
{
public:
   virtual const char* what() throw() {
	return "No execution time for the executing core."; 
  }
};

class CNoElementInPDF: public exception
{
public:
  virtual const char* what() throw() {
	return "No required element in PDF."; 
  }
};

extern CNoExecutionTimeForExecutingCore NoExecutionTimeForExecutingCore;  
extern CNoElementInPDF NoElementInPDF;  

}

#endif //IA_EXCEPTION_H
