#ifndef IA_SCHEDULERPRIORITYPREEMPTIVE_H
#define IA_SCHEDULERPRIORITYPREEMPTIVE_H

#include <string>
#include <list>
#include <iterator>
#include <algorithm>

#include "IATime.h"
#include "Job.h"
#include "JobTree.h"
#include "Scheduler.h"



namespace IntervalAlgebra
{
   using namespace std;

	class SchedulerPriorityPreemptive : public Scheduler {
	private:
		vector<Time*> CurrentTime;

	public:
		SchedulerPriorityPreemptive();
		void Schedule();
		Time* DeterminePreemptionTime(Job *j,int iteration=-1);
		void CheckPossiblePreemptions(Job *JustFinishedJob,int &iteration);
		void Preempt(int iCore,Job* j,Time *tPreemption, int &Index);


	}; 


}

#endif // IA_SCHEDULERPRIORITYPREEMPTIVE_H
