#ifndef IA_JOBTREE_H
#define IA_JOBTREE_H

#include <map>
#include <algorithm>
#include "JobTreeNode.h"
#include "TreeNode.h"

namespace IntervalAlgebra
{
extern list<TreeNode*> AllTreeNodes;
extern map<Job*,TreeNode*> mapJob_TreeNode;
extern multimap<Job*,TreeNode*> multimapJob_ParentTreeNode;

	class JobTree {
		TreeNode *Tree;
		void Display(int level, TreeNode *JobTreeNodeIn);
		 
	public:
		~JobTree();
		void AddRoot(Job *Root);
		JobTreeNode* FindNode(TreeNode *StartNode, Job *JobIn);
		vector<TreeNode*>* GetChildren(TreeNode *StartNode, Job *JobIn);
		TreeNode* FindTreeNode(TreeNode *StartNode, Job *JobIn);
		JobTreeNode* GetRoot();
		TreeNode* GetRootTreeNode();
		void DisplayFromRoot();
		void AddChildrenToEachParent(JobTreeNode* JobTreeNodeIn,int Iteration);
		void BuildTreeFromRoot(list<Job*> *Jobs);
		Job* FindTheEarliestReadyJob(Job* JobIn=NULL,int iteration=-1);
		Job* FindTheEarliestReadyJobForCore(IAResource* CoreIn,Job* JobIn=NULL,int iteration=-1);

		Job* FindTheEarliestReadyJobButNotOriginatedFrom(string OriginalIDOfthePreviousJobID,Job* JobIn=NULL,int iteration=-1);
		Job* FindTheEarliestReadyJobOfTheHighestPriority(Time *CurrentTime,Job* JobIn=NULL,int iteration=-1);
		Job* FindTheEarliestReadyJobOfTheHighestPriorityForCore(Time *CurrentTime, Job* JobIn,IAResource* CoreIn, int iteration=-1);

		Job* FindTheEarliestReadyJobOfTheHighestPriorityAndPriorityHigherThan(Job* JobIn,int iteration=-1);
		Job* FindTheEarliestReadyJobOfTheHighestPriorityAndPriorityHigherThanForCore(Job* JobIn,IAResource* CoreIn,int iteration=-1);

		Time* DetermineStartTime(Job* JobIn);
		Time* DetermineTheEarliestNonAllocatedTimeForCore(IAResource* CoreIn=NULL);
		Time* DetermineTheEarliestNonAllocatedTimeForExecutingCores(Job* JobIn);
		void AddNodeAsAParentTo(Job* NewParentJob,Job* ExisitngJob,int iteration);
		void AddNodeAsAChildTo(Job* NewChildJob,Job* ExisitngJob);
		void ChangeAllChildReferencesFromNode(TreeNode* FromWhichNode, Job* ExisitngJob, TreeNode* ReplaceTo);
		void ChangeAllChildReferencesFromRoot(Job* ExisitngJob, TreeNode* ReplaceTo);
		void ReplaceNodesFromFromNode(TreeNode* FromWhichNode, TreeNode* ReplaceFrom, TreeNode* ReplaceTo,int iteration);
		void ReplaceNodesFromRoot(TreeNode* ReplaceFrom, TreeNode* ReplaceTo,int iteration);
		void RemoveJustAddedNode(TreeNode* ToBeRemoved);

		Time* GetReadyTime(Job* JobIn);	
		void FillListOfChildren(list<Job*>* ChildrenListIn,Job *JobIn);
		void FillListOfParents(list<Job*>* ParentsListIn,Job *JobIn);
		Job* FindJobExecutedByCoreAtTime(IAResource *CoreIn,Time* TimeIn,int iteration);

	};



}

#endif // IA_JOBTREE_H
