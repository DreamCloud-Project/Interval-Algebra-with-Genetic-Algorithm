#ifndef IA_STIMULUS_H
#define IA_STIMULUS_H

#include <iostream>
#include <string>
#include <vector>
#include <algorithm>


namespace IntervalAlgebra
{
	using namespace std;
	class Task;
	class Job;

	class Stimulus {
		string Name;
		string ID;
		pair<int,string> Recurrence;
		pair<int,string> Offset;
		vector<Task*> Sources;
		vector<Task*> Destinations;
		vector<Job*> SourcesJob;
		vector<Job*> DestinationsJob;
	public:
		Stimulus(string NameIn);
		void SetName(string NameIn);
		string GetName();
		void SetID(string IDIn);
		string GetID();
		void SetRecurrence(pair<int,string> RecurrenceIn);
		void SetOffset(pair<int,string> OffsetIn);
		pair<int,string> GetRecurrence();
		pair<int,string> GetOffset();
		void Print();
		void AddSource(Task* TaskIn);
		void AddDestination(Task* TaskIn);
		int GetNoOfSources();
		int GetNoOfDestinations();
		bool IsTaskInSources(Task *TaskIn);
		bool IsTaskInDestinations(Task *TaskIn);
		Task* GetSource(int Index);
		Task* GetDestination(int Index);
		Job* GetSourceJob(int Index);
		Job* GetDestinationJob(int Index);
		void AddSourceJob(Job* JobIn);
		void AddDestinationJob(Job* JobIn);
		int GetNoOfSourcesJob();
		int GetNoOfDestinationsJob();
		void ClearSourceJobs();
		void ClearDestinationJobs();
	}; 


}

#endif // IA_STIMULUS_H