#ifndef IA_TIME_H
#define IA_TIME_H

#include "Types.h"
#include <iostream>


using namespace std;


namespace IntervalAlgebra
{
   using namespace std;

	class Time {
	private:
		virtual std::ostream& DoPrint(std::ostream&) const = 0;	
	protected:
		TimeUnit Unit;
	public:
		virtual const bool operator < (Time &t)=0;
		virtual const bool operator <= (Time &t)=0;
		virtual const bool operator > (Time &t)=0;
		virtual const bool operator == (Time &t)=0;
		virtual long long GetValue()=0;
		virtual TimeUnit GetUnit()=0;
		string GetUnitAsString();
		virtual bool IsStochastic()=0;
		TimeUnit GetLowerUnit(Time* TimeIn);
		virtual void ConvertTo(TimeUnit TimeUnitIn)=0;
		virtual Time* Clone()=0;
		virtual long long GetWorstCaseValue()=0;
		virtual long long GetBestCaseValue()=0;
		virtual long long GetValueInUnit(TimeUnit TimeUnitIn)=0;
		virtual long long GetWorstCaseValueInUnit(TimeUnit TimeUnitIn)=0;
		virtual long long GetBestCaseValueInUnit(TimeUnit TimeUnitIn)=0;
		virtual void MultipleValueByConst(double ConstIn)=0;

		long long ComputeValueToUnit(long long ValueSrc,TimeUnit UnitSrc,TimeUnit UnitDst);

		friend ostream& operator<<(ostream& os, const Time& dt) {
			return dt.DoPrint(os);
		}
		friend Time* Add(Time &t1,Time &t2);
		friend Time* Sub(Time &t1,Time &t2);


	};


}

#endif // IA_TIME_H
