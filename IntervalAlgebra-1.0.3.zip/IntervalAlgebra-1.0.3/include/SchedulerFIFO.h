#ifndef IA_SCHEDULERFIFO_H
#define IA_SCHEDULERFIFO_H

#include <string>
#include <list>

#include "Job.h"
#include "JobTree.h"
#include "Scheduler.h"


namespace IntervalAlgebra
{
   using namespace std;

	class SchedulerFIFO : public Scheduler {

	public:
		SchedulerFIFO();
		void Schedule();
		
	}; 


}

#endif // IA_SCHEDULERFIFO_H