#ifndef IA_SCHEDULERPRIORITYTDM_H
#define IA_SCHEDULERPRIORITYTDM_H

#include <string>
#include <list>

#include "IATime.h"
#include "Job.h"
#include "JobTree.h"
#include "Scheduler.h"

namespace IntervalAlgebra
{
   using namespace std;

   class SchedulerPriorityTDM : public Scheduler {
	private:
	   	vector<Time*> CurrentTime;
	public:
		SchedulerPriorityTDM(Time *QuantumIn);

		void Schedule();
		Time *Quantum;
		Time* GetQuantum();


	}; 


}

#endif // IA_SCHEDULERPRIORITYTDM_H
