#ifndef IA_QUARTZ_H
#define IA_QUARTZ_H

#include <iostream>
#include <list>


namespace IntervalAlgebra
{
   using namespace std;

	class Quartz {
		string Name;
		string ID;
		int Frequency;
	public:
		Quartz(string NameIn);
		void SetName(string NameIn);
		string GetName();
		void SetFrequency(int FrequencyIn);
		int GetFrequency();
		void SetID(string IDIn);
		string GetID();
	}; 


}

#endif // IA_QUARTZ_H