/*
 *  Open BEAGLE
 *  Copyright (C) 2001-2007 by Christian Gagne and Marc Parizeau
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 *  Contact:
 *  Laboratoire de Vision et Systemes Numeriques
 *  Departement de genie electrique et de genie informatique
 *  Universite Laval, Quebec, Canada, G1K 7P4
 *  http://vision.gel.ulaval.ca
 *
 */

/*!
 *  \file   MaxFctEvalOp.cpp
 *  \brief  Implementation of the class MaxFctEvalOp.
 *  \author Christian Gagne
 *  \author Marc Parizeau
 *  $Revision: 1.9.2.1 $
 *  $Date: 2007/05/09 01:51:22 $
 */


#include "beagle/GA.hpp"
#include "MaxFctEvalOpMO.hpp"
#include <cmath>
#include <iostream>
#include <vector>
#include "IntervalAlgebra.h"
#include "GATypes.h"



using namespace Beagle;


extern TestUnit* MyTestUnit;




/*!
 *  \brief Construct the individual evaluation operator for maximising the function.
 *  \param inEncoding Encoding of the variables (in bits).
 */

MaxFctEvalOpMO::MaxFctEvalOpMO(UIntArray inEncoding) :
  EvaluationOp("MaxFctEvalOpMO")
{

	NoOfRunnables=MyTestUnit->GetNoOfRunnables();
	NoOfLabels=MyTestUnit->GetNoOfLabels();
	if(inEncoding.size() != NoOfRunnables+NoOfLabels)	//TriCore
	throw ValidationException("Wrong size of the encoding vector!");
	for(unsigned int i=0; i<NoOfRunnables+NoOfLabels; i++) { //TriCore
		GA::BitString::DecodingKey lKey(0.0, 255.0, inEncoding[i]);
		mDecodingKeys.push_back(lKey);
	}



}



int ComputeDistance(vector<int> *List1, int IdleCoresInList1, vector<int> *List2,int IdleCoresInList2, int NoOfCores,vector<int> *Cost=NULL) {
	if(List1->size()!=List2->size()) {
		return -1;
	}
	vector<int>:: iterator it1,it2;
	int result=0,ind=0;
	for(it1=List1->begin(),it2=List2->begin();it1!=List1->end();++it1,++it2,ind++) {
		if(*it1%(NoOfCores-IdleCoresInList1) != *it2%(NoOfCores-IdleCoresInList2)) {
			if(Cost==NULL) {
				result+=1;
			}
			else {
				result+=(*Cost)[ind];
			}
		}
	}
	return result;
}




/*!
 *  \brief Evaluate the fitness of the given individual.
 *  \param inIndividual Current individual to evaluate.
 *  \param ioContext Evolutionary context.
 *  \return Handle to the fitness value of the individual.
 */


//for TriCore
Fitness::Handle MaxFctEvalOpMO::evaluate(Individual& inIndividual, Context& ioContext)
{




	vector<int> tab;
	vector<int> labels;
	tab.resize(NoOfRunnables);
	labels.resize(NoOfLabels);
	Beagle_AssertM(inIndividual.size() == 1);


	GA::BitString::Handle lBitString = castHandleT<GA::BitString>(inIndividual[0]);
	Beagle::DoubleArray lX;
	lBitString->decode(mDecodingKeys, lX);



//mapping
	for (int i=0;i<NoOfRunnables;i++) {
		tab[i]=(int)lX[i]%(NoOfCores-IdleCoresListCurrentMode);
	}



	for (int i=0;i<NoOfLabels;i++) {
		labels[i]=(int)lX[i+NoOfRunnables]%(NoOfMemories-IdleMemoriesListCurrentMode)+NoOfCores;
	}

	FitnessMultiObj::Handle lFitness = new FitnessMultiObj(2);










  pair<double,double> result;
  result=MyTestUnit->TestAmaltheaTriCore(tab,labels,NoOfCores,NoOfMemories);

#ifdef ComparisonInModalSystem
	int DistanceRunnable=ComputeDistance(&tab,IdleCoresListCurrentMode, &RunnablesInPreviousMode,IdleCoresListPreviousMode,NoOfCores,&RunnableMigrationCost);
	int DistanceRunnableNo=ComputeDistance(&tab,IdleCoresListCurrentMode, &RunnablesInPreviousMode,IdleCoresListPreviousMode,NoOfCores);

	int DistanceLabel=ComputeDistance(&labels,IdleMemoriesListCurrentMode, &LabelsInPreviousMode,IdleMemoriesListPreviousMode,NoOfMemories,&LabelMigrationCost);
	int DistanceLabelNo=ComputeDistance(&labels,IdleMemoriesListCurrentMode, &LabelsInPreviousMode,IdleMemoriesListPreviousMode,NoOfMemories);



	cout << "Distances: " << DistanceRunnable << ", " << DistanceRunnableNo << endl;

//for TriCore - just missed deadline number
	result.second=result.first;

	result.first=DistanceRunnable;
	result.first+=DistanceLabel;
#endif

  (*lFitness)[0] = result.first;
  (*lFitness)[1] = result.second;
  cout << "1st criterion: " << result.first << ", 2nd criterion: " << result.second << endl;

  return lFitness;
}





