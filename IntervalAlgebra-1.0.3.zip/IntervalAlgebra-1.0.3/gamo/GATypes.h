#ifndef GA_TYPES_H
#define GA_TYPES_H

//#define ComparisonInModalSystem

	const int NoOfBits=8;
	const int PModeLevels=6;


	const int NoCSizeX=2;
	const int NoCSizeY=2;

	const int IdleCoresListPreviousMode=1;
	const int IdleCoresListCurrentMode=1;

	const int NoOfCores=3;
	const int NoOfMemories=2;


	const int IdleMemoriesListPreviousMode=0;
	const int IdleMemoriesListCurrentMode=0;

	extern vector<int> RunnablesInPreviousMode;
	extern vector<int> RunnableMigrationCost;

	extern vector<int> LabelsInPreviousMode;
	extern vector<int> LabelMigrationCost;


#endif // GA_TYPES_H

