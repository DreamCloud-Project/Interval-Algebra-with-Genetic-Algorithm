/*
 *  Open BEAGLE
 *  Copyright (C) 2001-2007 by Christian Gagne and Marc Parizeau
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 *  Contact:
 *  Laboratoire de Vision et Systemes Numeriques
 *  Departement de genie electrique et de genie informatique
 *  Universite Laval, Quebec, Canada, G1K 7P4
 *  http://vision.gel.ulaval.ca
 *
 */

/*!
 *  \file   MaxFctMain.cpp
 *  \brief  Implementation of the main routine for the maximisation problem.
 *  \author Christian Gagne
 *  \author Marc Parizeau
 *  $Revision: 1.9.2.1 $
 *  $Date: 2007/05/09 01:51:22 $
 */

#include "beagle/GA.hpp"
#include "MaxFctEvalOpMO.hpp"

#include <cstdlib>
#include <iostream>
#include <stdexcept>
#include <vector>
#include <numeric>
#include <string>
#include <iostream>
#include <time.h>
#include <fstream>
#include <iomanip>
#include <sstream>
#include <regex>
#include "IntervalAlgebra.h"
#include "GATypes.h"


/*!
 *  \brief Main routine for the function maximisation problem.
 *  \param argc Number of arguments on the command-line.
 *  \param argv Arguments on the command-line.
 *  \return Return value of the program.
 *  \ingroup MaxFct
 */
using namespace Beagle;
using namespace std;

TestUnit* MyTestUnit;

	vector<int> RunnablesInPreviousMode;
	vector<int> RunnableMigrationCost;

	vector<int> LabelsInPreviousMode;
	vector<int> LabelMigrationCost;


int BinString2int(std::string StringIn) {
	int result=0;
	int multiplier=1;
	std::string::const_reverse_iterator rit;

	for(rit=StringIn.rbegin();rit!=StringIn.rend();++rit) {
		result+=(*rit=='1')*multiplier;
		multiplier*=2;
	}
	return result;
}


void FillMigrationCosts(int NoOfRunnables,std::string FileName){
	RunnableMigrationCost.resize(NoOfRunnables);

	std::string line;
	ifstream myfile(FileName);
	int index=0;
	if (myfile.is_open()) {
		while(getline(myfile,line) && NoOfRunnables-- >0) {
			RunnableMigrationCost[index++]=atoi(line.c_str());
		}
	}
	else { 
	  cout << "Unable to open file." << endl; 
	  exit(-1);
	}


}


void FillMigrationCostsTriCore(int NoOfRunnables,int NoOfLabels,std::string FileName){
	RunnableMigrationCost.resize(NoOfRunnables);
	LabelMigrationCost.resize(NoOfLabels);

	std::string line;
	ifstream myfile(FileName);
	int index=0;
	if (myfile.is_open()) {
		while(getline(myfile,line) && NoOfRunnables-- >0) {
			RunnableMigrationCost[index++]=atoi(line.c_str());
		}
		index=0;
		while(getline(myfile,line) && NoOfLabels-- >0) {
			LabelMigrationCost[index++]=atoi(line.c_str());
		}
	}
	else { 
	  cout << "Unable to open file." << endl; 
	  exit(-1);
	}


}



void FillTabLabelsFromFileForTriCore(vector<int> *Runnables,vector<int> *Labels,int NoOfRunnables,int NoOfCores,int NoOfLabels,std::string FileName,int WhichMapping,int BinNumberLength,int IdleCores, int IdleMemories) {
	std::string InputString;
	ifstream myfile(FileName);
	if (myfile.is_open()) {
		while(getline(myfile,InputString) && WhichMapping-- >0) {
		}
	myfile.close();
	}
	else { 
	  cout << "Unable to open file." << endl; 
	  exit(-1);
	}
	if(WhichMapping>-1) {
		cout << "Not sufficient mappings in file." << endl; 
		exit(-1);
	}



	while(!InputString.empty() && NoOfRunnables-- >0) {
		std::string Substring=InputString.substr(0,BinNumberLength);
		InputString.erase(InputString.begin(), InputString.begin()+BinNumberLength);
		int DecNumber=BinString2int(Substring);
		Runnables->push_back(DecNumber%(NoOfCores-IdleCores));
	}

	while(!InputString.empty() && NoOfLabels-- >0) {
		std::string Substring=InputString.substr(0,BinNumberLength);
		InputString.erase(InputString.begin(), InputString.begin()+BinNumberLength);
		int DecNumber=BinString2int(Substring);
		Labels->push_back(DecNumber%(NoOfMemories-IdleMemories));
	}


}


void FillTabLabelsFromFile(vector<int> *runnablesCmp,int NoOfRunnables,std::string FileName,int WhichMapping, int BinNumberLength, int NoOfCores) {
  
	
	
	std::string InputString;
	ifstream myfile(FileName);
	if (myfile.is_open()) {
		while(getline(myfile,InputString) && WhichMapping-- >0) {
		}
	myfile.close();
	}
	else { 
	  cout << "Unable to open file." << endl; 
	  exit(-1);
	}
	if(WhichMapping>-1) {
		cout << "Not sufficient mappings in file." << endl; 
		exit(-1);
	}



	while(!InputString.empty() && NoOfRunnables-- >0) {
		std::string Substring=InputString.substr(0,BinNumberLength);
		InputString.erase(InputString.begin(), InputString.begin()+BinNumberLength);
		int DecNumber=BinString2int(Substring);
		runnablesCmp->push_back(DecNumber%NoOfCores);

	}



}



int main(int argc, char** argv) {

	TestUnit* MyTestUnit=new TestUnit;
	std::string strName="../../benchmarks/DemoCar-PowerDown.amxmi";

	MyTestUnit->ParseAmalthea(strName);

	int NoOfRunnables=MyTestUnit->GetNoOfRunnables();
	int NoOfLabels=MyTestUnit->GetNoOfLabels();

	



#ifdef ComparisonInModalSystem
	RunnablesInPreviousMode.reserve(NoOfRunnables);
	LabelsInPreviousMode.reserve(NoOfLabels);
	std::string FileName="../../benchmarks/MultiModalTriCore/mapDrive-Idle1";
	int WhichMapping=0;




	FillTabLabelsFromFileForTriCore(&RunnablesInPreviousMode,&LabelsInPreviousMode,NoOfRunnables,NoOfCores,NoOfLabels,FileName,WhichMapping,NoOfBits,IdleCoresListPreviousMode, IdleMemoriesListPreviousMode);
	std::string strCostName="../../benchmarks/DemoCarSizes.txt";

	FillMigrationCostsTriCore(NoOfRunnables,NoOfLabels,strCostName); //for TriCore
#endif


	

	srand( (unsigned)time( NULL ) );

	  try {


    UIntArray lEncodingOfX;

	System::Handle lSystem = new System;
	const unsigned int lNumberOfBits = (NoOfRunnables+NoOfLabels)*NoOfBits;
	lSystem->addPackage(new GA::PackageBitString(lNumberOfBits));
	lSystem->addPackage(new PackageMultiObj);
lSystem->setEvaluationOp("MaxFctEvalOpMO", new MaxFctEvalOpMO::Alloc);
Evolver::Handle lEvolver = new Evolver;
lEvolver->initialize(lSystem, argc, argv);
Vivarium::Handle lVivarium = new Vivarium;
lEvolver->evolve(lVivarium, lSystem);
} catch(Exception& inException) {
		inException.terminate(cerr);
	} catch(std::exception& inException) {
		cerr << "Standard exception caught:" << endl << flush;
		cerr << inException.what() << endl << flush;
		return 1;
	}


	
  delete MyTestUnit;
  return 0;

  
}
