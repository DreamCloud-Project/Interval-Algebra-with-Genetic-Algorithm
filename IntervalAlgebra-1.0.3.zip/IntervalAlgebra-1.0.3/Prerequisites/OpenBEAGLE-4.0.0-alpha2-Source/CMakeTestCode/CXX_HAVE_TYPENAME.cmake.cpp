
template<typename T> class X {
	public:X(){}
	};

int main(int, char**){
	X<float> z; 
	return 0;
	}
