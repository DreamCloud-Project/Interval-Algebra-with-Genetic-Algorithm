
#include <unordered_map>

using std::unordered_map; 
int main(int,char**) {}
