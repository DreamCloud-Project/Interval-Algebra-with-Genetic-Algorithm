
int main(int, char**){
	try { 
		throw  1; 
		} 
	catch (int i) { 
		return i; 
		}
	}
