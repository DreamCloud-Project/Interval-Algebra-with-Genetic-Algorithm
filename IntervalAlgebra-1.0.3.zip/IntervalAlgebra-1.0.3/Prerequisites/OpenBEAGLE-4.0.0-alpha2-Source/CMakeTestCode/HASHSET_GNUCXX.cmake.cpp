#include <ext/hash_set>

using __gnu_cxx::hash_set; 

int main(int,char**) {}
