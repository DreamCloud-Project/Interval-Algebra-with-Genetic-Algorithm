#include <hash_map>

using std::hash_map; 
int main(int,char**) {}
