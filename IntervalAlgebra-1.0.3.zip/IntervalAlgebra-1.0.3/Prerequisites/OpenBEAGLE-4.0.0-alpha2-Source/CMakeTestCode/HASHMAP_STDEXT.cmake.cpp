#include <stdext/hash_map>

using stdext::hash_map; 

int main(int,char**) {}
