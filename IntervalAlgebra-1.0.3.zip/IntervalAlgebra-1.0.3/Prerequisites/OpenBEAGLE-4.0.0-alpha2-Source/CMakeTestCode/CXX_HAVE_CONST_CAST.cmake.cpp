
int main(int,char**) {
  int x = 0; 
  const int& y = x; 
  int& z = const_cast<int&>(y); 
}
