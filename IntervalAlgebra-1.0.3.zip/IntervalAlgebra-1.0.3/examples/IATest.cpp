// IATest.cpp : Defines the entry point for the console application.
//

#include <iostream>
#include <cmath>
#include <vector>
#include <time.h>
#include <fstream>
#include <string>
#include "IntervalAlgebra.h"

using namespace std;


int BinString2int(string StringIn) {
	int result=0;
	int multiplier=1;
	string::const_reverse_iterator rit;

	for(rit=StringIn.rbegin();rit!=StringIn.rend();++rit) {
		result+=(*rit=='1')*multiplier;
		multiplier*=2;
	}
	return result;
}


void PerformTestAmaltheaTriCore() {

	TestUnit* MyTestUnit=new TestUnit;
	std::string strName="../../benchmarks/DemoCar-Drive.amxmi";



	MyTestUnit->ParseAmalthea(strName);
	
	int NoOfCores=3;
	int NoOfMemories=2;

	int NoOfRunnables=MyTestUnit->GetNoOfRunnables();
	int NoOfLabels=MyTestUnit->GetNoOfLabels();

	srand( (unsigned)time( NULL ) );

	vector<int> tabRunnables;
	tabRunnables.resize(NoOfRunnables);






	for (int i=0;i<NoOfRunnables;i++) {
		tabRunnables[i]=rand()%NoOfCores;
	}
	
vector<int> tabLabels;
	tabLabels.resize(NoOfLabels);

	for (int i=0;i<NoOfLabels;i++) {
		tabLabels[i]=rand()%NoOfMemories+NoOfCores;	//memories have indices just after cores
	}



	pair<double,double> result;

	result=MyTestUnit->TestAmaltheaTriCore(tabRunnables,tabLabels,NoOfCores,NoOfMemories);
		
	cout << "result1= " << result.first << " , result2= " << result.second << endl;

  delete MyTestUnit;

}


void PerformTestAmaltheaNoC() {

	TestUnit* MyTestUnit=new TestUnit;

	std::string strName="../benchmarks/DEMO_CAR_fromCNRS.amxmi";


	MyTestUnit->ParseAmalthea(strName);
	

	int NoCXSize=4;
	int NoCYSize=4;

	int NoOfCores=NoCXSize*NoCYSize;
	int NoOfRunnables=MyTestUnit->GetNoOfRunnables();
	int NoOfLabels=MyTestUnit->GetNoOfLabels();

	srand( (unsigned)time( NULL ) );

	vector<int> tabRunnables;
	tabRunnables.resize(NoOfRunnables);



	for (int i=0;i<NoOfRunnables;i++) {
		tabRunnables[i]=rand()%NoOfCores;
	}

	vector<int> tabLabels;
	tabLabels.resize(NoOfLabels);

	for (int i=0;i<NoOfLabels;i++) {
		tabLabels[i]=rand()%NoOfCores;
	}


	MyTestUnit->TestAmaltheaNoC(tabRunnables,tabLabels,NoCXSize,NoCYSize);
		


  delete MyTestUnit;

}


void PerformTestAmaltheaNoCNoLabelMapping() {

	TestUnit* MyTestUnit=new TestUnit;
	string strName="../benchmarks/Projects/AmaltheaBenchmarks/DemoCar-Drive.amxmi";

	MyTestUnit->ParseAmalthea(strName);
	

	int NoCXSize=2;
	int NoCYSize=2;
	int IdleCores=0;
	int BinNumberLength=8;

	int NoOfCores=NoCXSize*NoCYSize-IdleCores;
	int NoOfRunnables=MyTestUnit->GetNoOfRunnables();
	int NoOfLabels=MyTestUnit->GetNoOfLabels();

//	srand( (unsigned)time( NULL ) );


//reading mapping from a file


	string InputString;
	string strMappingName="../benchmarks/mapDrive_4cores";

	  ifstream myfile (strMappingName);
	  if(myfile.is_open()) {
		getline (myfile,InputString);
		myfile.close();
	  }
	  else {
		  cout << "Unable to open file"; 
		  exit(-1);
	  }





	vector<int> DecimalNumberInputVector;


		DecimalNumberInputVector.clear();
		DecimalNumberInputVector.reserve(InputString.size()/BinNumberLength+1);

		while(!InputString.empty()) {
			string Substring=InputString.substr(0,BinNumberLength);
			InputString.erase(InputString.begin(), InputString.begin()+BinNumberLength);
			int DecNumber=BinString2int(Substring);
			DecimalNumberInputVector.push_back(DecNumber%(NoOfCores));
		}





	vector<int> tabRunnables;
	tabRunnables.resize(NoOfRunnables);

	for (int i=0;i<NoOfRunnables;i++) {
		tabRunnables[i]=DecimalNumberInputVector[i];
	}



	pair<double,double> result;
	result=MyTestUnit->TestAmaltheaNoCNoLabelMapping(tabRunnables,NoCXSize,NoCYSize,IdleCores);
	cout << "Energy: " << result.second << endl;
		


  delete MyTestUnit;

}


void PerformTestAmalthea() {

	TestUnit* MyTestUnit=new TestUnit;
	std::string strName="../benchmarks/DemoCar-Drive.amxmi";

	MyTestUnit->ParseAmalthea(strName);
	


	int NoOfCores=MyTestUnit->GetNoOfCores();
	int NoOfRunnables=MyTestUnit->GetNoOfRunnables();
	int NoOfLabels=MyTestUnit->GetNoOfLabels();


//	cout << "Cores:" <<  NoOfCores << " Tasks:" << MyTestUnit->GetNoOfTasks() << " Runnables:" << NoOfRunnables << " labels: " << NoOfLabels << endl;
	srand( (unsigned)time( NULL ) );

	vector<int> tabRunnables;
	tabRunnables.resize(NoOfRunnables);
	for (int i=0;i<NoOfRunnables;i++) {
		tabRunnables[i]=rand();
	}

	MyTestUnit->TestAmalthea(tabRunnables);
		


  delete MyTestUnit;

}


int main(int argc, char* argv[]) {
	PerformTestAmaltheaTriCore();
	return 0;
}

