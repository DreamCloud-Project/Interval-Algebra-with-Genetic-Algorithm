/*
 *  Open BEAGLE
 *  Copyright (C) 2001-2007 by Christian Gagne and Marc Parizeau
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 *  Contact:
 *  Laboratoire de Vision et Systemes Numeriques
 *  Departement de genie electrique et de genie informatique
 *  Universite Laval, Quebec, Canada, G1K 7P4
 *  http://vision.gel.ulaval.ca
 *
 */

/*!
 *  \file   MaxFctEvalOp.cpp
 *  \brief  Implementation of the class MaxFctEvalOp.
 *  \author Christian Gagne
 *  \author Marc Parizeau
 *  $Revision: 1.9.2.1 $
 *  $Date: 2007/05/09 01:51:22 $
 */


#include "beagle/GA.hpp"
#include "MaxFctEvalOp.hpp"
#include <cmath>
#include <iostream>
#include <vector>
#include "IntervalAlgebra.h"



using namespace Beagle;


extern TestUnit* MyTestUnit;
extern vector<int> tabCmp;
extern vector<int> labelsCmp;
extern vector<int> RunnableMigrationCost;
extern vector<int> LabelMigrationCost;

//#define NoLabelMapping

/*!
 *  \brief Construct the individual evaluation operator for maximising the function.
 *  \param inEncoding Encoding of the variables (in bits).
 */
MaxFctEvalOp::MaxFctEvalOp(UIntArray inEncoding) :
  EvaluationOp("MaxFctEvalOp")
{
	int NoOfRunnables=MyTestUnit->GetNoOfRunnables();
	int NoOfLabels=MyTestUnit->GetNoOfLabels();
#ifndef NoLabelMapping
	if(inEncoding.size() != NoOfRunnables+NoOfLabels)
#else
	if(inEncoding.size() != NoOfRunnables)
#endif
{
		cout << "!!! " << inEncoding.size() << " " << NoOfRunnables+NoOfLabels << " " << NoOfRunnables << endl;
	throw ValidationException("Wrong size of the encoding vector!");
}
#ifndef NoLabelMapping
	for(unsigned int i=0; i<NoOfRunnables+NoOfLabels; i++) {
#else
	for(unsigned int i=0; i<NoOfRunnables+NoOfLabels; i++) {
#endif
		GA::BitString::DecodingKey lKey(0.0, 255.0, inEncoding[i]);
		mDecodingKeys.push_back(lKey);
	}
}




/*!
 *  \brief Evaluate the fitness of the given individual.
 *  \param inIndividual Current individual to evaluate.
 *  \param ioContext Evolutionary context.
 *  \return Handle to the fitness value of the individual.
 */


int ComputeDistance(vector<int> *List1, int IdleCoresInList1, vector<int> *List2,int IdleCoresInList2, int NoOfCores,vector<int> *Cost=NULL) {
	if(List1->size()!=List2->size()) {
		return -1;
	}
	vector<int>:: iterator it1,it2;
	int result=0,ind=0;
	for(it1=List1->begin(),it2=List2->begin();it1!=List1->end();++it1,++it2,ind++) {
		if(*it1%(NoOfCores-IdleCoresInList1) != *it2%(NoOfCores-IdleCoresInList2)) {
			if(Cost==NULL) {
				result+=1;
			}
			else {
				result+=(*Cost)[ind];
			}
		}
	}
	return result;
}








Fitness::Handle MaxFctEvalOp::evaluate(Individual& inIndividual, Context& ioContext)
{

//#define ComparisonInModalSystem

	int NoOfRunnables=MyTestUnit->GetNoOfRunnables();

	int NoOfLabels=MyTestUnit->GetNoOfLabels();


	const int NoOfCores=3;
	const int NoOfMemories=2;
	const int IdleCores=0;



	vector<int> tab;
	vector<int> labels;
	vector<int> pmodes;

	tab.resize(NoOfRunnables);
	labels.resize(NoOfLabels);
	pmodes.resize(NoOfRunnables);
	Beagle_AssertM(inIndividual.size() == 1);
	GA::BitString::Handle lBitString = castHandleT<GA::BitString>(inIndividual[0]);
	Beagle::DoubleArray lX;
	lBitString->decode(mDecodingKeys, lX);

//mapping
	for (int i=0;i<NoOfRunnables;i++) {
		tab[i]=(int)lX[i]%(NoOfCores-IdleCores);
	}



	for (int i=0;i<NoOfLabels;i++) {
		labels[i]=(int)lX[i+NoOfRunnables]%NoOfMemories+NoOfCores;
	}


	double lF=-1*MyTestUnit->TestAmaltheaTriCore(tab,labels,NoOfCores,NoOfMemories).first;

  return new FitnessSimple(lF);
}







Fitness::Handle MaxFctEvalOp::evaluate2(Individual& inIndividual, Context& ioContext)
{

//#define ComparisonInModalSystem

	int NoOfRunnables=MyTestUnit->GetNoOfRunnables();

	//int NoOfCores=MyTestUnit->GetNoOfCores();
	int NoOfLabels=MyTestUnit->GetNoOfLabels();


	const int NoCSizeX=2;
	const int NoCSizeY=2;
	const int IdleCoresList1=2;
	const int IdleCoresList2=2;



	vector<int> tab;
	vector<int> labels;
	vector<int> pmodes;

	tab.resize(NoOfRunnables);
	labels.resize(NoOfLabels);
	pmodes.resize(NoOfRunnables);
	Beagle_AssertM(inIndividual.size() == 1);
	GA::BitString::Handle lBitString = castHandleT<GA::BitString>(inIndividual[0]);
	Beagle::DoubleArray lX;
	lBitString->decode(mDecodingKeys, lX);

//mapping
	for (int i=0;i<NoOfRunnables;i++) {
#ifndef ComparisonInModalSystem
		tab[i]=(int)lX[i]%(NoCSizeX*NoCSizeY-IdleCoresList1);
#else
		tab[i]=(int)lX[i]%(NoCSizeX*NoCSizeY-IdleCoresList2); 
#endif
	}



	for (int i=0;i<NoOfLabels;i++) {
#ifndef ComparisonInModalSystem
		labels[i]=(int)lX[i+NoOfRunnables]%(NoCSizeX*NoCSizeY-IdleCoresList1);
#else
		labels[i]=(int)lX[i+NoOfRunnables]%(NoCSizeX*NoCSizeY-IdleCoresList2);  
#endif
	}




	double lF=-1*MyTestUnit->TestAmaltheaNoCNoLabelMapping(tab,NoCSizeX,NoCSizeY).first;



//computation of distance with other mapping - for modal systems

#ifdef ComparisonInModalSystem
	int DistanceRunnable=ComputeDistance(&tab,IdleCoresList2, &tabCmp,IdleCoresList1,NoCSizeX*NoCSizeY,&RunnableMigrationCost);
	int DistanceRunnableNo=ComputeDistance(&tab,IdleCoresList2, &tabCmp,IdleCoresList1,NoCSizeX*NoCSizeY);


	cout << "Distances: " << DistanceRunnable << ", " << DistanceRunnableNo << endl;
	lF*=10000000; //weight for deadline miss
	lF=lF-DistanceRunnable;
#else


#endif

  return new FitnessSimple(lF);
}
