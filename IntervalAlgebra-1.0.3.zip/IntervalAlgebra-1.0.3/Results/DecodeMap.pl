#!/usr/bin/perl 

$numArgs = $#ARGV + 1;
print "thanks, you provided $numArgs command-line arguments\n";

@runnablelabellist = ();
open(file, "$ARGV[0]") || die "unable to open the encoded mappingfile";
while($inline01 = <file>) {
	chomp($inline01);
	#if (index $inline01, 'Genotype' >= 0) {
	if ($inline01 =~ /Geno/) {
        	print "Line containing Geno: $inline01 \n";
		($substr) = $inline01 =~ m!.*>([^<]*)<!;
		print "Only Binary: \n$substr \n";
		push(@runnablelabellist,$substr)
    	}
}
close file; 

print "$runnablelabellist[0]\n";

$numrunnables = $ARGV[1];
$numlabels = $ARGV[2];
$modemapfile = $ARGV[3];

print "number of runnables: $numrunnables\n";
print "number of labels: $numlabels\n";

@mapentity = $runnablelabellist[0] =~ /(.{8})/g;
print "@mapentity\n";
#print "First map entity $mapentity[0]\n";

$arraySize = @mapentity;
print "array size: $arraySize\n";

open($fh, '>>', $modemapfile) or die "Could not open file '$modemapfile' $!";
print $fh "Number of runnables: $numrunnables\n";
print $fh "Number of labels: $numlabels\n\n";
print $fh "Mapping of runnables to cores:\n";
print $fh "runnable_index \t\t core_index\n";
close $fh;

for ($i=0; $i<$numrunnables; $i++){
	$binary_number=$mapentity[$i];
	$decimal_number = oct("0b".$binary_number);
        $mapping_index = $decimal_number%3;
	print "mapping index for $i: $mapping_index\n";
	open($fh, '>>', $modemapfile) or die "Could not open file '$modemapfile' $!";
	print $fh "$i \t\t $mapping_index\n";
	close $fh;
}

open($fh, '>>', $modemapfile) or die "Could not open file '$modemapfile' $!";
print $fh "\nMapping of labels to cores:\n";
print $fh "label_index \t\t memory_index\n";
close $fh;

for ($i=$numrunnables; $i<$arraySize; $i++){
	$binary_number=$mapentity[$i];
	$decimal_number = oct("0b".$binary_number);
	$mapping_index = $decimal_number%2;
	print "mapping index for $i: $mapping_index\n";
	$memory_ind = $i - $numrunnables;
	open($fh, '>>', $modemapfile) or die "Could not open file '$modemapfile' $!";
	print $fh "$memory_ind \t\t $mapping_index\n";
	close $fh;
}
print "done.....\n";
