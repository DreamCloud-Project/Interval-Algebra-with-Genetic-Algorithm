#include "AmExecutionCyclesConstantInstruction.h"
#include "AmInstruction.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

namespace IntervalAlgebra
{
		ExecutionCyclesConstantInstruction::ExecutionCyclesConstantInstruction(string NameIn): Instruction(NameIn), Value(0) {
		}


		int ExecutionCyclesConstantInstruction::GetValue() {
			return Value;
		}

        void ExecutionCyclesConstantInstruction::SetValue(int ValueIn) {
			Value=ValueIn;
		}

		void ExecutionCyclesConstantInstruction::Print() {
			cout << GetName() ;
		}
}
