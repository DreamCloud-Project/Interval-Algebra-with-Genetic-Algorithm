#include "TimeDeterministic.h"
#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

namespace IntervalAlgebra
{


		const bool TimeDeterministic::operator < (Time &t) {
			if(t.GetUnit()!=GetUnit()) {
				TimeUnit LowerTimeUnit;
				LowerTimeUnit=GetLowerUnit(&t);
				if(t.GetUnit()!=LowerTimeUnit) {
					Time *t1;
					t1=new TimeDeterministic(t.GetValue(),t.GetUnit());
					t1->ConvertTo(LowerTimeUnit);
					bool result;
					result=GetValue() < t1->GetValue();
					delete t1;
					return result;
				}
				else {
					Time *t1;
					t1=new TimeDeterministic(GetValue(),GetUnit());
					t1->ConvertTo(LowerTimeUnit);
					bool result;
					result=t1->GetValue() < t.GetValue();
					delete t1;
					return result;
				}
			}
			else {
				return ( GetValue() < t.GetValue() );
			}
		}
		
		const bool TimeDeterministic::operator <= (Time &t) {
			if(t.GetUnit()!=GetUnit()) {
				TimeUnit LowerTimeUnit;
				LowerTimeUnit=GetLowerUnit(&t);
				if(t.GetUnit()!=LowerTimeUnit) {
					Time *t1;
					t1=new TimeDeterministic(t.GetValue(),t.GetUnit());
					t1->ConvertTo(LowerTimeUnit);
					bool result;
					result=GetValue() <= t1->GetValue();
					delete t1;
					return result;
				}
				else {
					Time *t1;
					t1=new TimeDeterministic(GetValue(),GetUnit());
					t1->ConvertTo(LowerTimeUnit);
					bool result;
					result=t1->GetValue() <= t.GetValue();
					delete t1;
					return result;
				}
			}
			else {
				return ( GetValue() <= t.GetValue() );
			}
		}

		const bool TimeDeterministic::operator > (Time &t) {
			if(t.GetUnit()!=GetUnit()) {
				TimeUnit LowerTimeUnit;
				LowerTimeUnit=GetLowerUnit(&t);
				if(t.GetUnit()!=LowerTimeUnit) {
					Time *t1;
					t1=new TimeDeterministic(t.GetValue(),t.GetUnit());
					t1->ConvertTo(LowerTimeUnit);
					bool result;
					result=GetValue() > t1->GetValue();
					delete t1;
					return result;
				}
				else {
					Time *t1;
					t1=new TimeDeterministic(GetValue(),GetUnit());
					t1->ConvertTo(LowerTimeUnit);
					bool result;
					result=t1->GetValue() > t.GetValue();
					delete t1;
					return result;
				}
			}
			else {
				return ( GetValue() > t.GetValue() );
			}
		}


	TimeDeterministic::TimeDeterministic(long long ValueIn,TimeUnit UnitIn) {
		Value=ValueIn;
		Unit=UnitIn;
	}

	TimeDeterministic::~TimeDeterministic() {
	}

	void TimeDeterministic::ConvertTo(TimeUnit TimeUnitIn) {
		while(Unit<TimeUnitIn) {
			Unit = static_cast<TimeUnit>( static_cast<int>(Unit) + 1 );
			Value/=1000;
		}
		while(Unit>TimeUnitIn) {
			Unit = static_cast<TimeUnit>( static_cast<int>(Unit) - 1 );
			Value*=1000;
		}
	}

	Time* TimeDeterministic::Clone() {
		TimeDeterministic *result;
		result=new TimeDeterministic(Value,Unit);
		return result;
	}

	long long TimeDeterministic::GetWorstCaseValue() {
		return Value;
	}

	long long TimeDeterministic::GetBestCaseValue() {
		return Value;
	}

	long long TimeDeterministic::GetValueInUnit(TimeUnit TimeUnitIn) {
		long long result=ComputeValueToUnit(Value,Unit,TimeUnitIn);
		return result;
	}

	long long TimeDeterministic::GetWorstCaseValueInUnit(TimeUnit TimeUnitIn) {
		return ComputeValueToUnit(Value,Unit,TimeUnitIn);
	}

	long long TimeDeterministic::GetBestCaseValueInUnit(TimeUnit TimeUnitIn) {
		return ComputeValueToUnit(Value,Unit,TimeUnitIn);
	}

	void TimeDeterministic::MultipleValueByConst(double ConstIn) {
		Value*=ConstIn;
	}



}
