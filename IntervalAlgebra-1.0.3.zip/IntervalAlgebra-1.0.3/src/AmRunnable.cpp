#include "AmRunnable.h"
#include "AmExecutionCyclesDeviationInstruction.h"
#include "AmExecutionCyclesConstantInstruction.h"
#include "AmRemoteAccessInstruction.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

namespace IntervalAlgebra
{
		Runnable::Runnable(string NameIn): Name(NameIn), Size(0) {
		}

		Runnable::~Runnable() {
			vector<Instruction*>::iterator itInstructions;
			for(itInstructions=Instructions.begin();itInstructions!=Instructions.end();++itInstructions) {
				delete *itInstructions;
			}
		}


		void Runnable::SetName(string NameIn) {
			Name=NameIn;
		}

		string Runnable::GetName() {
			return Name;
		}

		void Runnable::SetTags(string TagsIn) {
			Tags=TagsIn;
		}

		string Runnable::GetTags() {
			return Tags;
		}

		void Runnable::AddInstruction(Instruction *InstructionIn) {
			Instructions.push_back(InstructionIn);
		}

		void Runnable::SetSize(int SizeIn) {
			Size=SizeIn;
		}

		int Runnable::GetSize() {
			return Size;
		}

		void Runnable::SetID(string IDIn) {
			ID=IDIn;
		}

		string Runnable::GetID() {
			return ID;
		}

		void Runnable::Print() { 
			vector<Instruction*>::iterator it;
			int i;
			cout << "Name: " << Name << endl;
			for(i=0,it=Instructions.begin();it!=Instructions.end();++it,i++) {
				cout << "	Instruction no. " << i << ": ";
				(*it)->Print();
				cout << endl;
			}

		}

		bool Runnable::CheckIfIncludesExecutionCyclesDeviationInstruction() {
			bool result=false;
			vector<Instruction*>::iterator it;
			for(it=Instructions.begin();it!=Instructions.end();++it) {
				if(dynamic_cast<ExecutionCyclesDeviationInstruction*>(*it)!=NULL) {
					result=true;
					break;
				}
			}
			return result;
		}

		int Runnable::GetWCETInTick() {
			vector<Instruction*>::iterator it;
			int nWCET=0;
			for(it=Instructions.begin();it!=Instructions.end();++it) {
				if((dynamic_cast<ExecutionCyclesDeviationInstruction*>(*it))!=NULL) {
					nWCET+=static_cast<int>((dynamic_cast<ExecutionCyclesDeviationInstruction*>(*it))->GetUpperBound());
				}
				else if((dynamic_cast<ExecutionCyclesConstantInstruction*>(*it))!=NULL) {
					nWCET+=static_cast<int>((dynamic_cast<ExecutionCyclesConstantInstruction*>(*it))->GetValue());
				}
			}
			return nWCET;
		}

		int Runnable::GetBCETInTick() {
			vector<Instruction*>::iterator it;
			int nBCET=0;
			for(it=Instructions.begin();it!=Instructions.end();++it) {
				if((dynamic_cast<ExecutionCyclesDeviationInstruction*>(*it))!=NULL) {
					nBCET+=static_cast<int>((dynamic_cast<ExecutionCyclesDeviationInstruction*>(*it))->GetLowerBound());
				}
				else if((dynamic_cast<ExecutionCyclesConstantInstruction*>(*it))!=NULL) {
					nBCET+=static_cast<int>((dynamic_cast<ExecutionCyclesConstantInstruction*>(*it))->GetValue());
				}
			}
			return nBCET;
		}



		string Runnable::GetTheFirstDeviationType() {
			vector<Instruction*>::iterator it;
			for(it=Instructions.begin();it!=Instructions.end();++it) {
				if((dynamic_cast<ExecutionCyclesDeviationInstruction*>(*it))!=NULL) {
					return (dynamic_cast<ExecutionCyclesDeviationInstruction*>(*it))->GetType();
				}
			}
			return "";
		}

		double Runnable::GetTheFirstDeviationRemainPromille() {
			vector<Instruction*>::iterator it;
			for(it=Instructions.begin();it!=Instructions.end();++it) {
				if((dynamic_cast<ExecutionCyclesDeviationInstruction*>(*it))!=NULL) {
					if((dynamic_cast<ExecutionCyclesDeviationInstruction*>(*it))->GetRemainPromilleValid()) {
						return (dynamic_cast<ExecutionCyclesDeviationInstruction*>(*it))->GetRemainPromille();
					}
					else {
						return 0.0;
					}
				}
			}
			return 0.0;
		}

		int Runnable::GetTheFirstDeviationLowerBound() {
			vector<Instruction*>::iterator it;
			for(it=Instructions.begin();it!=Instructions.end();++it) {
				if((dynamic_cast<ExecutionCyclesDeviationInstruction*>(*it))!=NULL) {
					if((dynamic_cast<ExecutionCyclesDeviationInstruction*>(*it))->GetLowerBoundValid()) {
						return static_cast<int>((dynamic_cast<ExecutionCyclesDeviationInstruction*>(*it))->GetLowerBound());
					}
					else {
						return 0;
					}
				}
			}
			return 0;
		}

		int Runnable::GetTheFirstDeviationUpperBound() {
			vector<Instruction*>::iterator it;
			for(it=Instructions.begin();it!=Instructions.end();++it) {
				if((dynamic_cast<ExecutionCyclesDeviationInstruction*>(*it))!=NULL) {
					if((dynamic_cast<ExecutionCyclesDeviationInstruction*>(*it))->GetUpperBoundValid()) {
						return static_cast<int>((dynamic_cast<ExecutionCyclesDeviationInstruction*>(*it))->GetUpperBound());
					}
					else {
						return 0;
					}
				}
			}
			return 0;
		}

		int Runnable::GetTheFirstDeviationMean() {
			vector<Instruction*>::iterator it;
			for(it=Instructions.begin();it!=Instructions.end();++it) {
				if((dynamic_cast<ExecutionCyclesDeviationInstruction*>(*it))!=NULL) {
					if((dynamic_cast<ExecutionCyclesDeviationInstruction*>(*it))->GetMeanValid()) {
						return static_cast<int>((dynamic_cast<ExecutionCyclesDeviationInstruction*>(*it))->GetMean());
					}
					else {
						return 0;
					}
				}
			}
			return 0;
		}

		double Runnable::GetTheFirstDeviationStandardDeviation() {
			vector<Instruction*>::iterator it;
			for(it=Instructions.begin();it!=Instructions.end();++it) {
				if((dynamic_cast<ExecutionCyclesDeviationInstruction*>(*it))!=NULL) {
					if((dynamic_cast<ExecutionCyclesDeviationInstruction*>(*it))->GetSDValid()) {
						return (dynamic_cast<ExecutionCyclesDeviationInstruction*>(*it))->GetSD();
					}
					else {
						return 0.0;
					}
				}
			}
			return 0.0;
		}

		int Runnable::GetNoOfInstructions() {
			return Instructions.size();
		}

		string Runnable::GetNameOfInstruction(int Index) {
			return Instructions[Index]->GetName();
		}

		string Runnable::GetLabelNameOfLabelAccessInstruction(int Index) {
			return (dynamic_cast<RemoteAccessInstruction*>(Instructions[Index]))->GetLabel()->GetName();
		}

		bool Runnable::CheckIfWriteAccessInstruction(int Index) {
			return (dynamic_cast<RemoteAccessInstruction*>(Instructions[Index]))->GetWrite();
		}



}
