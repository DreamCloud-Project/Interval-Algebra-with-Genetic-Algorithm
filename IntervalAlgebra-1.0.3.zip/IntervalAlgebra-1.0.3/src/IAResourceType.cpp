#include "IAResourceType.h"
#include <algorithm>
#include <utility>

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

namespace IntervalAlgebra
{
		IAResourceType::IAResourceType(string NameIn): Name_(NameIn), DynamicEnergyMultiplierPerClockCycle_(0), SwitchingPModeTimePenalty(0.0), SwitchingPModeEnergyPenalty (0.0), MaxFrequencyInHz_(1) {
		}

		IAResourceType::IAResourceType(IAResourceType &IResourceNameIn) {

			Name_=IResourceNameIn.GetName();
			DynamicEnergyMultiplierPerClockCycle_=IResourceNameIn.GetDynamicEnergyMultiplierPerClockCycle();
			SwitchingPModeTimePenalty=IResourceNameIn.GetSwitchingPModeTimePenalty();
			SwitchingPModeEnergyPenalty=IResourceNameIn.GetSwitchingPModeEnergyPenalty();
		}


		void IAResourceType::SetName(string NameIn) {
			Name_=NameIn;
		}

		string IAResourceType::GetName() {
			return Name_;
		}



		void IAResourceType::SetDynamicEnergyMultiplierPerClockCycle(double EnergyMultiplierIn) {
			DynamicEnergyMultiplierPerClockCycle_=EnergyMultiplierIn;
		}

		double IAResourceType::GetDynamicEnergyMultiplierPerClockCycle() {
			return DynamicEnergyMultiplierPerClockCycle_;
		}


		int IAResourceType::GetNoOfDVFSLevels() {
			return VoltageFrequencyList.size();
		}

		void IAResourceType::SortVoltageFrequencyListDescending() {
			VoltageFrequencyList.sort(
				[] (const pair<double,double> &a, const pair<double,double> &b ) { return a.second > b.second; } );
		}

		void IAResourceType::AddVoltageFrequencyLevel(double Voltage, double Frequency) {
			VoltageFrequencyList.push_back(pair<double,double>(Voltage,Frequency));
			SortVoltageFrequencyListDescending();
		}

		double IAResourceType::GetSwitchingPModeTimePenalty() {
			return SwitchingPModeTimePenalty;
		}

		double IAResourceType::GetSwitchingPModeEnergyPenalty() {
			return SwitchingPModeEnergyPenalty;
		}

		void IAResourceType::SetSwitchingPModeTimePenalty(double SwitchingPModeTimePenaltyIn) {
			SwitchingPModeTimePenalty=SwitchingPModeTimePenaltyIn;
		}

		void IAResourceType::SetSwitchingPModeEnergyPenalty(double SwitchingPModeEnergyPenaltyIn) {
			SwitchingPModeEnergyPenalty=SwitchingPModeEnergyPenaltyIn;
		}

		double IAResourceType::GetDVFSFrequencyLevel(int LevelIn) {
			double result=1.0;
			if(LevelIn<VoltageFrequencyList.size()) {
				list<pair<double,double> >::iterator it = VoltageFrequencyList.begin();
				advance(it, LevelIn);
				result=(*it).second;
			}
			return result;
		}

		double IAResourceType::GetDVFSVoltageLevel(int LevelIn) {
			double result=1.0;
			if(LevelIn<VoltageFrequencyList.size()) {
				list<pair<double,double> >::iterator it = VoltageFrequencyList.begin();
				advance(it, LevelIn);
				result=(*it).first;
			}
			return result;
		}

		void IAResourceType::SetMaxFrequencyInHz(int MaxFrequencyInHzIn) {
			MaxFrequencyInHz_=MaxFrequencyInHzIn;
		}

		int IAResourceType::GetMaxFrequencyInHz() {
			return MaxFrequencyInHz_;
		}


}
