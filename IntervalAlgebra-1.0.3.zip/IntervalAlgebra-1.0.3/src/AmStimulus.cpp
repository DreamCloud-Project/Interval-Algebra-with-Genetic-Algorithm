#include "AmStimulus.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

namespace IntervalAlgebra
{
		Stimulus::Stimulus(string NameIn): Name(NameIn) {
		}

		void Stimulus::SetName(string NameIn) {
			Name=NameIn;
		}

		string Stimulus::GetName() {
			return Name;
		}

		void Stimulus::SetID(string IDIn) {
			ID=IDIn;
		}

		string Stimulus::GetID() {
			return ID;
		}


		void Stimulus::SetRecurrence(pair<int,string> RecurrenceIn) {
			Recurrence=RecurrenceIn;
		}

		void Stimulus::SetOffset(pair<int,string> OffsetIn) {
			Offset=OffsetIn;
		}

		pair<int,string> Stimulus::GetRecurrence() {
			return Recurrence;
		}

		pair<int,string> Stimulus::GetOffset() {
			return Offset;
		}

		void Stimulus::Print() {
			cout << " Name: " << Name << " Value: " << Recurrence.first << Recurrence.second;
		}

		void Stimulus::AddSource(Task* TaskIn){
			Sources.push_back(TaskIn);
		}

		void Stimulus::AddDestination(Task* TaskIn){
			Destinations.push_back(TaskIn);
		}

		int Stimulus::GetNoOfSources(){
			return Sources.size();
		}

		int Stimulus::GetNoOfDestinations(){
			return Destinations.size();
		}

		Task* Stimulus::GetSource(int Index){
			return Sources.at(Index);
		}

		Task* Stimulus::GetDestination(int Index){
			return Destinations.at(Index);
		}

		Job* Stimulus::GetSourceJob(int Index) {
			return SourcesJob.at(Index);
		}

		Job* Stimulus::GetDestinationJob(int Index){
			return DestinationsJob.at(Index);
		}

		void Stimulus::AddSourceJob(Job* JobIn){
			SourcesJob.push_back(JobIn);
		}

		void Stimulus::AddDestinationJob(Job* JobIn){
			DestinationsJob.push_back(JobIn);
		}

		int Stimulus::GetNoOfSourcesJob(){
			return SourcesJob.size();
		}

		int Stimulus::GetNoOfDestinationsJob(){
			return DestinationsJob.size();
		}

		bool Stimulus::IsTaskInSources(Task *TaskIn) {
			vector<Task*>::iterator p;
			if((p = find(Sources.begin(),Sources.end(),TaskIn))!=Sources.end()) {
				return true;
			}
			return false;
		}

		bool Stimulus::IsTaskInDestinations(Task *TaskIn) {
			vector<Task*>::iterator p;
			if((p = find(Destinations.begin(),Destinations.end(),TaskIn))!=Destinations.end()) {
				return true;
			}
			return false;
		}

		void Stimulus::ClearSourceJobs() {
			SourcesJob.clear();
		}

		void Stimulus::ClearDestinationJobs() {
			DestinationsJob.clear();
		}



}
