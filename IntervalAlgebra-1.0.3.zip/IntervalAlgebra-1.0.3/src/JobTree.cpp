#include "JobTree.h"
#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

namespace IntervalAlgebra
{

	JobTree::~JobTree() {
		Tree->RemoveFromThisNode();
	}

	void JobTree::AddRoot(Job *Root) {
		TreeNode *jtnRoot = new TreeNode;
		AllTreeNodes.push_back(jtnRoot);
		mapJob_TreeNode[Root]=jtnRoot;
		JobTreeNode *RootNode = new JobTreeNode(Root);
		jtnRoot->t=RootNode;
		Tree=jtnRoot;
	}

	JobTreeNode* JobTree::GetRoot() {
		return Tree->t;
	}

	TreeNode* JobTree::GetRootTreeNode() {
		return Tree;
	}


	vector<TreeNode*>* JobTree::GetChildren(TreeNode *StartNode, Job *JobIn) {
		if(StartNode==NULL) return NULL;

		if(StartNode->t->GetJobA()==JobIn) {
			return &StartNode->children;
		}
		TreeNode *b;
		vector<TreeNode*>* val;
		vector<TreeNode* >::iterator it;
		for (it = StartNode->children.begin(); it!= StartNode->children.end(); ++it) {
			b=*it;
			if(GetChildren(b,JobIn) !=NULL) {
				val=GetChildren(b,JobIn);
				return val;
			}
		
		}
		return NULL;


	}

	JobTreeNode* JobTree::FindNode(TreeNode *StartNode, Job *JobIn) {
		
			if(StartNode==NULL) return NULL;
			TreeNode *result;
			try {
				 result = mapJob_TreeNode.at(JobIn);			
				 return result->t;
			}
			catch (...) {
				return NULL;
			}

	}




	void JobTree::AddChildrenToEachParent(JobTreeNode* JobTreeNodeIn,int Iteration) {

		TreeNode *CurrentNode = new TreeNode;
		CurrentNode->t=JobTreeNodeIn;
		AllTreeNodes.push_back(CurrentNode);
		mapJob_TreeNode[JobTreeNodeIn->GetJobA()]=CurrentNode;
		
		Tree->AddChildrenToEachParent(CurrentNode,Iteration);
	}

	void JobTree::BuildTreeFromRoot(list<Job*> *Jobs) {
//DetermineDependencyLevel shall be run before
		list<Job*>::iterator it;
		JobTreeNode* jtnTmp;
		int AddedNodes=0;
		int CurrentLevel=this->GetRoot()->GetJobA()->GetDependencyLevel()-1;
		int NodesToBeAdded=Jobs->size();
		int Iteration=0;
		while(AddedNodes<NodesToBeAdded-1) {
			for (it = Jobs->begin(); it!= Jobs->end(); ++it) {
				if((*it)->GetDependencyLevel()==CurrentLevel) {
					jtnTmp = new JobTreeNode(*it);
					AddChildrenToEachParent(jtnTmp,Iteration);
					AddedNodes++;
					Iteration++;
				}
			}
			CurrentLevel--;
		}
	}




	void JobTree::Display(int level, TreeNode *CurrentNode) {
		
		
		vector<TreeNode*> ::iterator it;
		int i=0;
		for (it = CurrentNode->children.begin(); it!= CurrentNode->children.end(); ++it,++i) {
			cout << " Level: " << level << ", Node: " << i <<", " << (*it)->t->GetJobA()->GetName();
			Display(level+1, *it);
			}
		
	}

	void JobTree::DisplayFromRoot() {
		TreeNode *RootNode;
		RootNode=this->Tree;
		JobTree	*CurrentNode;
		vector<TreeNode*> ::iterator it;
		CurrentNode=this;
		int i=0,level=0;
		cout << " Level: " << level << ", Node: " << i <<", " << CurrentNode->Tree->t->GetJobA()->GetName();

		level++;
		for (it = CurrentNode->Tree->children.begin(); it!= CurrentNode->Tree->children.end(); ++it,++i) {
			cout << " Level: " << level << ", Node: " << i <<", " << (*it)->t->GetJobA()->GetName();
			Display(level+1, *it);
			}
		}

		Job* JobTree::FindTheEarliestReadyJobButNotOriginatedFrom(string OriginalIDOfthePreviousJobID,Job* JobIn,int iteration) {
			return this->Tree->FindTheEarliestReadyJobButNotOriginatedFrom(this->Tree,OriginalIDOfthePreviousJobID);
		}

		Job* JobTree::FindTheEarliestReadyJob(Job* JobIn,int iteration) {
			return this->Tree->FindTheEarliestReadyJob(this->Tree, NULL, iteration);
		}

		Job* JobTree::FindTheEarliestReadyJobForCore(IAResource* CoreIn,Job* JobIn,int iteration) {
			return this->Tree->FindTheEarliestReadyJobForCore(this->Tree, NULL, CoreIn,iteration);
		}


		Job* JobTree::FindTheEarliestReadyJobOfTheHighestPriority(Time *CurrentTime, Job* JobIn,int iteration) {
			return this->Tree->FindTheEarliestReadyJobOfTheHighestPriority(this->Tree,CurrentTime,NULL,0,iteration);
		}

		Job* JobTree::FindTheEarliestReadyJobOfTheHighestPriorityForCore(Time *CurrentTime, Job* JobIn,IAResource* CoreIn, int iteration) {
			return this->Tree->FindTheEarliestReadyJobOfTheHighestPriorityForCore(this->Tree,CurrentTime,NULL,0,CoreIn,iteration);
		}

		Job* JobTree::FindTheEarliestReadyJobOfTheHighestPriorityAndPriorityHigherThan(Job* JobIn,int iteration) {
			return this->Tree->FindTheEarliestReadyJobOfTheHighestPriorityAndPriorityHigherThan(this->Tree,JobIn,NULL,0,iteration);
		}

		Job* JobTree::FindTheEarliestReadyJobOfTheHighestPriorityAndPriorityHigherThanForCore(Job* JobIn,IAResource* CoreIn,int iteration) {
			return this->Tree->FindTheEarliestReadyJobOfTheHighestPriorityAndPriorityHigherThanForCore(this->Tree,JobIn,CoreIn,NULL,0,iteration);
		}


		Time* JobTree::DetermineStartTime(Job* JobIn) {
			Time *TheLatestEndTimeOfChildren;
			Time *TheEarliestNonAllocatedTime;
			if(JobIn->IsStartingJob()) {
				return JobIn->GetReleaseTime();
			}
			TheLatestEndTimeOfChildren=this->Tree->DetermineTheLatestEndTimeOfChildren(Tree,JobIn);

			TheEarliestNonAllocatedTime=DetermineTheEarliestNonAllocatedTimeForExecutingCores(JobIn);


			if(TheLatestEndTimeOfChildren!=NULL && (TheEarliestNonAllocatedTime==NULL || *TheLatestEndTimeOfChildren>*TheEarliestNonAllocatedTime)) {
				if(*JobIn->GetReleaseTime()>*TheLatestEndTimeOfChildren) {
					return JobIn->GetReleaseTime();
				}
				else {
					return TheLatestEndTimeOfChildren;
				}
			}
			else {
				if(TheEarliestNonAllocatedTime==NULL || *JobIn->GetReleaseTime()>*TheEarliestNonAllocatedTime) {
					return JobIn->GetReleaseTime(); 
				}
				else {
					return TheEarliestNonAllocatedTime;
				}
			}

		}


		Time* JobTree::DetermineTheEarliestNonAllocatedTimeForExecutingCores(Job* JobIn) {
			return Tree->DetermineTheEarliestNonAllocatedTimeForExecutingCores(this->Tree,JobIn);
		}


		Time* JobTree::DetermineTheEarliestNonAllocatedTimeForCore(IAResource *CoreIn) {
			Time *result;
			result=Tree->DetermineTheEarliestNonAllocatedTimeForCore(this->Tree,CoreIn);

			return result;
		}



		void JobTree::ChangeAllChildReferencesFromNode(TreeNode* FromWhichNode, Job* ExisitngJob, TreeNode* ReplaceTo) {
			vector<TreeNode*> ::iterator it;
			for (it = FromWhichNode->children.begin(); it != FromWhichNode->children.end(); ++it) {
				if ((*it)->t->GetJobA()->GetName() == ExisitngJob->GetName()) {
					FromWhichNode->children.erase(it);
					FromWhichNode->AddChildren(ReplaceTo);
					break;
				}
			}
			for (it = FromWhichNode->children.begin(); it != FromWhichNode->children.end(); ++it) {
				ChangeAllChildReferencesFromNode((*it), ExisitngJob, ReplaceTo);
			}

		}

		void JobTree::ChangeAllChildReferencesFromRoot(Job* ExisitngJob, TreeNode* ReplaceTo) {
			ChangeAllChildReferencesFromNode(this->Tree, ExisitngJob, ReplaceTo);
		}

		void JobTree::ReplaceNodesFromRoot(TreeNode* ReplaceFrom, TreeNode* ReplaceTo,int iteration) {
			ReplaceNodesFromFromNode(this->Tree, ReplaceFrom, ReplaceTo, iteration);
		}

		void JobTree::ReplaceNodesFromFromNode(TreeNode* FromWhichNode, TreeNode* ReplaceFrom, TreeNode* ReplaceTo,int iteration) {
			vector<TreeNode*> ::iterator it;
			FromWhichNode->VisitedAtIteration=iteration;
			for (it = FromWhichNode->children.begin(); it != FromWhichNode->children.end(); ++it) {
				if ((*it)->t->GetJobA()->GetName() == ReplaceFrom->t->GetJobA()->GetName()) {

					if((*it)->t->GetJobA()->GetName()!="Start") {
						FromWhichNode->children.erase(it);
					}
					FromWhichNode->AddChildren(ReplaceTo);
					break;
				}
			}
			for (it = FromWhichNode->children.begin(); it != FromWhichNode->children.end(); ++it) {
				if((*it)->VisitedAtIteration!=iteration) {
					if ((*it)->t->GetJobA()->GetName() != ReplaceTo->t->GetJobA()->GetName()) {
						ReplaceNodesFromFromNode((*it), ReplaceFrom, ReplaceTo,iteration);
					}
				}
			}

		}


		TreeNode* JobTree::FindTreeNode(TreeNode *StartNode, Job *JobIn) {
			if(StartNode==NULL) return NULL;

			try {
				return mapJob_TreeNode.at(JobIn);
			}
			catch (...) {
				return NULL;
			}
		}

		void JobTree::AddNodeAsAParentTo(Job* NewParentJob,Job* ExisitngJob,int iteration) {
			TreeNode *NewParentTreeNode = new TreeNode();
			AllTreeNodes.push_back(NewParentTreeNode);
			mapJob_TreeNode[NewParentJob]=NewParentTreeNode;
			JobTreeNode *NewParentNode = new JobTreeNode(NewParentJob);
			NewParentTreeNode->t=NewParentNode;
			JobTreeNode *ExisitngJobTreeNode;
			ExisitngJobTreeNode = FindNode(this->Tree, ExisitngJob);

			TreeNode *ExisitngTreeNode;
			ExisitngTreeNode = FindTreeNode(this->Tree, ExisitngJob);
			NewParentTreeNode->AddChildren(ExisitngTreeNode);
			ReplaceNodesFromRoot(ExisitngTreeNode,NewParentTreeNode,iteration);

		}

		Time* JobTree::GetReadyTime(Job* JobIn) {
			return Tree->GetReadyTime(Tree,JobIn);
		}



		void JobTree::AddNodeAsAChildTo(Job* NewChildJob,Job* ExisitngJob) {
			TreeNode *NewChildTreeNode = new TreeNode();
			AllTreeNodes.push_back(NewChildTreeNode);
			mapJob_TreeNode[NewChildJob]=NewChildTreeNode;
			JobTreeNode *NewChildNode = new JobTreeNode(NewChildJob);
			NewChildTreeNode->t=NewChildNode;
			JobTreeNode *ExisitngJobTreeNode;
			ExisitngJobTreeNode = FindNode(this->Tree, ExisitngJob);
			TreeNode *ExistingTreeNode=FindTreeNode(this->Tree,ExisitngJob);
			NewChildTreeNode->CopyChildrenFrom(ExistingTreeNode);
			ExistingTreeNode->ClearChildren();

			TreeNode *ExisitngTreeNode;
			ExisitngTreeNode = FindTreeNode(this->Tree, ExisitngJob);
			ExisitngTreeNode->AddChildren(NewChildTreeNode);

		}



		void JobTree::FillListOfChildren(list<Job*>* ChildrenListIn,Job *JobIn) {
			vector<TreeNode*> ::iterator it;
			TreeNode* FromWhichNode=FindTreeNode(this->Tree,JobIn);
			for (it = FromWhichNode->children.begin() ;it!=FromWhichNode->children.end() ; ++it) {
				ChildrenListIn->push_back((*it)->t->GetJobA());
			}

		}

		void JobTree::FillListOfParents(list<Job*>* ParentsListIn,Job *JobIn) {
			vector<TreeNode*> ::iterator it;
			TreeNode* FromWhichNode=FindTreeNode(this->Tree,JobIn);
			for (it = FromWhichNode->children.begin() ;it!=FromWhichNode->children.end() ; ++it) {
				ParentsListIn->push_back((*it)->t->GetJobA());
			}

		}

		Job* JobTree::FindJobExecutedByCoreAtTime(IAResource *CoreIn,Time* TimeIn,int iteration) {
			return this->Tree->FindJobExecutedByCoreAtTime(this->Tree,NULL,CoreIn,TimeIn,iteration);

		}

		void JobTree::RemoveJustAddedNode(TreeNode* ToBeRemoved) {
			TreeNode *RootTreeNode=GetRootTreeNode();
			vector<TreeNode*>::iterator itchildren;
			RootTreeNode->children.erase(remove(RootTreeNode->children.begin(), RootTreeNode->children.end(), ToBeRemoved), RootTreeNode->children.end());
			delete ToBeRemoved->t;
			delete ToBeRemoved;

		}


}

