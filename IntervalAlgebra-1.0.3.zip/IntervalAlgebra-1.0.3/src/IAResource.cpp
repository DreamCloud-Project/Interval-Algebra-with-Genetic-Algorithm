#include "IAResource.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

namespace IntervalAlgebra
{
		IAResource::IAResource(string NameIn): Name_(NameIn), ResourceType_(NULL),CurrentPMode_(0),NoOfPModeChanges_(0), IsIdle_(false) {
			StaticEnergyPerTimeUnit_=pair<double,TimeUnit>(0,ms);
		}

		IAResource::~IAResource() {
			delete ResourceType_;
		}


		void IAResource::SetName(string NameIn) {
			Name_=NameIn;
		}

		string IAResource::GetName() {
			return Name_;
		}

		void IAResource::SetResourceType(IAResourceType *ResourceTypeIn) {
			if(ResourceType_!=NULL) {
				delete 	ResourceType_;
				ResourceType_=NULL;
			}
			ResourceType_=new IAResourceType(*ResourceType_);
		}

		IAResourceType* IAResource::GetResourceType() {
			if(ResourceType_==NULL) {
				ResourceType_=new IAResourceType(Name_);
			}
			return ResourceType_;
		}

		void IAResource::SetResourceType(string ResourceTypeNameIn) {
			ResourceType_=new IAResourceType(ResourceTypeNameIn);
		}


		void IAResource::SetDynamicEnergyMultiplierPerClockCycle(double EnergyMultiplierIn) {
			if(ResourceType_==NULL) {
				ResourceType_=new IAResourceType(Name_);
			}
			ResourceType_->SetDynamicEnergyMultiplierPerClockCycle(EnergyMultiplierIn);
		}

		double IAResource::GetDynamicEnergyMultiplierPerClockCycle() {
			if(ResourceType_==NULL) {
				ResourceType_=new IAResourceType(Name_);
			}
			return ResourceType_->GetDynamicEnergyMultiplierPerClockCycle();
		}

		double IAResource::GetDynamicEnergyMultiplierPerTimeUnit(TimeUnit UnitIn) {
			double result=0;
			if(ResourceType_==NULL) {
				ResourceType_=new IAResourceType(Name_);
			}
			double DynamicEnergyMultiplierPerClockCycle=ResourceType_->GetDynamicEnergyMultiplierPerClockCycle();

			DynamicEnergyMultiplierPerClockCycle*=GetResourceType()->GetMaxFrequencyInHz();	//in one s
			result=DynamicEnergyMultiplierPerClockCycle;
			if(UnitIn==ms) {
				result/=1000;
			}
			else if(UnitIn==us) {
				result/=1000000;
			}
			else if(UnitIn==ns) {
				result/=1000000000;
			}
			else if(UnitIn==ps) {
				result/=1000000000000;
			}
			else if(UnitIn==fs) {
				result/=1000000000000000;
			}
			return result;
		}



		int IAResource::GetCurrentPMode() {
			if(this==NULL) {
				return 0;
			}
			return CurrentPMode_;
		}

		void IAResource::SetCurrentPMode(int PModeIn) {
			if(PModeIn>=0 && PModeIn<ResourceType_->GetNoOfDVFSLevels()) {
				if(PModeIn!=CurrentPMode_) {
					SetNoOfPModeChanges(GetNoOfPModeChanges()+1);
				}
				CurrentPMode_=PModeIn;
			}
		}

		void IAResource::SetNoOfPModeChanges(int NoOfPModeChangesIn) {
			NoOfPModeChanges_=NoOfPModeChangesIn;
		}

		int IAResource::GetNoOfPModeChanges() {
			return NoOfPModeChanges_;
		}

		double IAResource::GetStaticEnergyPerTimeUnit(TimeUnit UnitIn) {
			TimeUnit MyUnit=StaticEnergyPerTimeUnit_.second;
			double MyValue=StaticEnergyPerTimeUnit_.first;
			while(UnitIn<MyUnit) {
				if(MyUnit==s) {
					MyUnit=ms;
				}
				else if(MyUnit==ms) {
					MyUnit=us;
				}
				else if(MyUnit==us) {
					MyUnit=ns;
				}
				else if(MyUnit==ns) {
					MyUnit=ps;
				}
				else if(MyUnit==ps) {
					MyUnit=fs;
				}
				MyValue/=1000;
			}

			while(UnitIn>MyUnit) {
				if(MyUnit==fs) {
					MyUnit=ps;
				}
				else if(MyUnit==ps) {
					MyUnit=ns;
				}
				else if(MyUnit==ns) {
					MyUnit=us;
				}
				else if(MyUnit==us) {
					MyUnit=ms;
				}
				else if(MyUnit==ms) {
					MyUnit=s;
				}
				MyValue*=1000;
			}
			return MyValue;
		}

		void IAResource::SetStaticEnergyPerTimeUnit(double ValueIn, TimeUnit UnitIn) {
			StaticEnergyPerTimeUnit_=pair<double,TimeUnit>(ValueIn,UnitIn);
		}

		void IAResource::SetIsIdle(bool IsIdleIn) {
			IsIdle_=IsIdleIn;
		}

		bool IAResource::GetIsIdle() {
			return IsIdle_;
		}




}
