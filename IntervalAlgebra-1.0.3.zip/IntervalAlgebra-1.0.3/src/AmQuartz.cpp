#include "AmQuartz.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

namespace IntervalAlgebra
{
		Quartz::Quartz(string NameIn): Name(NameIn), Frequency(0) {
		}

		void Quartz::SetName(string NameIn) {
			Name=NameIn;
		}

		string Quartz::GetName() {
			return Name;
		}

		void Quartz::SetFrequency(int FrequencyIn) {
			Frequency=FrequencyIn;
		}

		int Quartz::GetFrequency() {
			return Frequency;
		}

		void Quartz::SetID(string IDIn) {
			ID=IDIn;
		}

		string Quartz::GetID() {
			return ID;
		}


}
