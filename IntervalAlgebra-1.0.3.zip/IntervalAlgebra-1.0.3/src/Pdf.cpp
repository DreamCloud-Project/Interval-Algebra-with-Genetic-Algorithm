#define _USE_MATH_DEFINES
#include <cmath>

#include "IAException.h"
#include "Pdf.h"


#define DEBUG_NEW new(_NORMAL_BLOCK, THIS_FILE, __LINE__)
#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

namespace IntervalAlgebra
{
	Pdf::Pdf() {
		Threshold=0.5;
	}

	Pdf::~Pdf() {
		for (std::vector<Point*>::iterator it = Points.begin() ; it != Points.end(); ++it) {
			delete *it;
		}
	}

	void Pdf::AddPoint(Point* PointIn) {
		Points.push_back(PointIn);
	}

	double Pdf::ComputeNormal(int X,double Mean, double Variance) {
		return 1/(Variance*sqrt(2*M_PI))*exp(-((X-Mean)*(X-Mean))/(2*Variance));
	}


	double Pdf::ComputeGamma(int X,double Lambda) {
		return Lambda*exp(-Lambda*X);
	}

		double Pdf::ComputeWeibull(double X,double Shape,double Scale) {
		if(X<0) {
			return 0;
		}
		else {
			return Shape/Scale*pow(X/Scale,Shape-1)*exp(-pow(X/Scale,Shape));
		}
	}


	void Pdf::CreateNormalDistribution(int Xmin,int Xmax,double Mean,double Variance) {
		for(int i=Xmin;i<=Xmax;i++) {
			Point *MyPoint;
			MyPoint = new Point(i,ComputeNormal(i-Xmin,Mean,Variance));
			AddPoint(MyPoint);
		}
		Normalize();
	}

	void Pdf::CreateExpDistribution(int Xmin,int Xmax,double Lambda) {
		for(int i=Xmin;i<=Xmax;i++) {
			Point *MyPoint;
			MyPoint = new Point(i,ComputeGamma(i-Xmin,Lambda));
			AddPoint(MyPoint);
		}
		Normalize();
	}

	void Pdf::CreateUniformDistribution(int Xmin,int Xmax) {
		double value=1.0/(Xmax-Xmin+1);
		for(int x=Xmin;x<=Xmax;x++) {
			Point *MyPoint;
			MyPoint = new Point(x,value);
			AddPoint(MyPoint);
		}
	}


	void Pdf::CreateWeibullDistribution(int Xmin,int Xmax,double Remain) {
		Remain/=1000;	//since in permille
		Remain=1-Remain;
		double p1=0.01;	//low probability value - P(X<lowerbound)=p1
		double Shape=(log(-log(1-Remain))-log(-log(1-p1)))/(log(Xmax-Xmin)-log(1));
		double Scale=Xmin/pow((-log(1-p1)),(1/Shape));

		CreateWeibullDistribution(Xmin,Xmax,Shape,Scale);
	}

	void Pdf::CreateWeibullDistribution(int Xmin,int Xmax,double Shape, double Scale) {
			for(int i=Xmin;i<=Xmax;i++) {
			Point *MyPoint;
			MyPoint = new Point(i+Xmin,ComputeWeibull(i-Xmin,Shape,Scale));
			AddPoint(MyPoint);
		}
		Normalize();
	}


	void Pdf::Print() {
		for (std::vector<Point*>::iterator it = Points.begin() ; it != Points.end(); ++it) {
			(*it)->Print();
		}
	}

	int Pdf::GetMinX() {
		return  static_cast<int>((*Points.begin())->GetX());
	}

	int Pdf::GetMaxX() {

	try {
		if(Points.size()<=0) {
		   throw NoElementInPDF;
		}

	}
		catch(exception &e) {
			cout << "Error: " << e.what() << endl;
			cout << "Required max of PDF, Size of PDF:"<< Points.size() << endl;
			cin.get();
			exit(-1);
		}

		return  static_cast<int>((*(--Points.end()))->GetX());
	}

	int Pdf::GetLength() {
		return Points.size();
	}

	double Pdf::GetValueNo(int ElementNo) {
		return (*Points.at(ElementNo)).GetY();
	}

	double Pdf::GetValueOfX(int XIn) {
		double result = 0.0;
		if (XIn<GetMinX() || XIn>GetMaxX()) {
			return result;
		}

		for (std::vector<Point*>::iterator it = Points.begin() ; it != Points.end(); ++it) {
			if((*it)->GetX()==XIn) {
				result=(*it)->GetY();
				return result;
			}
		}
		return result;
	}

	int min(int a, int b) {
		return a < b ? a : b;
	}

	int max(int a, int b) {
		return a > b ? a : b;
	}

	void Pdf::ClearPdf() {
		Points.clear();

	}

	void Pdf::Convolute(Pdf *Pdf1, Pdf *Pdf2) {
		ClearPdf();

		for (int n = Pdf1->GetMinX() + Pdf2->GetMinX(); n<Pdf1->GetMaxX() + Pdf2->GetMaxX() + 1; n++) {
			double ConvolutionValue=0.0;

			for (int k = 0; k < Pdf1->GetMaxX() + Pdf2->GetMaxX(); k++) {
				ConvolutionValue += Pdf2->GetValueOfX(k) * Pdf1->GetValueOfX(n - k);
			}

			Point *MyPoint;
			MyPoint=new Point(n,ConvolutionValue);
			AddPoint(MyPoint);
		}


	}

	double Pdf::GetSumOfAllValues() {
		double result=0.0;
		for (std::vector<Point*>::iterator it = Points.begin() ; it != Points.end(); ++it) {
			result+=(*it)->GetY();
		}
		return result;
	}

	void Pdf::Normalize() {
		double SumOfAllValues=GetSumOfAllValues();
		for (std::vector<Point*>::iterator it = Points.begin() ; it != Points.end(); ++it) {
			(*it)->DivideYBy(SumOfAllValues);
		}
	}

	void Pdf::SetThreshold(double ThresholdIn) {
		Threshold=ThresholdIn;
	}
	
	
	double Pdf::GetThreshold() {
		return Threshold;
	}

	int Pdf::GetXAboveThreshold() {
		int result=GetMaxX();
		double sum=0.0;
		for (std::vector<Point*>::iterator it = Points.begin() ; it != Points.end(); ++it) {
			sum+=(*it)->GetY();
			if(sum>=Threshold) {
				result=static_cast<int>((*it)->GetX());
				return result;
			}
		}
		return result;
	}

	int Pdf::GetPointsSize() {
		return Points.size();
	}
	
	Point* Pdf::GetElement(int NoElement) {
	try {
		if(NoElement>=static_cast<int>(Points.size())) {
		   throw NoElementInPDF;
		}

	}
		catch(exception &e) {
			cout << "Error: " << e.what() << endl;
			cout << "Required no. of element: " << NoElement << ", Maximum element: " << Points.size() << endl;
			cin.get();
			exit(-1);
		}

		return Points[NoElement];
	}



	void Pdf::AddConstant(Pdf* PdfIn,unsigned long long ConstantIn) {
		for (int i=0;i<PdfIn->GetPointsSize();i++) {
			Point *MyPoint;
			MyPoint = new Point(PdfIn->GetElement(i)->GetX()+ConstantIn,PdfIn->GetElement(i)->GetY());
			AddPoint(MyPoint);
		}

	}



}
