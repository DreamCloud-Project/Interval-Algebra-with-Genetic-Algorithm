#include "TimeStochastic.h"
#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

namespace IntervalAlgebra
{
	TimeStochastic::TimeStochastic(TimeUnit UnitIn) {
		Value = new Pdf();
		Unit=UnitIn;
	}

	TimeStochastic::~TimeStochastic() {
		delete Value;
	}



	void TimeStochastic::CreateExpDistribution(int Xmin,int Xmax,double Lambda) {
		Value->CreateExpDistribution(Xmin,Xmax,Lambda);
	}

	void TimeStochastic::CreateUniformDistribution(int Xmin,int Xmax) {
		Value->CreateUniformDistribution(Xmin,Xmax);
	}

	void TimeStochastic::CreateWeibullDistribution(int Xmin,int Xmax,double Remain) {
		Value->CreateWeibullDistribution(Xmin,Xmax,Remain);
	}

	void TimeStochastic::CreateWeibullDistribution(int Xmin,int Xmax,double Shape, double Scale) {
		Value->CreateWeibullDistribution(Xmin,Xmax,Shape,Scale);
	}

	void TimeStochastic::CreateNormalDistribution(int Xmin,int Xmax,double Mean,double Variance) {
		Value->CreateNormalDistribution(Xmin,Xmax,Mean,Variance);
	}



	void TimeStochastic::SetThreshold(double ThresholdIn) {
		Value->SetThreshold(ThresholdIn);
	}

	double TimeStochastic::GetThreshold() {
		return Value->GetThreshold();
	}

	void TimeStochastic::Convolute(TimeStochastic *Time1, TimeStochastic *Time2) {
		Value->Convolute(Time1->GetPdf(),Time2->GetPdf());
	}

	void TimeStochastic::AddConstantTime(TimeStochastic *t1,TimeDeterministic *t2) {
		if(t1->GetUnit()!=t2->GetUnit()) {
			cerr << "2Unit conversion of time with aleatory variables is unimplemented." << endl;
			exit(1);
		}
		Unit=t1->GetUnit();
		Value->AddConstant(t1->GetPdf(),t2->GetValue());
	}

	void TimeStochastic::SubConstantTime(TimeStochastic *t1,TimeDeterministic *t2) {
		if(t1->GetUnit()!=t2->GetUnit()) {
			cerr << "1Unit conversion of time with aleatory variables is unimplemented." << endl;
			exit(1);
		}
		Unit=t1->GetUnit();
		Value->AddConstant(t1->GetPdf(),-1*t2->GetValue());
	}



	Pdf* TimeStochastic::GetPdf() {
		return Value;
	}


	void TimeStochastic::ConvertTo(TimeUnit TimeUnitIn) {
		cerr << "3Unit conversion of time with aleatory variables is unimplemented." << endl;
		exit(1);

	}

	long long TimeStochastic::GetWorstCaseValue() {
		return Value->GetMaxX();
	}

	long long TimeStochastic::GetBestCaseValue() {
		return Value->GetMinX();
	}

	long long TimeStochastic::GetValueInUnit(TimeUnit TimeUnitIn) {
		return ComputeValueToUnit(GetValue(),Unit,TimeUnitIn);
	}

	long long TimeStochastic::GetWorstCaseValueInUnit(TimeUnit TimeUnitIn) {
		return ComputeValueToUnit(GetWorstCaseValue(),Unit,TimeUnitIn);
	}

	long long TimeStochastic::GetBestCaseValueInUnit(TimeUnit TimeUnitIn) {
		return ComputeValueToUnit(GetBestCaseValue(),Unit,TimeUnitIn);
	}


		const bool TimeStochastic::operator == (Time &t) {
			bool result;
			result=!(*this<t ||*this>t);
			return result;
		}

		const bool TimeStochastic::operator < (Time &t) {

			if(t.GetUnit()!=GetUnit() && t.IsStochastic()) {
				cerr << "3aUnit conversion of time with aleatory variables is unimplemented." << endl;
				exit(1);
			}

			bool result;
			if(t.GetUnit()!=GetUnit()) {
					TimeDeterministic *t3;
					t3=new TimeDeterministic(t.GetValue(),t.GetUnit());
					t3->ConvertTo(GetUnit());
					result = GetValue() < t3->GetValue();
					delete t3;
			}
			else {
				result = GetValue() < t.GetValue();
			}
			return result;
		}
		
		const bool TimeStochastic::operator <= (Time &t) {
			if(t.GetUnit()!=GetUnit() && t.IsStochastic()) {
				cerr << "3aUnit conversion of time with aleatory variables is unimplemented." << endl;
				exit(1);
			}

			bool result;
			if(t.GetUnit()!=GetUnit()) {
					TimeDeterministic *t3;
					t3=new TimeDeterministic(t.GetValue(),t.GetUnit());
					t3->ConvertTo(GetUnit());
					result = GetValue() <= t3->GetValue();
					delete t3;
			}
			else {
				result = GetValue() <= t.GetValue();
			}
			return result;
		}

		const bool TimeStochastic::operator > (Time &t) {
			if(t.GetUnit()!=GetUnit() && t.IsStochastic()) {
				cerr << "3aUnit conversion of time with aleatory variables is unimplemented." << endl;
				exit(1);
			}

			bool result;
			if(t.GetUnit()!=GetUnit()) {
					TimeDeterministic *t3;
					t3=new TimeDeterministic(t.GetValue(),t.GetUnit());
					t3->ConvertTo(GetUnit());
					result = GetValue() > t3->GetValue();
					delete t3;
			}
			else {
				result = GetValue() > t.GetValue();
			}
			return result;
		}

	Time* TimeStochastic::Clone() {
		TimeStochastic *result;
		result=new TimeStochastic();
		result->Unit=Unit;
		result->Value=Value;
		return result;
	}

	void TimeStochastic::MultipleValueByConst(double ConstIn) {
		if(ConstIn!=1.0) {
			cerr << "Multiplication by constant of time with aleatory variables is unimplemented." << endl;
			exit(1);
		}
	}


}
