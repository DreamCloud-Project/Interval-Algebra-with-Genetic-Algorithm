#include "Job.h"
#include "IAException.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif



namespace IntervalAlgebra
{
	Job::Job(string IDin) {
		ID=IDin;
		OriginalID=IDin;
		ReleaseTime=new TimeDeterministic(0);
		Period=new TimeDeterministic(0);
		Deadline=new TimeDeterministic(0);
		DependentOn=new list<Job*>;
		Priority=0;
		AllowedResourcesExecutionTime.clear();
		DependencyLevel=-1;
		StartTime=new TimeDeterministic(0);
		EndTime=new TimeDeterministic(0);
		Ready=false;
		Scheduled=false;
		Slice=0;
	}

	Job::Job(string IDIn, Time *ExecutionTimeIn) {
		ID=IDIn;
		OriginalID=IDIn;
		ReleaseTime=new TimeDeterministic(0);
		Period=new TimeDeterministic(0);
		Deadline=new TimeDeterministic(0);
		Priority=0;
		AllowedResourcesExecutionTime.clear();
		pair<IAResource*, Time*> p(NULL,ExecutionTimeIn);
		AllowedResourcesExecutionTime.push_back(p);
		DependentOn=new list<Job*>;
		DependencyLevel=-1;
		if(ExecutionTimeIn->IsStochastic()) {
			StartTime=new TimeStochastic();
			EndTime=new TimeStochastic();
		}
		else {
			StartTime=new TimeDeterministic(0);
			EndTime=new TimeDeterministic(0);
		}
		Ready=false;
		Scheduled=false;
		Slice=0;
	}


	Job::Job(const Job &JobIn) {
		ID=JobIn.ID;
		OriginalID=JobIn.OriginalID;
		ReleaseTime=JobIn.ReleaseTime->Clone();
		Period=JobIn.Period->Clone();
		Deadline=JobIn.Deadline->Clone();
		DependentOn=new list<Job*>;

		list<Job*>::iterator it;
		for (it = DependentOn->begin() ; it != DependentOn->end(); ++it) {
			DependentOn->push_back(*it);
		}
			
		Priority=JobIn.Priority;
		SetAllowedResourcesExecutionTimeFrom(JobIn);
		DependencyLevel=JobIn.DependencyLevel;
		StartTime=JobIn.StartTime->Clone();
		EndTime=JobIn.EndTime->Clone();
		Ready=JobIn.Ready;
		Scheduled=JobIn.Scheduled;
		Slice=JobIn.Slice;
		
		list<IAResource*>::const_iterator it1;
		for (it1 = JobIn.ExecutingCore.begin() ; it1 != JobIn.ExecutingCore.end(); ++it1) {
			ExecutingCore.push_back(*it1);
		}

		list<int>::const_iterator itPMode;
		for (itPMode = JobIn.PMode.begin() ; itPMode != JobIn.PMode.end(); ++itPMode) {
			PMode.push_back(*itPMode);
		}


	}


	Job::~Job() {
		RemoveTimes();
	}

	void Job::RemoveTimes() {
		delete ReleaseTime;
		delete Period;
		delete Deadline;
		delete DependentOn;
		delete StartTime;
		delete EndTime;
		list<pair<IAResource*, Time*> >::iterator it;
		for (it = AllowedResourcesExecutionTime.begin() ; it != AllowedResourcesExecutionTime.end(); ++it) {
			delete (*it).second;
		}
	}

	string Job::GetName() {
		return ID;
	}

	void Job::SetName(string NameIn) {
		ID=NameIn;
	}

		string Job::GetOriginalName() {
		return OriginalID;
	}

	void Job::SetOriginalName(string NameIn) {
		OriginalID=NameIn;
	}

	unsigned int Job::GetPriority() {
		return Priority;
	}
	
	void Job::SetPriority(unsigned int PriorityIn){
		Priority=PriorityIn;
	}


	void Job::SetDependencyLevel(int Level)
	{
		DependencyLevel=Level;
	}

	int Job::GetDependencyLevel() {
		return DependencyLevel;
	}

	bool Job::IsReady() {
		return CheckIfReadyAndThenSetReady();
	}

	bool Job::GetReadyWithoutComputingIt() {
		return Ready;
	}


	double Job::ComputeUtilisation() {
		if(Deadline==0) {
			return 0; 
		}
		else {
			Time *MyTime=GetExecutionTimeForExecutingResource();
			long long ExecutionTime=MyTime->GetValueInUnit(Deadline->GetUnit());
			delete MyTime;
			return (double)ExecutionTime/Deadline->GetValue();
		}
	}

	bool Job::IsLHSUtilizationHigherThanRHS(Job* lhs, Job* rhs) {
		double UtilisationLhs=lhs->ComputeUtilisation();
		double UtilisationRhs=rhs->ComputeUtilisation();
		return UtilisationLhs>UtilisationRhs;

	}

	bool Job::IsScheduled() {
		return Scheduled;
	}

	void Job::SetScheduled(bool ScheduledIn) {
		Scheduled=ScheduledIn;
	}


	Time* Job::GetReleaseTime() {
		return ReleaseTime;
	}

	Time* Job::GetStartTime() {
		return StartTime;
	}

	Time* Job::GetEndTime() {
		return EndTime;
	}

	double Job::GetDynamicEnergyForResource(IAResource *CoreIn,TimeUnit MyTimeUnit) {
		double result;
		Time *MyTime=GetExecutionTime(CoreIn);
		result=MyTime->GetValueInUnit(MyTimeUnit)*CoreIn->GetDynamicEnergyMultiplierPerClockCycle();
		delete MyTime;
		return result;
	}

	double Job::GetDynamicEnergyForExecutingResourcesAndAllocatedTasks(TimeUnit MyTimeUnit) {
		double result=0.0;
		if(IsScheduled()==false || ExecutingCore.empty()) {
			return result;
		}




		list<IAResource*>::iterator it;
		for(it=ExecutingCore.begin();it!=ExecutingCore.end();++it) {
			double DVFSEnergyMultiplier=1.0;
			double DVFSMaxEnergy=1.0;
					if((*it)->GetCurrentPMode()!=0) {
					DVFSMaxEnergy=(*it)->GetResourceType()->GetDVFSFrequencyLevel(0)*(*it)->GetResourceType()->GetDVFSVoltageLevel(0)*(*it)->GetResourceType()->GetDVFSVoltageLevel(0);
					DVFSEnergyMultiplier=((*it)->GetResourceType()->GetDVFSFrequencyLevel(GetPModeOfResource(*it))*(*it)->GetResourceType()->GetDVFSVoltageLevel(GetPModeOfResource(*it))*(*it)->GetResourceType()->GetDVFSVoltageLevel(GetPModeOfResource(*it)))/DVFSMaxEnergy;
				}
				result+=(EndTime->GetValueInUnit(MyTimeUnit)-StartTime->GetValueInUnit(MyTimeUnit))*(*it)->GetDynamicEnergyMultiplierPerTimeUnit(MyTimeUnit)*DVFSEnergyMultiplier;
		}
		return result;
	}

	void Job::SetReleaseTime(Time* t) {
		delete ReleaseTime;
		ReleaseTime=t;
	}

	void Job::SetPeriod(Time* t) {
		delete Period;
		Period=t;
	}

	Time* Job::GetPeriod() {
		return Period;
	}


	void Job::SetReady(bool ReadyIn) {
		Ready=ReadyIn;
	}


	void Job::SetDependenciesFrom(Job* JobIn) {
		*DependentOn=*JobIn->DependentOn;
	}

	void Job::SetNoOfSlice(int SliceIn) {
		Slice=SliceIn;
	}

	int Job::GetNoOfSlice() {
		return Slice;
	}

	bool Job::DependsDirectlyOn(Job* JobIn) {
		list<Job*>::iterator it;
		bool Found=false;
		for (it = DependentOn->begin() ; !Found && it != DependentOn->end(); ++it) {
			if((*it)->GetName()==JobIn->GetName()) {
				Found=true;
			}
		}

		return Found;
	}


	bool Job::CheckIfReadyAndThenSetReady() {
		if(Ready) {
			return true;
		}
		Ready=true;
		list<Job*>::iterator it;
		for (it = DependentOn->begin() ; Ready && it != DependentOn->end(); ++it) {
			Ready&=(*it)->IsScheduled();
		}
		return Ready;
	}



	Time* Job::GetExecutionTimeForTheFastestResource() {
		if(ExecutingCore.size()<=1) {
			return GetExecutionTimeForExecutingResource();
		}
		else {
			Time *result=GetExecutionTime(*ExecutingCore.begin());
			list<IAResource*>::iterator it;
			for(it=ExecutingCore.begin(),++it;it!=ExecutingCore.end();++it) {
				Time *MyTime=GetExecutionTime(*it);
				if(*result > *MyTime) {
					delete result;
					result=MyTime;
				}
				else {
					delete MyTime;
				}
			}
			return result;
		}
	}



	Time* Job::GetExecutionTimeForTheSlowestResource() {
		if(ExecutingCore.size()<=1) {
			return GetExecutionTimeForExecutingResource();
		}
		else {
			Time *result=GetExecutionTime(*ExecutingCore.begin());
			list<IAResource*>::iterator it;
			for(it=ExecutingCore.begin(),++it;it!=ExecutingCore.end();++it) {
				Time *MyTime=GetExecutionTime(*it);
				if(*result < *MyTime) {
					delete result;
					result=MyTime;
				}
				else {
					delete MyTime;
				}
			}
			return result;
		}
	}



	Time* Job::GetExecutionTime(IAResource* rt) {
		bool Found=false;
		list<pair<IAResource*, Time*> > ::iterator it;
		for (it = AllowedResourcesExecutionTime.begin(); it!= AllowedResourcesExecutionTime.end(); ++it) {
			if((*it).first==rt) {
				double TimeMultiplier=1;
				if(rt!=NULL && (*it).first->GetCurrentPMode()!=0) {
					TimeMultiplier=(*it).first->GetResourceType()->GetDVFSFrequencyLevel(0)/(*it).first->GetResourceType()->GetDVFSFrequencyLevel((*it).first->GetCurrentPMode());
				}
				Time *result=(*it).second->Clone();
				result->MultipleValueByConst(TimeMultiplier);
				return result;
			}
		}

		try {
		   throw NoExecutionTimeForExecutingCore;
		}
		catch(exception &e) {
			cout << "Error: no execution time for executing core" << endl;
			cout << "Task: " << GetName() << ", Executing core: " << rt->GetName() << endl;
			cin.get();
			exit(-1);
		}

		return NULL;
	}



	void Job::SetExecutionTimeForResource(Time* Length,IAResource* rt) {
		list<pair<IAResource*, Time*> > ::iterator it;
		for (it = AllowedResourcesExecutionTime.begin(); it!= AllowedResourcesExecutionTime.end(); ++it) {
			if((*it).first==rt) {
				Time *Time1=(*it).second;
				(*it).second=Length->Clone();
				delete Time1;
				return;
			}
		}
		Time *MyTime=Length->Clone();
		pair<IAResource*, Time*> *p=new pair<IAResource*, Time*>(rt,MyTime);
		AllowedResourcesExecutionTime.push_back(*p);
		delete p;
	}


	void Job::RemoveExecutionTimeForResource(IAResource* rt) {
		list<pair<IAResource*, Time*> > ::iterator it;
		for (it = AllowedResourcesExecutionTime.begin(); it!= AllowedResourcesExecutionTime.end(); ++it) {
			if((*it).first==rt) {
				Time* MyTime=(*it).second;
				AllowedResourcesExecutionTime.remove(*it);
				delete MyTime;
				return;
			}
		}
	}



	void Job::DecreaseExecutionTimeForResourceBy(Time* Length,IAResource* rt) {
		list<pair<IAResource*, Time*> > ::iterator it;
		Time *TimeTmp;
		for (it = AllowedResourcesExecutionTime.begin(); it!= AllowedResourcesExecutionTime.end(); ++it) {
			if((*it).first==rt) {
				TimeTmp=(*it).second;
				(*it).second=Sub(*(*it).second,*Length);
				delete TimeTmp;
				return;
			}
		}
	}


	void Job::SetStartTime(Time *t) {
		if(t!=NULL) {
			delete StartTime;
			StartTime=t->Clone();
		}
	}

	void Job::SetEndTime(Time *t) {
		if(t!=NULL) {
			delete EndTime;
			EndTime=t->Clone();
		}
	}

	void Job::SetStartAndEndTimeForCollapse(Time *tStart, Time *tEnd) {
		SetStartTime(tStart);
		SetEndTime(tEnd);
	}

	void Job::SetStartAndEndTime(Time *t) {
		if(t!=NULL && *ReleaseTime<*t) {
			delete StartTime;
			StartTime=t->Clone();
		}
		else {
			delete StartTime;
			StartTime=ReleaseTime->Clone();
		}

		delete EndTime;
		Time *MyTime=GetExecutionTime(ExecutingCore.size()==0?NULL:*ExecutingCore.begin());
		EndTime=Add(*StartTime,*MyTime);
		delete MyTime;

	}



	void Job::ClearStartAndEndTime() {
		delete StartTime;
		delete EndTime;
		StartTime=new TimeDeterministic(0);
		EndTime=new TimeDeterministic(0);
	}



	void Job::SetAllowedResourcesExecutionTimeFrom(Job const &JobIn) {

		list<pair<IAResource*, Time*> > ::const_iterator  it;
		for (it = JobIn.AllowedResourcesExecutionTime.begin(); it!= JobIn.AllowedResourcesExecutionTime.end(); ++it) {
			pair<IAResource*, Time*> *MyPair = new pair<IAResource*, Time*>;
			MyPair->first=(*it).first;
			MyPair->second=(*it).second->Clone();
			AllowedResourcesExecutionTime.push_back(*MyPair);
			delete MyPair;
		}
	}


	void Job::AddToReleaseTime(Time* TimeIn) {
		Time *TimeTmp;
		TimeTmp=ReleaseTime;
		ReleaseTime=Add(*ReleaseTime,*TimeIn);
		delete TimeTmp;
	}

	void Job::AddToDeadline(Time* TimeIn) {
		Time *TimeTmp;
		TimeTmp=Deadline;
		Deadline=Add(*Deadline,*TimeIn);
		delete TimeTmp;
	}

	void Job::AddDependency(Job *JobIn) {
		DependentOn->push_back(JobIn);
	}

	bool Job::IsPeriodic() {
		if(GetPeriod()->GetValue()==0) {
			return false;
		}
		else {
			return true;
		}
	}


	int Job::GetDependentOnListSize() {
		return DependentOn->size();
	}
	Job* Job::GetDependentOnListElement(int NoElement) {
		Job *result=NULL;
		list<Job*>::iterator it;
		int WhichElement=NoElement;
		for (it = DependentOn->begin() ; it != DependentOn->end(); ++it , WhichElement--) {
			if(WhichElement==0) {
				result=*it;
				return result;
			}
		}
		return result;
	}

	void Job::SetDependentOnListElement(int i,Job *JobIn) {
		list<Job*>::iterator it;
		int WhichElement=i;
		for (it = DependentOn->begin() ; it != DependentOn->end(); ++it , WhichElement--) {
			if(WhichElement==0) {
				*it=JobIn;
				return;
			}
		}
	}


	Job* Job::ExtractPrefix(Time* Length,IAResource* rt) {
		Job* result;
		result=new Job(*this);
		result->SetExecutionTimeForResource(Length,rt);
		return result;
	}

	void Job::RemovePrefix(Time* Length,IAResource* rt) {
		DecreaseExecutionTimeForResourceBy(Length,rt);
		AddToReleaseTime(Length);
	}

	void Job::AddDependencySet(list<Job*> *DepJobs) {
		list<Job*>::iterator it;
		for (it = DepJobs->begin() ; it != DepJobs->end(); ++it ) {
			AddDependency(*it);
		}

	}

	Time* Job::GetDeadline() {
		return Deadline;
	}

	void Job::SetDeadline(Time* TimeIn) {
		if(Deadline!=NULL) {
			delete Deadline;
		}
		Deadline=TimeIn;
	}

	void Job::Display() {
		cout << GetName() << ", Start: " << *GetStartTime() << ", End: " << *GetEndTime() << endl;
	}

	bool Job::IsPeriodicOrSporadic() {
		bool result=false;
		if(Period->GetValue()!=0) {
			result=true;
		}
		return result;
	}

	bool Job::IsStartingJob() {
		bool result=false;
		if(ID=="Start") {
			result=true;
		}
		return result;
	}

	bool Job::IsEndingJob() {
		bool result=false;
		if(ID=="End") {
			result=true;
		}
		return result;
	}

	void Job::AddExecutingCore(IAResource *CoreIn) {
		ExecutingCore.push_back(CoreIn);
		PMode.push_back(CoreIn->GetCurrentPMode());
	}

	IAResource* Job::GetTheFirstExecutingCore() {
		return (ExecutingCore.size()==0?NULL:*ExecutingCore.begin());
	}

	Time* Job::GetExecutionTimeForExecutingResource() {
		return GetExecutionTime(ExecutingCore.size()==0?NULL:*ExecutingCore.begin());
	}

	void Job::SetExecutionTimeForExecutingResource(Time* Length) {
		SetExecutionTimeForResource(Length,ExecutingCore.size()==0?NULL:*ExecutingCore.begin());
	}

	bool Job::CheckIfExecutedByCore(IAResource *CoreIn) {
		if(CoreIn==NULL && ExecutingCore.size()==0) {
			return true;
		}
		else if(find(ExecutingCore.begin(),ExecutingCore.end(),CoreIn)!=ExecutingCore.end()) {
			return true;
		}
		else {
			return false;
		}
	}

	void Job::SetExecutingCores(list<IAResource*>* CoresListIn) {
		ExecutingCore.clear();
		PMode.clear();
		ExecutingCore.insert(ExecutingCore.begin(),CoresListIn->begin(),CoresListIn->end());
		list<IAResource*>::iterator it;
		for(it=ExecutingCore.begin();it!=ExecutingCore.end();++it) {
			PMode.push_back((*it)->GetCurrentPMode());
		}

	}

	list<IAResource*>* Job::GetExecutingCores() {
		return &ExecutingCore;
	}


	void Job::ClearDependencies() {
		DependentOn->clear();
	}

	bool Job::IsDependentOn(Job* JobIn) {
		if(find(DependentOn->begin(),DependentOn->end(),JobIn)!=DependentOn->end()) {
			return true;
		}
		else {
			return false;
		}
	}

	bool Job::CheckIfDeadlineMet() {
		bool result;
		if(Deadline->GetValue()==0) {
			result=true;
		}
		else if(*EndTime<=*Deadline) {
			result=true;
		}
		else {
			result=false;
		}
		return result;
	}


	Time* Job::GetLaxity() {
		if(Deadline->GetValue()==0) {
			return NULL;
		}
		else {
			return Sub(*Deadline,*EndTime);
		}
	}

	void Job::OverwriteTheFirstExecutingCore(IAResource* CoreIn) {
		//can be used only in the hogeneous systems
		if(ExecutingCore.empty()==false) {
			IAResource* CoreOld=ExecutingCore.front();
			Time* ExecutingTime=GetExecutionTime(CoreOld);
			RemoveExecutionTimeForResource(CoreOld);
			ExecutingCore.pop_front();
			ExecutingCore.push_front(CoreIn);
			SetExecutionTimeForResource(ExecutingTime,CoreIn);
			delete ExecutingTime;
		}
	}

	void Job::RemoveExecutingCores(IAResource* CoreIn) {
		IAResource* CoreOld=ExecutingCore.front();
		Time* ExecutingTime=GetExecutionTimeForExecutingResource();
		RemoveExecutionTimeForResource(CoreOld);
		ExecutingCore.clear();
		PMode.clear();
		SetExecutionTimeForExecutingResource(ExecutingTime);
		delete ExecutingTime;
	}

	void Job::ExchangeDependentOnListElement(Job* JobFrom, Job* JobTo) {
		list<Job*>::iterator itDependentOn;
		for(itDependentOn = DependentOn->begin();itDependentOn!=DependentOn->end();++itDependentOn) {
			if(*itDependentOn==JobFrom) {
				*itDependentOn=JobTo;
			}
		}
	}


	int Job::GetPModeOfResource(IAResource* CoreIn) {
		list<IAResource*>::iterator findIter = find(ExecutingCore.begin(), ExecutingCore.end(), CoreIn);
		int index = distance(ExecutingCore.begin(), findIter);
		list<int>::iterator it = PMode.begin();
		advance(it,index);
		return *it;
	}

	void Job::SetPModeOfResource(IAResource* CoreIn,int PModeIn) {
		if(CoreIn==NULL) {
			return;
		}
		list<IAResource*>::iterator findIter = find(ExecutingCore.begin(), ExecutingCore.end(), CoreIn);
		int index = distance(ExecutingCore.begin(), findIter);
		list<int>::iterator it = PMode.begin();
		advance(it,index);
		*it=PModeIn;
	}

	void Job::SetPModeOfExecutingResources() {
			list<IAResource*>::iterator itResource;
			for(itResource=GetExecutingCores()->begin();itResource!=GetExecutingCores()->end();++itResource) {
				SetPModeOfResource(*itResource,(*itResource)->GetCurrentPMode());
			}

	}
}
