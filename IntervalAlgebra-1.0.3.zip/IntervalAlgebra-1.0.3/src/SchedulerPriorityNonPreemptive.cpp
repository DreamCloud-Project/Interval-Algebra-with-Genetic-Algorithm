#include "SchedulerPriorityNonPreemptive.h"
#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

namespace IntervalAlgebra
{

	SchedulerPriorityNonPreemptive::SchedulerPriorityNonPreemptive(): Scheduler() {
		ResetDeadlineCounters();
	}




	

	void SchedulerPriorityNonPreemptive::Schedule() {
		Job *j;

		IAResource *DefaultCore = NULL;
		if(AllCores.empty()) {
			DefaultCore = new IAResource("Default");
			AllCores.push_back(DefaultCore);
			list<Job*>::iterator itJob;
			for(itJob=AllJobs.begin();itJob!=AllJobs.end();++itJob) {
				Time* ExecutionTime=(*itJob)->GetExecutionTimeForExecutingResource();
				(*itJob)->AddExecutingCore(DefaultCore);
				(*itJob)->SetExecutionTimeForResource(ExecutionTime,DefaultCore);
				delete ExecutionTime;
			}
		}


		CurrentTime.reserve(AllCores.size());
		for(unsigned int iCore=0;iCore<AllCores.size();iCore++) {
			CurrentTime.push_back(NULL);
		}

		//start task
		j=jt1->FindTheEarliestReadyJob(NULL,0);
			if(j==NULL) {
				cout << "Error. No start job!"<< endl;
				exit(-1);
			}
		Time *t=jt1->DetermineStartTime(j);
		j->SetStartAndEndTime(t);
		j->SetPModeOfExecutingResources();			
		j->SetScheduled(true);
		int Index=1;

		for(unsigned int i=1;i<AllJobs.size()-1;) {
			int JobsAllocatedInPreviousStep=i;
			for(unsigned int iCore=0;iCore<AllCores.size();iCore++) {


				j=jt1->FindTheEarliestReadyJobOfTheHighestPriorityForCore(CurrentTime.at(iCore),NULL,GetCore(iCore),Index++);
				if(j==NULL) {
					continue;
				}
				i++;

				Time *t=jt1->DetermineStartTime(j);
				j->SetStartAndEndTime(t);



				CurrentTime[iCore]=j->GetEndTime();
				if(*CurrentTime[iCore]<=*j->GetDeadline()) {
					IncreaseBeforeDeadlineCounter();
				}
				else {
					IncreaseAfterDeadlineCounter();
				}


				j->SetPModeOfExecutingResources();			
				j->SetScheduled(true);
				TreeNode* MyRootTreeNode = jt1->GetRootTreeNode();

				list<IAResource*>::iterator it;
				Time* EndTime=j->GetEndTime();
				for(it=j->GetExecutingCores()->begin();it!=j->GetExecutingCores()->end();++it) {
					delete mapCoreTime[*it];
					mapCoreTime[*it]=EndTime->Clone();
				}

				
			}
			if (i==JobsAllocatedInPreviousStep) { //no jobs for the current time, we should look for the next time event
				j=jt1->FindTheEarliestReadyJob(NULL,Index++);
				if(j==NULL) {
					cout << "Error. Job not found!"<< endl;
					exit(-1);
				}
				Time *PossibleStartTime=jt1->DetermineStartTime(j);
				for(unsigned int iCore=0;iCore<AllCores.size();iCore++) {
					if(CurrentTime[iCore]==NULL || *CurrentTime[iCore]<*PossibleStartTime) {
						delete CurrentTime[iCore];
						Time *NewTime=  PossibleStartTime->Clone();
						CurrentTime[iCore] = NewTime;
					}
				}
			}

		}

		j=jt1->FindTheEarliestReadyJob(NULL,0);
			if(j==NULL) {
				cout << "Error. No end job!"<< endl;
				exit(-1);
			}
		t=jt1->DetermineStartTime(j);
		j->SetStartAndEndTime(t);
		j->SetPModeOfExecutingResources();			
		j->SetScheduled(true);

		if(DefaultCore!=NULL) {
			list<Job*>::iterator itJob;
			for(itJob=AllJobs.begin();itJob!=AllJobs.end();++itJob) {
				(*itJob)->RemoveExecutingCores(DefaultCore);
			}
			delete DefaultCore;
		}


	}











}
