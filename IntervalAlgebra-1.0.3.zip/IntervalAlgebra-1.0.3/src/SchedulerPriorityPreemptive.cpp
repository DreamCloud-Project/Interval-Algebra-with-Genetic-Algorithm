#include "SchedulerPriorityPreemptive.h"
#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

namespace IntervalAlgebra
{

	SchedulerPriorityPreemptive::SchedulerPriorityPreemptive() : Scheduler() {
		ResetDeadlineCounters();
	}


	void SchedulerPriorityPreemptive::Preempt(int iCore,Job* j,Time *tPreemption, int &Index) {

					Job *PrefixJob;	
					Time* tTaskLengthBeforePreemption=Sub(*tPreemption,*j->GetStartTime());
					PrefixJob=j->ExtractPrefix(tTaskLengthBeforePreemption,j->GetTheFirstExecutingCore());
					j->RemovePrefix(tTaskLengthBeforePreemption,j->GetTheFirstExecutingCore());
					delete tTaskLengthBeforePreemption;
					string str=string(to_string(PrefixJob->GetNoOfSlice()));
					PrefixJob->SetName(PrefixJob->GetName()+"__$"+str);
					PrefixJob->SetExecutingCores(j->GetExecutingCores());
					j->SetNoOfSlice(PrefixJob->GetNoOfSlice()+1);
					PrefixJob->SetStartAndEndTime(j->GetStartTime());
					PrefixJob->SetPModeOfExecutingResources();			
					PrefixJob->SetScheduled(true);
					CurrentTime[iCore]=PrefixJob->GetEndTime();
					AllJobs.push_front(PrefixJob);

					list<IAResource*>::iterator it;
					Time* EndTime=PrefixJob->GetEndTime();
					for(it=PrefixJob->GetExecutingCores()->begin();it!=PrefixJob->GetExecutingCores()->end();++it) {
						delete mapCoreTime[*it];
						mapCoreTime[*it]=EndTime->Clone();
					}

					jt1->AddNodeAsAChildTo(PrefixJob,j);
	}

	


	void SchedulerPriorityPreemptive::Schedule() {
		Job *j;
		string OriginalIDOfthePreviousJobID="";

		Time *tPreemption;
		Time *TimeTmp;
		IAResource *DefaultCore = NULL;
		if(AllCores.empty()) {
			DefaultCore = new IAResource("Default");
			AllCores.push_back(DefaultCore);
			list<Job*>::iterator itJob;
			for(itJob=AllJobs.begin();itJob!=AllJobs.end();++itJob) {
				Time* ExecutionTime=(*itJob)->GetExecutionTimeForExecutingResource();
				(*itJob)->AddExecutingCore(DefaultCore);
				(*itJob)->SetExecutionTimeForResource(ExecutionTime,DefaultCore);
				delete ExecutionTime;
			}
		}

		list<Job*>::iterator itJobs11;


		CurrentTime.reserve(AllCores.size());
		for(unsigned int iCore=0;iCore<AllCores.size();iCore++) {
			CurrentTime.push_back(NULL);
		}

		//start task
		j=jt1->FindTheEarliestReadyJob(NULL,0);
			if(j==NULL) {
				cout << "Error. No start job!"<< endl;
				exit(-1);
			}
		Time *t=jt1->DetermineStartTime(j);
		j->SetStartAndEndTime(t);
		j->SetPModeOfExecutingResources();			
		j->SetScheduled(true);
		int Index=1;

		for(unsigned int i=1;i<AllJobs.size()-1;) {
			int JobsAllocatedInPreviousStep=i;
			for(unsigned int iCore=0;iCore<AllCores.size();iCore++) {


				j=jt1->FindTheEarliestReadyJobOfTheHighestPriorityForCore(CurrentTime.at(iCore),NULL,GetCore(iCore),Index++);




				if(j==NULL) {
					continue;
				}
				i++;
				t=jt1->DetermineStartTime(j);
				j->SetStartAndEndTime(t);
				tPreemption=DeterminePreemptionTime(j,Index++); 

				TimeTmp=NULL;

				if(tPreemption!=NULL&&CurrentTime.at(iCore)!=NULL && *tPreemption==*CurrentTime.at(iCore)) {
					tPreemption=NULL;

				}
				Time *MyTime=j->GetExecutionTimeForTheSlowestResource();
				if((tPreemption!=NULL&&tPreemption->GetValue()!=0) && (*(TimeTmp=Add(*j->GetStartTime(), *MyTime)) > *tPreemption)) {
					if(TimeTmp!=NULL) {
						delete TimeTmp;
					}






					Preempt(iCore,j,tPreemption, ++Index);
					OriginalIDOfthePreviousJobID=j->GetOriginalName();


				}
				else {
					if(TimeTmp!=NULL) {
						delete TimeTmp;
					}
					j->SetStartAndEndTime(t);

					j->SetPModeOfExecutingResources();			
					j->SetScheduled(true);
					CheckPossiblePreemptions(j,++Index);


					CurrentTime[iCore]=j->GetEndTime();
					if(*CurrentTime[iCore]<=*j->GetDeadline()) {
						IncreaseBeforeDeadlineCounter();
					}
					else {
						IncreaseAfterDeadlineCounter();
					}

					OriginalIDOfthePreviousJobID=j->GetOriginalName();

					list<IAResource*>::iterator it;
					Time* EndTime=j->GetEndTime();
					for(it=j->GetExecutingCores()->begin();it!=j->GetExecutingCores()->end();++it) {
						delete mapCoreTime[*it];
						mapCoreTime[*it]=EndTime->Clone();
					}

				}
				delete MyTime;
			}

			if (i==JobsAllocatedInPreviousStep) { //no jobs for the current time, we should look for the next time event
				j=jt1->FindTheEarliestReadyJob(NULL,Index++);
				if(j==NULL) {
					cout << "Error. Job not found!"<< endl;
					exit(-1);
				}
				Time *PossibleStartTime=jt1->DetermineStartTime(j);
				for(unsigned int iCore=0;iCore<AllCores.size();iCore++) {
					if(CurrentTime[iCore]==NULL || *CurrentTime[iCore]<*PossibleStartTime) {
						delete CurrentTime[iCore];
						Time *NewTime=  PossibleStartTime->Clone();
						CurrentTime[iCore] = NewTime;
					}
				}
			}


		}
//end job
		j=jt1->FindTheEarliestReadyJob(NULL,0);
			if(j==NULL) {
				cout << "Error. No end job!"<< endl;
				exit(-1);
			}
		t=jt1->DetermineStartTime(j);
		j->SetStartAndEndTime(t);
		j->SetPModeOfExecutingResources();			
		j->SetScheduled(true);

		if(DefaultCore!=NULL) {
			list<Job*>::iterator itJob;
			for(itJob=AllJobs.begin();itJob!=AllJobs.end();++itJob) {
				(*itJob)->RemoveExecutingCores(DefaultCore);
			}
			delete DefaultCore;
		}
	}



	void SchedulerPriorityPreemptive::CheckPossiblePreemptions(Job *JustFinishedJob,int &iteration) {
		list<Job*> *ParentTreeNodes = new list<Job*>; //parent in trees, but dependent tasks on the just finished task
		jt1->FillListOfParents(ParentTreeNodes,JustFinishedJob);
		
		 
		pair <multimap<Job*,TreeNode*>::iterator, multimap<Job*,TreeNode*>::iterator> itMM;
		multimap<Job*,TreeNode*>::iterator itParents;
		itMM = multimapJob_ParentTreeNode.equal_range(JustFinishedJob);
		Time *JustFinishedTaskEndingTime=JustFinishedJob->GetEndTime();
		for(itParents=itMM.first;itParents!=itMM.second;++itParents) {

			Job* ParentJob=(itParents->second)->t->GetJobA();
			bool wasReady=ParentJob->GetReadyWithoutComputingIt();
			if(wasReady==false && ParentJob->IsReady()) {
				Time *ParentReleaseTime=ParentJob->GetReleaseTime();
				list<IAResource*> *ExecutingCores=ParentJob->GetExecutingCores();
				list<IAResource*>::iterator itCore;

				for(itCore=ExecutingCores->begin() ; itCore!=ExecutingCores->end() ; ++itCore) {
					if(mapCoreTime.find(*itCore)!=mapCoreTime.end() && *ParentReleaseTime<*mapCoreTime.at(*itCore)) {
						Job* JobExecutedByCore=jt1->FindJobExecutedByCoreAtTime(*itCore,JustFinishedTaskEndingTime,iteration++);
						if(JobExecutedByCore==NULL || ParentJob->GetPriority()<JobExecutedByCore->GetPriority()) {
							continue;
						}
						
							list<IAResource*>::iterator itCore1=find(AllCores.begin(),AllCores.end(),*itCore);

							int iCore=distance(AllCores.begin(),itCore1);
							Preempt(iCore,JobExecutedByCore,JustFinishedTaskEndingTime, ++iteration);
							JobExecutedByCore->SetScheduled(false);
							JobExecutedByCore->SetReady(false);
							JobExecutedByCore->ClearStartAndEndTime();

					}

				}

			}

		}

		delete ParentTreeNodes;
	}




	Time* SchedulerPriorityPreemptive::DeterminePreemptionTime(Job *j,int iteration) {
		Time *result=NULL;
		Job *j1;
		j1=jt1->FindTheEarliestReadyJobOfTheHighestPriorityAndPriorityHigherThanForCore(j,j->GetTheFirstExecutingCore(),iteration);
		if(j1!=NULL) {
			result=jt1->GetReadyTime(j1);
		}


		return result;
	}


}
