#include "AmInstruction.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

namespace IntervalAlgebra
{
		Instruction::Instruction(string NameIn) {
			Name=NameIn;
		}

		void Instruction::SetName(string NameIn) {
			Name=NameIn;
		}

		string Instruction::GetName() {
			return Name;
		}

		void Instruction::Print() {
			cout << Name ;
		}


}
