#include "AmTask.h"
#include "AmTypes.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

namespace IntervalAlgebra
{
		Task::Task(string NameIn): Name(NameIn), Priority(0), PriorityValid(false), Stimulus_(NULL) {
		}

		Task::~Task() {}


		void Task::SetName(string NameIn) {
			Name=NameIn;
		}

		string Task::GetName() {
			return Name;
		}

		int Task::GetPriority() {
			return Priority;
		}

		void Task::SetPriority(int PriorityIn) {
			Priority=PriorityIn;
		}

		bool Task::GetPriorityValid() {
			return PriorityValid;
		}

		int Task::GetMultipleTaskActivationLimit() {
			return MultipleTaskActivationLimit;
		}

		void Task::SetMultipleTaskActivationLimit(int MultipleTaskActivationLimitIn) {
			MultipleTaskActivationLimit=MultipleTaskActivationLimitIn;
		}

		bool Task::GetMultipleTaskActivationLimitValid() {
			return MultipleTaskActivationLimitValid;
		}

		void Task::SetPreemption(string PreemptionIn) {
			Preemption=PreemptionIn;
		}

		string Task::GetPreemption() {
			return Preemption;
		}
		
		void Task::SetDeadline(pair<int,string> DeadlineIn) {
			Deadline=DeadlineIn;
		}

		int Task::GetDeadlineValue() {
			return Deadline.first;
		}

		string Task::GetDeadlineUnit(){
			return Deadline.second;
		}

		void Task::AddRunnable(Runnable* RunnableIn) {
			Runnables.push_back(RunnableIn);
		}

		void Task::Print() {
			cout << "Name: " << Name;
			cout << " period - ";
			Stimulus_->Print();
			cout << endl;
			vector<Runnable*>::iterator it;
			int i;
			for(i=0,it=Runnables.begin();it!=Runnables.end();++it,i++) {
				cout << "Runnable no:" << i << endl;
				(*it)->Print();
			}
		}


		void Task::SetStimulus(Stimulus* StimulusIn) {
			Stimulus_=StimulusIn;
		}

		Stimulus*  Task::GetStimulus() {
			return Stimulus_;
		}

		Runnable*  Task::GetRunnable(int Index) {
			return Runnables[Index];
		}

		int Task::GetNoOfRunnables() {
			return Runnables.size();
		}

		pair<int,string> Task::GetPeriod() {
			pair<int,string> result;
			if(Stimulus_!=NULL) {
				result=Stimulus_->GetRecurrence();
			}
			else {
				result=AmNoTime;
			}
			return result;
		}


}
