#include "AmCoreType.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

namespace IntervalAlgebra
{
		CoreType::CoreType(string NameIn): Name(NameIn), InstructionsPerCycle(0) {
		}

		void CoreType::SetName(string NameIn) {
			Name=NameIn;
		}

		string CoreType::GetName() {
			return Name;
		}

		void CoreType::SetInstructionsPerCycle(int InstructionsPerCycleIn) {
			if(InstructionsPerCycleIn<=0) {
				cout << "Error! Wrong value of InstructionsPerCycle in the benchmark.";
				exit(-1);
			}
			InstructionsPerCycle=InstructionsPerCycleIn;
		}

		int CoreType::GetInstructionsPerCycle() {
			return InstructionsPerCycle;
		}

		void CoreType::SetID(string IDIn) {
			ID=IDIn;
		}

		string CoreType::GetID() {
			return ID;
		}


}
