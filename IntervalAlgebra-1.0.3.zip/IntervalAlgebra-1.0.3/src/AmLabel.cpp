#include "AmLabel.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

namespace IntervalAlgebra
{
		Label::Label(string NameIn): Name(NameIn), Size(0) {
		}

		void Label::SetName(string NameIn) {
			Name=NameIn;
		}

		string Label::GetName() {
			return Name;
		}

		void Label::SetSize(int SizeIn) {
			Size=SizeIn;
		}

		int Label::GetSize() {
			return Size;
		}

		void Label::SetID(string IDIn) {
			ID=IDIn;
		}

		string Label::GetID() {
			return ID;
		}


}
