#include "AmExecutionCyclesDeviationInstruction.h"
#include "AmInstruction.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

namespace IntervalAlgebra
{
		ExecutionCyclesDeviationInstruction::ExecutionCyclesDeviationInstruction(string NameIn): Instruction(NameIn), RemainPromille(0), Mean(0), LowerBound(0), UpperBound(0), SD(0), LowerBoundValid(false), UpperBoundValid(false), RemainPromilleValid(false), MeanValid(false), SDValid(false) {
		}




		double ExecutionCyclesDeviationInstruction::GetLowerBound() {
			return LowerBound;
		}

        double ExecutionCyclesDeviationInstruction::GetUpperBound() {
			return UpperBound;
		}

        string ExecutionCyclesDeviationInstruction::GetType() {
			return Type;
		}

		double ExecutionCyclesDeviationInstruction::GetRemainPromille() {
			return RemainPromille;
		}

		double ExecutionCyclesDeviationInstruction::GetMean() {
			return Mean;
		}

		double ExecutionCyclesDeviationInstruction::GetSD() {
			return SD;
		}

		void ExecutionCyclesDeviationInstruction::SetLowerBound(double LowerBoundIn) {
			LowerBound=LowerBoundIn;
			LowerBoundValid=true;
		}

		void ExecutionCyclesDeviationInstruction::SetUpperBound(double UpperBoundIn) {
			UpperBound=UpperBoundIn;
			UpperBoundValid=true;
		}

		void ExecutionCyclesDeviationInstruction::SetType(string TypeIn) {
			Type=TypeIn;
		}

		void ExecutionCyclesDeviationInstruction::SetRemainPromille(double RemainPromilleIn) {
			RemainPromille=RemainPromilleIn;
			RemainPromilleValid=true;
		}

		void ExecutionCyclesDeviationInstruction::SetMean(double MeanIn) {
			Mean=MeanIn;
			MeanValid=true;
		}

		void ExecutionCyclesDeviationInstruction::SetSD(double SDIn) {
			SD=SDIn;
			SDValid=true;
		}

		bool ExecutionCyclesDeviationInstruction::GetLowerBoundValid() {
			return LowerBoundValid;
		}

		bool ExecutionCyclesDeviationInstruction::GetUpperBoundValid() {
			return UpperBoundValid;
		}

		bool ExecutionCyclesDeviationInstruction::GetRemainPromilleValid() {
			return RemainPromilleValid;
		}

		bool ExecutionCyclesDeviationInstruction::GetMeanValid() {
			return MeanValid;
		}

		bool ExecutionCyclesDeviationInstruction::GetSDValid() {
			return SDValid;
		}

		void ExecutionCyclesDeviationInstruction::Print() {
		cout << GetName() << " Type: " << Type;
		if (RemainPromilleValid) {
			cout << " RemainPromille: " << RemainPromille;
		}
		if (MeanValid) {
			cout << " Mean: " << Mean;
		}
		if (SDValid) {
			cout << " SD: " << SD;
		}
		if (LowerBoundValid) {
			cout << " LowerBound: " << LowerBound;
		}
		if (UpperBoundValid) {
			cout << " UpperBound: " << UpperBound;
		}
		}

}
