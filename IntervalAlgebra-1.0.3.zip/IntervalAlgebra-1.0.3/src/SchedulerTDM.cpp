#include "SchedulerTDM.h"
#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

namespace IntervalAlgebra
{

	SchedulerTDM::SchedulerTDM(Time *QuantumIn) : Scheduler() {
		Quantum=QuantumIn;
		ResetDeadlineCounters();
	}


	Time* SchedulerTDM::GetQuantum() {
		return Quantum;
	}



	

	void SchedulerTDM::Schedule() {
		Job *j,*j1;
		string OriginalIDOfthePreviousJobID="";

		Time *CurrentTime;
		CurrentTime=NULL;


		for(unsigned int i=0;i<AllJobs.size();i++) {
			j=jt1->FindTheEarliestReadyJobButNotOriginatedFrom(OriginalIDOfthePreviousJobID,NULL,i);
			j1=jt1->FindTheEarliestReadyJob(NULL,i+100); //i+100, as we have to have different iteration index than above
			if(j==NULL||(j!=j1 && *jt1->DetermineStartTime(j)>*jt1->DetermineStartTime(j1))) {
				j=j1; 
			}
			Time *MyTime=j->GetExecutionTime(j->GetTheFirstExecutingCore());
			if(*MyTime > *Quantum) {
				Time *t=jt1->DetermineStartTime(j);
				t=t->Clone();
				Job *PrefixJob=j->ExtractPrefix(Quantum,j->GetTheFirstExecutingCore());
				j->RemovePrefix(Quantum,j->GetTheFirstExecutingCore());
				string str=string(to_string(PrefixJob->GetNoOfSlice()));
				PrefixJob->SetName(PrefixJob->GetName()+"__$"+str);
				j->SetNoOfSlice(PrefixJob->GetNoOfSlice()+1);
				PrefixJob->SetStartAndEndTime(t);
				PrefixJob->SetPModeOfExecutingResources();			
				PrefixJob->SetScheduled(true);
				AllJobs.push_front(PrefixJob);
				jt1->AddNodeAsAChildTo(PrefixJob,j);


				list<IAResource*>::iterator it;
				Time* EndTime=PrefixJob->GetEndTime();
				for(it=PrefixJob->GetExecutingCores()->begin();it!=PrefixJob->GetExecutingCores()->end();++it) {
					delete mapCoreTime[*it];
					mapCoreTime[*it]=EndTime->Clone();
				}

				OriginalIDOfthePreviousJobID=j->GetOriginalName();
				delete t;
			}
			else {
				Time *t=jt1->DetermineStartTime(j);
				j->SetStartAndEndTime(t);
				
				j->SetPModeOfExecutingResources();			
				j->SetScheduled(true);

				CurrentTime = j->GetEndTime();

				if(*CurrentTime<=*j->GetDeadline()) {
					IncreaseBeforeDeadlineCounter();
				}
				else {
					IncreaseAfterDeadlineCounter();
				}


				OriginalIDOfthePreviousJobID=j->GetOriginalName();

				list<IAResource*>::iterator it;
				Time* EndTime=j->GetEndTime();
				for(it=j->GetExecutingCores()->begin();it!=j->GetExecutingCores()->end();++it) {
					delete mapCoreTime[*it];
					mapCoreTime[*it]=EndTime->Clone();
				}

			}
			delete MyTime;
		}
	}





}
