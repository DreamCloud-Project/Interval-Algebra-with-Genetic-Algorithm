#include "Scheduler.h"
#include <string>

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


namespace IntervalAlgebra
{

	Scheduler::Scheduler() : AllocateTasksUsingPModes_(false) {
		Time *TimeZero = new TimeDeterministic(0);

		Job *Start = new Job("Start");
		Start->SetReleaseTime(TimeZero);
		Time *TimeStart=new TimeDeterministic(0);
		Start->SetExecutionTimeForExecutingResource(TimeStart);
		delete TimeStart;
		AddJobA(Start);
		StartJob = Start;
		EndJob = NULL;
		UsedResource=NULL;
		jt1=NULL;
	}

	Scheduler::~Scheduler() {
			delete StartJob;
			delete jt1;

			map<IAResource*,Time*> :: iterator it;
			for(it=mapCoreTime.begin();it!=mapCoreTime.end();++it) {
				if(it->second!=NULL) {
					delete it->second;
					it->second=NULL;
				}
			}
}

	void Scheduler::DisplayJobTime() {
			cout <<endl;
			for (std::list<Job*>::iterator it = AllJobs.begin() ; it != AllJobs.end(); ++it) {
			if((*it)->GetName()!="Start" && (*it)->GetName()!="End") {
				cout << "Job: " << (*it)->GetName() <<" Start: " << *(*it)->GetStartTime() << " End: " << *(*it)->GetEndTime() << " Deadline: " << *(*it)->GetDeadline() <<	" Cores: ";
				if((*it)->GetTheFirstExecutingCore()==NULL) 
					cout <<"Default";
				else {
					list<IAResource*>::iterator itCore;
					for(itCore=(*it)->GetExecutingCores()->begin();itCore!=(*it)->GetExecutingCores()->end();++itCore) {
						if(itCore != (*it)->GetExecutingCores()->begin()){
							cout << ", ";
						}
						cout << (*itCore)->GetName();
					}
				}
				if (*(*it)->GetEndTime()>*(*it)->GetDeadline()) {
					cout << " Missed Deadline!";
				}

				cout <<endl;
			}
		}

	}



	bool SortFunction1(Job *Job1, Job *Job2) {
		if(*Job1->GetStartTime() == *Job2->GetStartTime()) {  //when equal start time - important for jobs of the Running Time equal 0 (e.g. Start)
			return (*Job1->GetEndTime() < *Job2->GetEndTime());
		}
		return (*Job1->GetStartTime() < *Job2->GetStartTime());
	}

	void Scheduler::SortJobByTime() {
			AllJobs.sort(SortFunction1);
	}

	void Scheduler::AddCore(IAResource* CoreIn) {
		AllCores.push_back(CoreIn);
	}

	IAResource* Scheduler::GetCore(int Index) {
		list<IAResource*>::iterator result=AllCores.begin();
		advance(result,Index);
		return *result;
	}


	void Scheduler::AddJobA(Job* JobIn) {
		if(JobIn->GetDependentOn()->size()==0 && JobIn->GetName()!="Start") {
			JobIn->AddDependency(StartJob);
		}
		AllJobs.push_back(JobIn);
		AllJobsMap[JobIn->GetName()]=JobIn;
	}

	void Scheduler::AddJobs(list<Job*> *Jobs) {
		for(list<Job*>::iterator i=Jobs->begin();i!=Jobs->end() ; ++i) {
			AddJobA(*i);
		}
	}

	void Scheduler::AddPeriodicJob(Job* JobIn,Time *MaxTime,bool AddIfNotSplit) {

		list<Job*> *SplitJobs;
		SplitJobs=SplitPeriodicTaskIntoSeriesofSingleAppearanceTask(JobIn,MaxTime);
		if(!SplitJobs->empty() || AddIfNotSplit) {
			AddJobA(JobIn);
			AddJobs(SplitJobs);
		}
		delete SplitJobs;
	}

	Job* Scheduler::FindJobByName(string NameOfJobNeeded,list<Job*>* AllJobs) {
		if(AllJobsMap.count(NameOfJobNeeded)==0) {
			return NULL;
		}
		else {
			return AllJobsMap.at(NameOfJobNeeded);
		}
	}

	void Scheduler::AddEndJob() {
		list<Job*> *AllButEndJob=new list<Job*>;
		*AllButEndJob=AllJobs;
		Job *End;
		End = new Job("End");
		End->AddDependencySet(AllButEndJob);
		EndJob=End;
		TimeDeterministic *TimeZero =new TimeDeterministic(0);
		End->SetExecutionTimeForResource(TimeZero,NULL);
		delete TimeZero;
		AddJobA(End);
		jt1=new JobTree;
		jt1->AddRoot(End);
		delete AllButEndJob;
	}


	void Scheduler::DisplayJobs(list<Job*> *Jobs) {
		list<Job*>::iterator it;
		for (it = Jobs->begin(); it!= Jobs->end(); ++it) {
			if((*it)->GetName()!="Start" && (*it)->GetName()!="End") {
			cout<<"Job: " << (*it)->GetName() << " Level: " << (*it)->GetDependencyLevel() << endl;
			}
		}
	}

	void Scheduler::DisplayAllJobs() {
		DisplayJobs(&AllJobs);
	}

	void Scheduler::DisplayJobTimeWithPriorities() {
		cout << endl;
		for (std::list<Job*>::iterator it = AllJobs.begin(); it != AllJobs.end(); ++it) {
			if((*it)->GetName()!="Start" && (*it)->GetName()!="End") {
				cout << "Job: " << (*it)->GetName() << " Start: " << *(*it)->GetStartTime() << " End: " << *(*it)->GetEndTime() << " Priority: " << (*it)->GetPriority() << " Core: " ;

				if((*it)->GetTheFirstExecutingCore()==NULL) 
					cout <<"Default";
				else {
					list<IAResource*>::iterator itCore;
					for(itCore=(*it)->GetExecutingCores()->begin();itCore!=(*it)->GetExecutingCores()->end();++itCore) {
						if(itCore != (*it)->GetExecutingCores()->begin()){
							cout << ", ";
						}
						cout << (*itCore)->GetName();
					}
				}
				cout <<endl;

			}
		}

	}

	void Scheduler::RemoveAllJobs() {
		list<Job*>::iterator it;
		Job* it1;
		it1=NULL;
		for (it = AllJobs.begin(); it!= AllJobs.end(); ++it) {
			if((*it)->GetName()!="Start")  {
				delete *it;
			}
		}
	}

	void Scheduler::RemoveTree() {
		delete jt1;
	}

	void Scheduler::IncreaseBeforeDeadlineCounter(){
		BeforeDeadlineCounter++;
	}

	void Scheduler::IncreaseAfterDeadlineCounter() {
		AfterDeadlineCounter++;
	}



	void Scheduler::ResetDeadlineCounters() {
		BeforeDeadlineCounter=0;
		AfterDeadlineCounter=0;
	}

	void Scheduler::ComputeDeadlineCounters() {
		ResetDeadlineCounters();
		list<Job*>::iterator it;

		for (it = AllJobs.begin(); it!= AllJobs.end(); ++it) {
			if((*it)->GetName()=="Start" || (*it)->GetName()=="End" || (*it)->GetName().find("__$", 0)!=string::npos) {
			}
			else if((*it)->CheckIfDeadlineMet()){
				IncreaseBeforeDeadlineCounter();
			}
			else {
				IncreaseAfterDeadlineCounter();
			}
		}
	}


	int Scheduler::GetBeforeDeadlineCounter(){
		return BeforeDeadlineCounter;
	}

	int Scheduler::GetAfterDeadlineCounter(){
		return AfterDeadlineCounter;
	}

	Time* Scheduler::GetTotalLaxity() {
		list<Job*>::iterator it;
		Time *result=new TimeDeterministic(0),*result1,*TimeLaxity;
		for (it = AllJobs.begin(); it!= AllJobs.end(); ++it) {
			if((*it)->GetName()=="Start" || (*it)->GetName()=="End") {
			}
			else {
				TimeLaxity=(*it)->GetLaxity();
				if(TimeLaxity!=NULL) {
					result1=Add(*result,*TimeLaxity);
					delete result;
					delete TimeLaxity;
					result=result1;
				}
			}
		}

		return result;
	}

	Job* Scheduler::GetEarliestJob() {
		return *std::min_element(AllJobs.begin(),AllJobs.end(),SortFunction1);
	}

	
	Job* Scheduler::GetLatestJob() {
		return *std::max_element(AllJobs.begin(),AllJobs.end(),SortFunction1);
	}


	inline bool Scheduler::EndsWith(string const &Value, string const &Ending) {
		if (Ending.size() > Value.size()) return false;
		return equal(Ending.rbegin(), Ending.rend(), Value.rbegin());
	}


	Job* Scheduler::GetLatestFirstJobOfPeriodicTask() {
		list<Job*>::iterator it;
		Job* LatestFirstJob=NULL;
		string FirstJobOfPeriodicTaskSuffix="__#0";
		for(it=AllJobs.begin();it!=AllJobs.end();++it) {
			if(EndsWith((*it)->GetName(),FirstJobOfPeriodicTaskSuffix) && (LatestFirstJob==NULL || *((*it)->GetEndTime()) > *LatestFirstJob->GetEndTime())) {
				LatestFirstJob=*it;
			}
		}
		return LatestFirstJob;
	}


		bool Scheduler::UpdatePeriodicDependencies(Job* JobIn, int JobIndexIn,list<Job*>* AllJobs) {

			Job* MyJob;	
			for (int i=0 ; i<JobIn->GetDependentOnListSize(); i++) {
				MyJob=JobIn->GetDependentOnListElement(i);
				if(MyJob->IsPeriodic()) {
					string NameOfJobNeeded=MyJob->GetName()+"__#"+std::to_string(JobIndexIn);
					MyJob=FindJobByName(NameOfJobNeeded,AllJobs);
					if(MyJob==NULL) {
						return false;
					}
					else {
						JobIn->SetDependentOnListElement(i,MyJob);
					}
			}
		}
		return true;
	}


	TimeUnit Scheduler::GetSmallestUnitFromStartEndTimes(list<Job*> *JobList) {
		TimeUnit result=s;
		list<Job*>::iterator it;
		for(it=JobList->begin();it!=JobList->end();++it) {
			if((*it)->GetStartTime()->GetUnit()<result) {
				result=(*it)->GetStartTime()->GetUnit();
			}
			if((*it)->GetEndTime()->GetUnit()<result) {
				result=(*it)->GetEndTime()->GetUnit();
			}
		}
		return result;
	}

	double Scheduler::GetEnergy() {
		double result=0.0;
		TimeUnit MyTimeUnit;
		MyTimeUnit=GetSmallestUnitFromStartEndTimes(&AllJobs);
//dynamic energy		
		for (std::list<Job*>::iterator it = AllJobs.begin() ; it != AllJobs.end(); ++it) {
			result+=(*it)->GetDynamicEnergyForExecutingResourcesAndAllocatedTasks(MyTimeUnit);
		}

		for (std::list<IAResource*>::iterator it = AllCores.begin() ; it != AllCores.end(); ++it) {
			result+=(*it)->GetNoOfPModeChanges()*(*it)->GetResourceType()->GetSwitchingPModeEnergyPenalty();
		}
		double dynamicEnergy=result;
//static energy
		for (std::list<IAResource*>::iterator it = AllCores.begin() ; it != AllCores.end(); ++it) {
			if((*it)->GetIsIdle()==true) {
				continue;
			}
			result+=(*it)->GetStaticEnergyPerTimeUnit(MyTimeUnit)*(GetLatestJob()->GetEndTime()->GetValueInUnit(MyTimeUnit)-GetEarliestJob()->GetStartTime()->GetValueInUnit(MyTimeUnit));
		}

		double staticEnergy=result-dynamicEnergy;

		return result;
	}

	int Scheduler::GetDependencyLevel(Job *JobIn) {
		bool AllParentsAssigned=true;
		int MaxParentLevel=-1;
		int Level;
		if(JobIn->GetDependentOnListSize()==0) return 0;
			for (int i=0 ; i<JobIn->GetDependentOnListSize(); i++) {
				Job *JobDep=JobIn->GetDependentOnListElement(i);
				Level=JobDep->GetDependencyLevel();

				if(Level==-1) {
					AllParentsAssigned=false;
					return -1;
				}
				else if(Level>MaxParentLevel) {
					MaxParentLevel=Level;
				}
			}
		return MaxParentLevel+1;
	}


	void Scheduler::DetermineDependencyLevel(list<Job*> *Jobs) {


		list<Job*> Jobs1;
		std::copy(Jobs->begin(), Jobs->end(), std::back_inserter(Jobs1));

		int ToBeDone=Jobs->size();
		int Done=0;
		int Level;
		int MaxLevel=0;

		while(Done<ToBeDone) {
			list<Job*>::iterator it,itJobsSynchrNoC,it1;

			for (it = Jobs1.begin(); it!= Jobs1.end() && Done<ToBeDone; ) {
				if(Done==ToBeDone-1) { //End task
					(*it)->SetDependencyLevel(MaxLevel+1);
					Done++;
					break;
				}

				if((Level=GetDependencyLevel(*it))!=-1) {
					(*it)->SetDependencyLevel(Level);
					if(MaxLevel<Level) {
						MaxLevel=Level;
					}
					Done++;
					
					for(itJobsSynchrNoC=(*it)->SynchrNoC.begin();itJobsSynchrNoC!=(*it)->SynchrNoC.end();++itJobsSynchrNoC)	{
						it1=find(Jobs1.begin(),Jobs1.end(),*itJobsSynchrNoC);

						if(it1==Jobs1.end()) {
							cout << "Error! The element has not been found in DetermineDependencyLevel." << endl;
							continue;
						}

						(*it1)->SetDependencyLevel(Level+1);
						if(MaxLevel<Level+1) {
							MaxLevel=Level+1;
						}

						Done++;
						Jobs1.erase(it1);
					}

					it=Jobs1.erase(it);

				}
				else {
					++it;
				}
			}
		}
	}



	int Scheduler::GetTheHighestDependencyLevel(list<Job*> *Jobs) {
		list<Job*>::iterator it;
		int MaxLevel=-1;
		int Level;
		for (it = Jobs->begin(); it!= Jobs->end(); ++it) {
			if((Level=(*it)->GetDependencyLevel())>MaxLevel) {
				MaxLevel=Level;
			}
		}
		return Level;
	}

	void Scheduler::DetermineDependencyLevelOfAllJobs() {
		DetermineDependencyLevel(&AllJobs);
	}

	void Scheduler::Initialize() {
		jt1->BuildTreeFromRoot(&AllJobs);
		}


	void Scheduler::Finalize() {
		AddEndJob();
		DetermineDependencyLevelOfAllJobs();
		Initialize();
		Schedule();
	}

	void Scheduler::Collapse(Job *CollapseJob) {
		Finalize();
		CollapseJob->SetStartAndEndTimeForCollapse(GetEarliestJob()->GetStartTime(),GetLatestJob()->GetEndTime());
	}

	void Scheduler::Preserve() {
		Finalize();
	}


	list<Job*>* Scheduler::SplitPeriodicTaskIntoSeriesofSingleAppearanceTask(Job* JobIn, Time *EndSplittingTime) {
		list<Job*>* result=new list<Job*>;
		Time *TimeI=new TimeDeterministic(0);
		Time *TimeTmp;
		bool ParentFound;
		int JobIndex=0;
		while(*TimeI<*EndSplittingTime) {
			string SingleApperanceJobName=JobIn->GetName();
			SingleApperanceJobName=SingleApperanceJobName+"__#"+std::to_string(JobIndex);
			Job *SingleApperanceJob=new Job(SingleApperanceJobName);


			Time *NewTime=JobIn->GetReleaseTime()->Clone();
			SingleApperanceJob->SetReleaseTime(NewTime);
			Time *NewDeadline=JobIn->GetDeadline()->Clone();
			SingleApperanceJob->SetDeadline(NewDeadline);

			SingleApperanceJob->SetDependenciesFrom(JobIn);
			SingleApperanceJob->SetPriority(JobIn->GetPriority());
			SingleApperanceJob->SetExecutingCores(JobIn->GetExecutingCores());
			ParentFound=UpdatePeriodicDependencies(SingleApperanceJob,JobIndex,&AllJobs);
			if(ParentFound==false) { 
				//probably we have not generated enough preceeding tasks, e.g., its period is longer; thus we have to skip the generation of the remaining single occurence tasks to satisfy the dependencies
				break;
			}

			SingleApperanceJob->SetAllowedResourcesExecutionTimeFrom(*JobIn);
			result->push_back(SingleApperanceJob);

			JobIn->AddToReleaseTime(JobIn->GetPeriod());
			JobIn->AddToDeadline(JobIn->GetPeriod());
			TimeTmp=TimeI;
			TimeI=Add(*TimeI,*(JobIn->GetPeriod()));
			delete TimeTmp;
			JobIndex++;
		}



		delete TimeI;
		return result;

	}

	bool Scheduler::CheckIfAllTasksArePeriodicOrSporadic() {
		bool result=true;
		for (std::list<Job*>::iterator it = AllJobs.begin() ; it != AllJobs.end(); ++it) {
			if(!(*it)->IsStartingJob() && !(*it)->IsEndingJob() && !(*it)->IsPeriodicOrSporadic()) {
				return false;
			}
		}
		return result;
	}

	bool Scheduler::CheckIfAllTasksArePeriodicOrSporadicForCore(IAResource* CoreIn) {
		bool result=true;
		for (std::list<Job*>::iterator it = AllJobs.begin() ; it != AllJobs.end(); ++it) {
			if(!(*it)->IsStartingJob() && !(*it)->IsEndingJob() && !(*it)->IsPeriodicOrSporadic() && (*it)->CheckIfExecutedByCore(CoreIn)) {
				return false;
			}
		}
		return result;
	}


	void Scheduler::FindHigherPrioritiesJob(Job* JobIn,list<Job*> *HigherPriorities) {
		for (std::list<Job*>::iterator it = AllJobs.begin() ; it != AllJobs.end(); ++it) {
			if((*it)->GetPriority()>JobIn->GetPriority()) {
				HigherPriorities->push_back(*it);
			}
		}
	}

	void Scheduler::FindHigherPrioritiesJobForCore(Job* JobIn,list<Job*> *HigherPriorities, IAResource* CoreIn) {
		for (std::list<Job*>::iterator it = AllJobs.begin() ; it != AllJobs.end(); ++it) {
			if((*it)->CheckIfExecutedByCore(CoreIn) && (*it)->GetPriority()>JobIn->GetPriority()) {
				HigherPriorities->push_back(*it);
			}
		}
	}


	bool Scheduler::PerformRealTimeAnalysisSingleCore() {


		if(!CheckIfAllTasksArePeriodicOrSporadic()) {
			return false;	//the analysis is not applicable
		}

		TimeUnit LowestTimeUnit=s;

		for (std::list<Job*>::iterator it = AllJobs.begin() ; it != AllJobs.end(); ++it) {
			if((*it)->GetPeriod()->GetUnit()<LowestTimeUnit) {
				LowestTimeUnit=(*it)->GetPeriod()->GetUnit();
			}

			Time *MyTime=(*it)->GetExecutionTimeForExecutingResource();
			if(MyTime->GetUnit()<LowestTimeUnit) {
				LowestTimeUnit=MyTime->GetUnit();
			}
			delete MyTime;

			if((*it)->GetDeadline()->GetValue()!=0) {
				if((*it)->GetDeadline()->GetUnit()<LowestTimeUnit) {
					LowestTimeUnit=(*it)->GetDeadline()->GetUnit();
				}
			}
		}

		bool result=true;
		double Ri,RiPrev;
		Ri=RiPrev=0;
		list<Job*> HigherPriorities;
		for (std::list<Job*>::iterator it = AllJobs.begin() ; it != AllJobs.end(); ++it) {
			if((*it)->IsStartingJob() || (*it)->IsEndingJob()) {
				continue;
			}
			FindHigherPrioritiesJob(*it,&HigherPriorities);

			for (;;) {
				Time *MyTime=(*it)->GetExecutionTimeForExecutingResource();
				Ri=static_cast<double>(MyTime->GetWorstCaseValueInUnit(LowestTimeUnit));
				delete MyTime;
				for (std::list<Job*>::iterator ithp = HigherPriorities.begin() ; ithp != HigherPriorities.end(); ++ithp) {
					MyTime=(*ithp)->GetExecutionTimeForExecutingResource();
					Ri+=ceil(RiPrev/(*ithp)->GetPeriod()->GetBestCaseValueInUnit(LowestTimeUnit))*MyTime->GetWorstCaseValueInUnit(LowestTimeUnit);
					delete MyTime;
				}

					if(Ri==RiPrev) break;
					RiPrev=Ri;
			} 

			HigherPriorities.clear();
			if((*it)->GetDeadline()->GetValueInUnit(LowestTimeUnit)!=0) {
				if(Ri>(*it)->GetDeadline()->GetValueInUnit(LowestTimeUnit)) {
					result=false;
					return result;
				}
			} 
			else { //there is no deadline, so we use the period instead
				if(Ri>(*it)->GetPeriod()->GetValueInUnit(LowestTimeUnit)) {
					result=false;
					return result;
				}
			}

		}

		return result;
	}

	bool Scheduler::PerformRealTimeAnalysisForCore(IAResource* CoreIn) {

		if(!CheckIfAllTasksArePeriodicOrSporadic()) {
			return false;	//the analysis is not applicable
		}

		TimeUnit LowestTimeUnit=s;

		for (std::list<Job*>::iterator it = AllJobs.begin() ; it != AllJobs.end(); ++it) {
			if(!(*it)->CheckIfExecutedByCore(CoreIn)) {
				continue;
			}

			if((*it)->GetPeriod()->GetUnit()<LowestTimeUnit) {
				LowestTimeUnit=(*it)->GetPeriod()->GetUnit();
			}

			Time *MyTime=(*it)->GetExecutionTime(CoreIn);
			if(MyTime->GetUnit()<LowestTimeUnit) {
				LowestTimeUnit=MyTime->GetUnit();
			}
			delete MyTime;

			if((*it)->GetDeadline()->GetValue()!=0) {
				if((*it)->GetDeadline()->GetUnit()<LowestTimeUnit) {
					LowestTimeUnit=(*it)->GetDeadline()->GetUnit();
				}
			}
		}

		bool result=true;
		double Ri,RiPrev;
		Ri=RiPrev=0;
		list<Job*> HigherPriorities;
		for (std::list<Job*>::iterator it = AllJobs.begin() ; it != AllJobs.end(); ++it) {
			if((*it)->IsStartingJob() || (*it)->IsEndingJob() || !(*it)->CheckIfExecutedByCore(CoreIn) ) {
				continue;
			}
			FindHigherPrioritiesJobForCore(*it,&HigherPriorities,CoreIn);

			for (;;) {
				Time *MyTime=(*it)->GetExecutionTime(CoreIn);
				Ri=static_cast<double>(MyTime->GetWorstCaseValueInUnit(LowestTimeUnit));
				delete MyTime;
				
				for (std::list<Job*>::iterator ithp = HigherPriorities.begin() ; ithp != HigherPriorities.end(); ++ithp) {
					MyTime=(*ithp)->GetExecutionTime(CoreIn);
					Ri+=ceil(RiPrev/(*ithp)->GetPeriod()->GetBestCaseValueInUnit(LowestTimeUnit))*MyTime->GetWorstCaseValueInUnit(LowestTimeUnit);
					delete MyTime;
				}

					if(Ri==RiPrev) break;
					RiPrev=Ri;
			} 

			HigherPriorities.clear();
			cout << "Deadline: " << (*it)->GetDeadline()->GetValue() << (*it)->GetDeadline()->GetUnit() << endl;
			if((*it)->GetDeadline()->GetValueInUnit(LowestTimeUnit)!=0) {
				if(Ri>(*it)->GetDeadline()->GetValueInUnit(LowestTimeUnit)) {
					result=false;
					return result;
				}
			} 
			else { //there is no deadline, so we use the period instead
				if(Ri>(*it)->GetPeriod()->GetValueInUnit(LowestTimeUnit)) {
					result=false;
					return result;
				}
			}

		}

		return result;
	}


	bool Scheduler::HasLHSEarlierDeadlineThanRHSJob(Job* lhs, Job* rhs) {
		bool result;
		Time *lhsDeadline=Add(*lhs->GetReleaseTime(),*lhs->GetDeadline());
		Time *rhsDeadline=Add(*rhs->GetReleaseTime(),*rhs->GetDeadline());
		if(*lhsDeadline<*rhsDeadline) {
			result=true;
		}
		else {
			result=false;
		}
		delete lhsDeadline;
		delete rhsDeadline;
		return result;
	}

	void Scheduler::AssignPrioritiesEDF() {
		vector<Job*> ToBeAssigned;
		ToBeAssigned.reserve(AllJobs.size()-2);
		list<Job*>::iterator it;
		for(it=AllJobs.begin();it!=AllJobs.end();++it) {
			if((*it)->IsScheduled()==false && (*it)->GetPriority()!=INT_MAX && (*it)->GetName()!="End" && (*it)->GetName()!="Start") {
				ToBeAssigned.push_back(*it);
			}
		}
		sort(ToBeAssigned.begin(),ToBeAssigned.end(),&HasLHSEarlierDeadlineThanRHSJob);
		int Priority=ToBeAssigned.size();

		vector<Job*>::iterator itv;
		for(itv=ToBeAssigned.begin();itv!=ToBeAssigned.end();++itv) {
			(*itv)->SetPriority(Priority--);
		}


	}


	JobTree* Scheduler::GetJobTree() {
		return jt1;
	}

	const list<Job*>&  Scheduler::GetAllJobsList() {
		return AllJobs;
	}

	void Scheduler::RemoveFromAllJobsAndAllJobsMap(Job *JobIn) {
		AllJobsMap.erase(JobIn->GetName());
		AllJobs.erase(remove(AllJobs.begin(), AllJobs.end(), JobIn), AllJobs.end());
	}

	void Scheduler::SetAllocateTasksUsingPModes(bool AllocateTasksUsingPModesIn) {
		AllocateTasksUsingPModes_=AllocateTasksUsingPModesIn;
	}

	bool Scheduler::GetAllocateTasksUsingPModes() {
		return AllocateTasksUsingPModes_;
	}

	void Scheduler::ClearTaskPModesVector() {
		TaskPModes_.clear();
	}

	int Scheduler::GetNumberofTaskPModesVectorElements() {
		return TaskPModes_.size();
	}

	int Scheduler::GetElementFromTaskPModesVectorElements(int IndexIn) {
		if(TaskPModes_.size()<IndexIn) {
			return -1;
		}
		else {
			return TaskPModes_[IndexIn];
		}
	}

	void Scheduler::SetElementFromTaskPModesVectorElements(int IndexIn,int ValueIn) {
		if(TaskPModes_.size()<IndexIn) {
			TaskPModes_.resize(IndexIn);
		}
		TaskPModes_[IndexIn]=ValueIn;
	}

	void Scheduler::SetSizeofTaskPModesVectorElements(int SizeIn) {
		TaskPModes_.resize(SizeIn);
	}


}

