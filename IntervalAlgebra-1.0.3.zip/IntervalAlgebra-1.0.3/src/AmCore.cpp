#include "AmCore.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

namespace IntervalAlgebra
{
		AmCore::AmCore(string NameIn): Name(NameIn), CoreType_(NULL), Quartz_(NULL) {
		}

		void AmCore::SetName(string NameIn) {
			Name=NameIn;
		}

		string AmCore::GetName() {
			return Name;
		}

		void AmCore::SetCoreType(CoreType* CoreTypeIn) {
			CoreType_=CoreTypeIn;
		}

		CoreType* AmCore::GetCoreType() {
			return CoreType_;
		}

		void AmCore::SetQuartz(Quartz* QuartzIn) {
			Quartz_=QuartzIn;
		}

		Quartz* AmCore::GetQuartz() {
			return Quartz_;
		}

		void AmCore::SetID(string IDIn) {
			ID=IDIn;
		}

		string AmCore::GetID() {
			return ID;
		}




}
