#include "AmRemoteAccessInstruction.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

namespace IntervalAlgebra
{
		RemoteAccessInstruction::RemoteAccessInstruction(string NameIn): Instruction(NameIn), Label_(NULL), Write_(false) {
		}

		Label* RemoteAccessInstruction::GetLabel() {
			return Label_;
		}


		void RemoteAccessInstruction::SetLabel(Label* LabelIn) {
			Label_=LabelIn;
		}

		void RemoteAccessInstruction::SetWrite(bool WriteIn) {
			Write_=WriteIn;
		}

		bool RemoteAccessInstruction::GetWrite() {
			return Write_;
		}

		RemoteAccessInstruction::~RemoteAccessInstruction() {
		}


		void RemoteAccessInstruction::Print() {
		cout << GetName() << " Label: " << GetLabel()->GetName() << " Size: " << GetLabel()->GetSize();
		if (Write_) {
			cout << " W";
		}
		else {
			cout << " R";
		}
		}
}


