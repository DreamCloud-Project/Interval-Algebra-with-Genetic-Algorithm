#include "Point.h"
#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

namespace IntervalAlgebra
{
		Point::Point(unsigned long long XIn, double YIn) :X(XIn), Y(YIn)
		{
		}

		void Point::SetX(unsigned long long XIn) {
			X=XIn;
		}

		void Point::SetY(double YIn) {
			Y=YIn;
		}

		unsigned long long Point::GetX(){
			return X;
		}

		double Point::GetY(){
			return Y;
		}

		void Point::Print() {
			cout << X << " " << Y << endl;
		}

		void Point::DivideYBy(double Divisor) {
			Y/=Divisor;
		}

		void Point::AddToX(unsigned long long ConstantIn) {
			X+=ConstantIn;
		}


}
