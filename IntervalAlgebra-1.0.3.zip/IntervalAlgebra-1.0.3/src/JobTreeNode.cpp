#include "JobTreeNode.h"
#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

namespace IntervalAlgebra
{
			JobTreeNode::~JobTreeNode() {
			}

			JobTreeNode::JobTreeNode(Job *JobIn) {

				Job1=JobIn;
			}

			JobTreeNode::JobTreeNode() {
			}

			Job* JobTreeNode::GetJobA() {
				return Job1;
			}


			void JobTreeNode::SetJobA(Job* JobIn) {
				Job1=JobIn;
			}

		bool JobTreeNode::IsReady() {
			bool Ready=Job1->IsReady();
			return Ready;
		}

		bool JobTreeNode::IsScheduled() {
			return Job1->IsScheduled();
		}



}

