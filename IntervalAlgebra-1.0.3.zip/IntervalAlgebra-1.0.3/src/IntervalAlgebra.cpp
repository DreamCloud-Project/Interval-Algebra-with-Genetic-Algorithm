////////////////////////////////////////////////////////////////////////////////
//                                                                            //
//              Interval algebra 1.0 alfa release (16.11.2014)                //
//                           DREAMCLOUD PROJECT                               //
//                  Copyright (C) 2014 University of York                     //
//                                                                            //
////////////////////////////////////////////////////////////////////////////////





#include <string>
#include <iostream>
#include <time.h>
#include <fstream>
#include <iomanip>
#include <sstream>
#include <boost/regex.hpp>
#include <set>
#include <algorithm>
#include <iterator>
#include <limits>

#include "IntervalAlgebra.h"
#include "TimeDeterministic.h"
#include "TimeStochastic.h"
#include "Job.h"
#include "SchedulerFIFO.h"
#include "SchedulerPriorityNonPreemptive.h"
#include "SchedulerTDM.h"
#include "SchedulerPriorityTDM.h"
#include "SchedulerPriorityPreemptive.h"
#include "JobTree.h"
#include "AmAmaltheaParser.h"
#include "AmAmaltheaSystem.h"
#include "IAException.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


#define ExecutionTimeMultiplier 1

using namespace IntervalAlgebra;

namespace IntervalAlgebra
{
list<TreeNode*> AllTreeNodes;
map<IAResource*,Time*> mapCoreTime;
map<IAResource*,Time*> CTmapCoreTimeBackupForTransactionRollback;
map<Job*,TreeNode*> mapJob_TreeNode;
multimap<Job*,TreeNode*> multimapJob_ParentTreeNode;

CNoExecutionTimeForExecutingCore NoExecutionTimeForExecutingCore;
CNoElementInPDF NoElementInPDF;  

}


vector<IAResource*> MyCores; 
vector<IAResource*> MyLinks;
map<string,IAResource*> mapNameCore;
map<string,IAResource*> mapNameLink;
vector<Job*>* TestUnit::AllJobs;


pair<int,int> GetCoordinatesOfCore(IAResource* CoreIn){
	int x,y;
	using namespace boost;
	boost::cmatch res;

	string STRING=CoreIn->GetName();
	boost::regex rx("^Core_([0-9]+)_([0-9]+)$");
	if (regex_match(STRING.c_str(), res, rx)) {
		x=(atoi(((string)res[1]).c_str()));
		y=(atoi(((string)res[2]).c_str()));
	}
	else {
		cout << "Wrong core name.";
		return pair<int,int>(0,0);
	}
	return pair<int,int>(x,y);
}

list<IAResource*>* GetPathBetween(IAResource* Source, IAResource* Destination) {
	list<IAResource*>* Path=new list<IAResource*>;
	pair<int,int> MyPair=GetCoordinatesOfCore(Source);
	int XSrc=MyPair.first;
	int YSrc=MyPair.second;
	MyPair=GetCoordinatesOfCore(Destination);
	int XDst=MyPair.first;
	int YDst=MyPair.second;

	//XY path
	if(Source == Destination) {
		return Path;
	}

	int x=XSrc;
	int y=YSrc;
	Path->push_back(mapNameLink.at("Core_"+to_string(x)+"_"+to_string(y)+"-Router_"+to_string(x)+"_"+to_string(y)));

	while(x<XDst) {
		Path->push_back(mapNameLink.at("Router_"+to_string(x)+"_"+to_string(y)+"-Router_"+to_string(x+1)+"_"+to_string(y)));
		x++;
	}
	while(x>XDst) {
		Path->push_back(mapNameLink.at("Router_"+to_string(x)+"_"+to_string(y)+"-Router_"+to_string(x-1)+"_"+to_string(y)));
		x--;
	}
	while(y<YDst) {
		Path->push_back(mapNameLink.at("Router_"+to_string(x)+"_"+to_string(y)+"-Router_"+to_string(x)+"_"+to_string(y+1)));
		y++;
	}
	while(y>YDst) {
		Path->push_back(mapNameLink.at("Router_"+to_string(x)+"_"+to_string(y)+"-Router_"+to_string(x)+"_"+to_string(y-1)));
		y--;
	}
		Path->push_back(mapNameLink.at("Router_"+to_string(x)+"_"+to_string(y)+"-Core_"+to_string(x)+"_"+to_string(y)));

	return Path;
}


string AddOne(string strIn) {
        string strResult;

        using namespace boost;
        boost::cmatch res;

        strResult=strIn;
        boost::regex rx("^(.*)(_@_)([0-9]*)$");
        if (regex_match(strIn.c_str(), res, rx)) {
                int nIndex=atoi(string(res[3]).c_str())+1;
                strResult=string(res[1])+string(res[2])+to_string(nIndex);
        }
        else {
                strResult=strResult+"_@_0";
        }


        return strResult;
}



static set<string> NamesSet;

string DoUnique(string strIn){

	string strResult;
	if(NamesSet.find(strIn)==NamesSet.end()) {
		strResult=strIn;
		NamesSet.insert(strResult);
	}
	else {
		strResult=strIn;
		while(NamesSet.find(strResult)!=NamesSet.end()) {
			strResult=AddOne(strResult);
		};
		NamesSet.insert(strResult);
	}

	return strResult;
}

TimeUnit strToTimeUnit(string strIn) {
	TimeUnit result=ms;

	if (strIn=="ps") {
		result=ps;
	}
	else if(strIn=="ns") {
		result=ns;
	}
	else if(strIn=="us") {
		result=us;
	}
	else if(strIn=="ms") {
		result=ms;
	}
	else if(strIn=="s") {
		result=s;
	}
	return result;
}





int TestUnit::GetNoOfRunnables() {
	return AmaltheaSystem::instance()->GetNoOfRunnables();

}




int TestUnit::GetNoOfLabels() {
	return AmaltheaSystem::instance()->GetNoOfLabels();

}

int TestUnit::GetIndexOfRunnable(string NameIn) {
	Runnable* MyRunnable=AmaltheaSystem::instance()->GetRunnableByName(NameIn);
	return AmaltheaSystem::instance()->GetIndexOfRunnable(MyRunnable);
}

int TestUnit::GetIndexOfLabel(string NameIn) {
	Label* MyLabel=AmaltheaSystem::instance()->GetLabelByName(NameIn);
	return AmaltheaSystem::instance()->GetIndexOfLabel(MyLabel);
}


int TestUnit::GetNoOfTasks() {
	return AmaltheaSystem::instance()->GetNoOfTasks();
}

int TestUnit::GetNoOfCores() {
		return AmaltheaSystem::instance()->GetNoOfAmCores();

}

void TestUnit::FillJobStructure(list<JobStruct> &JobStructIn) {
	SchedulerFIFO *MySchedulerFIFO=new SchedulerFIFO;


	Time *MaxTime = new TimeDeterministic(1000,us);

	list<Job*>* JobList=new list<Job*>;

	vector<IAResource*> Cores;

	unsigned long long nQuartzFrequency=1;
	int nTicksPerCycle=0;

	for(int l=0;l<AmaltheaSystem::instance()->GetNoOfAmCores();l++) {
		nQuartzFrequency=AmaltheaSystem::instance()->GetAmCore(l)->GetQuartz()->GetFrequency()/1000000;		
		nTicksPerCycle=AmaltheaSystem::instance()->GetAmCore(l)->GetCoreType()->GetInstructionsPerCycle();

		if(nTicksPerCycle==0) {
			nTicksPerCycle=1;
		}

		IAResource* MyCore=new IAResource(AmaltheaSystem::instance()->GetAmCore(l)->GetName());
		MyCore->SetResourceType(AmaltheaSystem::instance()->GetAmCore(l)->GetCoreType()->GetName());
		Cores.push_back(MyCore);
	}



	int nNoOfTasks=AmaltheaSystem::instance()->GetNoOfTasks();
	for(int i=0;i<nNoOfTasks;i++) {
		Task* MyTask = AmaltheaSystem::instance()->GetTask(i);
		int nNoOfRunnables=MyTask->GetNoOfRunnables();
		Job* MyJobPrev=NULL;
		for(int j=0;j<nNoOfRunnables;j++) {
			Runnable* MyRunnable = MyTask->GetRunnable(j);
			
			
			
			Job *MyJob=new Job(DoUnique(MyRunnable->GetName()));

			if(j==0) {
				//for the 1st runnable in the task only
				AmaltheaSystem::instance()->AddJobToStimuliDestinationsIfNecessary(MyTask,MyJob);
			}

			Time *TimeReleaseA;
			if(MyTask->GetStimulus()!=NULL) {
				TimeReleaseA = new TimeDeterministic(MyTask->GetStimulus()->GetOffset().first,strToTimeUnit(MyTask->GetStimulus()->GetOffset().second));
			}
			else  {
				TimeReleaseA = new TimeDeterministic(0);
			}

			MyJob->SetReleaseTime(TimeReleaseA);

			if(MyTask->GetStimulus()!=NULL) {
				Time *TimePeriodA = new TimeDeterministic(MyTask->GetStimulus()->GetRecurrence().first,strToTimeUnit(MyTask->GetStimulus()->GetRecurrence().second));
				MyJob->SetPeriod(TimePeriodA);
			}

			int nTickExecute=MyRunnable->GetWCETInTick();

			if(AmaltheaSystem::instance()->GetNoOfAmCores()>0) {
				for(int l=0;l<AmaltheaSystem::instance()->GetNoOfAmCores();l++) {
					nQuartzFrequency=AmaltheaSystem::instance()->GetAmCore(l)->GetQuartz()->GetFrequency()/1000000;		
					nTicksPerCycle=AmaltheaSystem::instance()->GetAmCore(l)->GetCoreType()->GetInstructionsPerCycle();

					if(nTicksPerCycle==0) {
						nTicksPerCycle=1;
					}

					Time *TimeExecuteA=new TimeDeterministic(ceil((double)nTickExecute/nQuartzFrequency)*nTicksPerCycle,us);  //us, since we divided the frequency by 1000000
					MyJob->SetExecutionTimeForResource(TimeExecuteA,Cores[l]);

				}


			}
			else {
					Time *TimeExecuteA=new TimeDeterministic(ceil((double)nTickExecute/nQuartzFrequency)*nTicksPerCycle,us);  //us, since we divided the frequency by 1000000
					MyJob->SetExecutionTimeForExecutingResource(TimeExecuteA);
			}


			Time *DeadlineA = new TimeDeterministic(MyTask->GetDeadlineValue(),strToTimeUnit(MyTask->GetDeadlineUnit()));
			MyJob->SetDeadline(DeadlineA);

			if(MyJobPrev!=NULL) {
				MyJob->AddDependency(MyJobPrev);
			}
			MyJob->AddExecutingCore(Cores[0]);
			MySchedulerFIFO->AddPeriodicJob(MyJob,MaxTime);

			JobList->push_back(MyJob);
			MyJobPrev=MyJob;
		}
		AmaltheaSystem::instance()->AddJobToStimuliSourcesIfNecessary(MyTask,MyJobPrev);


	}

	AmaltheaSystem::instance()->AddTaskDependencesFromStimuli();

	MySchedulerFIFO->AddEndJob();
	MySchedulerFIFO->DetermineDependencyLevelOfAllJobs();
	MySchedulerFIFO->Initialize();

	int i;
	list<Job*>::const_iterator  it1;
	for(i=0,it1=MySchedulerFIFO->GetAllJobsList().begin();it1!=MySchedulerFIFO->GetAllJobsList().end();++it1,++i) {

		if((*it1)->GetName()=="Start" ||(*it1)->GetName()=="End") {
			continue;
		}

		JobStruct JobStructTmp;
		JobStructTmp.TID=i+1;
		JobStructTmp.TaskName=(*it1)->GetName();
		JobStructTmp.SubmissionTime.first=static_cast<int>((*it1)->GetReleaseTime()->GetValue());
		JobStructTmp.SubmissionTime.second=(*it1)->GetReleaseTime()->GetUnitAsString();
		Time *MyTime=(*it1)->GetExecutionTimeForExecutingResource();
		JobStructTmp.ExecutionTime.first=static_cast<int>(MyTime->GetValue());
		JobStructTmp.ExecutionTime.second=MyTime->GetUnitAsString();
		delete MyTime;
		JobStructTmp.Deadline.first=static_cast<int>((*it1)->GetDeadline()->GetValue());
		JobStructTmp.Deadline.second=(*it1)->GetDeadline()->GetUnitAsString();
		list<Job*> ChildrenList;
		MySchedulerFIFO->GetJobTree()->FillListOfChildren(&ChildrenList,*it1);

		list<Job*>:: iterator it2;
		for(it2=ChildrenList.begin(); it2!=ChildrenList.end() ; ++it2) {
			if((*it2)->GetName()=="Start") {
				continue;
			}
			list<Job*>:: const_iterator it3 = find(MySchedulerFIFO->GetAllJobsList().begin(), MySchedulerFIFO->GetAllJobsList().end(), *it2);
			if(it3!=MySchedulerFIFO->GetAllJobsList().end()) {
				JobStructTmp.ChildrenTids.push_back(1+distance(MySchedulerFIFO->GetAllJobsList().begin(), it3)); //1+distance - the needed TID
			}
		}

		JobStructIn.push_back(JobStructTmp);

	}

}

double TestUnit::ComputeTotalUtilisation(IAResource *CoreIn) {
	vector<Job*>::iterator it1;
	double result=0.0;
	for(it1=AllJobs->begin();it1!=AllJobs->end();++it1) {
		if((*it1)->CheckIfExecutedByCore(CoreIn)) {
			result+=(*it1)->ComputeUtilisation();
		}
	}
	return result;
}

bool TestUnit::IsLHSCoreUtilizationLowerThanRHSCore(IAResource* lhs, IAResource* rhs) {
	return ComputeTotalUtilisation(lhs)<ComputeTotalUtilisation(rhs);
}

double TestUnit::ComputeSigma(vector<Job*> *AllJobs,IAResource* CoreIn) {
	double U_gamma_p=ComputeTotalUtilisation(CoreIn);
	return (1-U_gamma_p)/(1+U_gamma_p);
}


int TestUnit::selectProcessorsForNextCluster(vector<Job*> *AllJobs,vector<IAResource*> *AllCores, int q,int i,int m) {
	//returns upper bound on cluster size
	int k_prim=1; 
	int p=q;

	double U=(*(AllJobs->begin()+i))->ComputeUtilisation();
	//the loop below calculates a provisional estimate for k_prim
	//and indentifies the first k_prim-1 processors

	while(p<=m && U>ComputeSigma(AllJobs,(*AllCores)[p-1])) { 
		//consider P_p as member of the next cluster
		U-=ComputeSigma(AllJobs,(*AllCores)[p-1]);
		k_prim++;
		p++;
	}

	//provisional k_prim has been calculated; now attempting
	//a local optimisation for the last k_prim-th processor

	for(p=m;p>=q+k_prim-1;p--) {
		if(2*(sqrt(2.0)-1.0)-ComputeTotalUtilisation((*AllCores)[p-1]) >=U) {
			break;
		}

	}

	if(p>q+k_prim-1) {
		//reindex P_p to become P_{q+k_prim-1)
		IAResource *CoreTmp=*(AllCores->begin()+(p-1));
		AllCores->erase(AllCores->begin()+(p-1));
		AllCores->insert(AllCores->begin()+(q+k_prim-1-1),CoreTmp);

		return k_prim;
	}
	else if (p==q+k_prim-1) {
		return k_prim;
	}
	else {
		//no such processor found
		return m-q+1;
	}

}


int GetIndexOfTheShortestPeriodMappedToCores(vector<IAResource*> *AllCores,vector<Job*> *AllJobs,int q,int k_prim,TimeUnit MyUnit) {
	//returns index of the task with shortes period (or interarrival time) allocated to P_{q}, ..., p_{q+k_prim-1}]
	long long ShortestPeriod=LLONG_MAX;
	int index=0;

	for(int i=q;i<q+k_prim;i++) {
		IAResource* CurrentCore=(*AllCores)[i-1];
		vector<Job*>::iterator it;
		for(it=AllJobs->begin();it!=AllJobs->end();++it) {
			if((*it)->CheckIfExecutedByCore(CurrentCore) && (*it)->GetPeriod()->GetValueInUnit(MyUnit)<ShortestPeriod) {
				ShortestPeriod=(*it)->GetPeriod()->GetValueInUnit(MyUnit);
				index=it-AllJobs->begin();
			}
		}
	}
	return index;
}

int TestUnit::SplitTask(vector<Job*> *AllJobs,vector<IAResource*> *AllCores, int j, int q, int k_prim,int m,TimeUnit MyUnit) {
	vector<IAResource*>::iterator it1,it2;
	sort(AllCores->begin()+(q-1),AllCores->begin()+(q+k_prim-1-1),&IsLHSCoreUtilizationLowerThanRHSCore);
	Time *MyTime=(*(AllJobs->begin()+j))->GetExecutionTimeForExecutingResource();
	double C=(MyTime->GetValueInUnit(MyUnit));
	delete MyTime;
	double T=(*(AllJobs->begin()+j))->GetPeriod()->GetValueInUnit(MyUnit);
	int p=1; 
	Job* PreviousJob=NULL;
	int index=0;
	while(p<=k_prim) {  
		if(C/T <= ComputeSigma(AllJobs,*(AllCores->begin()+(q+p-1-1)))) {
			break;
		}
		else {

			Job *PortionJob;
			long long PortionJobExecutionTime=(*(AllJobs->begin()+j))->GetPeriod()->GetValueInUnit(MyUnit)*ComputeSigma(AllJobs,*(AllCores->begin()+(q+p-1-1)));
			//was p-1

			TimeDeterministic *tPreemption = new TimeDeterministic(PortionJobExecutionTime,MyUnit);
			PortionJob=(*(AllJobs->begin()+j))->ExtractPrefix(tPreemption,(*(AllJobs->begin()+j))->GetTheFirstExecutingCore());
			delete tPreemption;

			string str=string(to_string(p));
			PortionJob->SetName(PortionJob->GetName()+"__%"+str);
			PortionJob->OverwriteTheFirstExecutingCore((*AllCores)[q+p-1-1]); 
			if(PreviousJob!=NULL) {
				PortionJob->AddDependency(PreviousJob);
			}
			PortionJob->SetPriority(INT_MAX);
			AllJobs->insert((AllJobs->begin()+(j+1+index++)),PortionJob);
			PreviousJob=PortionJob;
	
			C-=PortionJobExecutionTime;
			p++;
		}
	}

	if(p>k_prim) {
		return 0;
	}
	else {
		int k=p;
		for(p=m;p>=q+k_prim-1;p--) {
			if(ComputeSigma(AllJobs,*(AllCores->begin()+(p-1)))>=C/T) {
			//reindex P_p to become P_{q+k-1)
			IAResource *CoreTmp=*(AllCores->begin()+(p-1));
			AllCores->erase(AllCores->begin()+(p-1));
			AllCores->insert(AllCores->begin()+(q+k-1-1),CoreTmp);



			Job *PortionJob;
			long long PortionJobExecutionTime=C;

			TimeDeterministic *tPreemption = new TimeDeterministic(PortionJobExecutionTime,MyUnit);
			PortionJob=(*(AllJobs->begin()+j))->ExtractPrefix(tPreemption,(*(AllJobs->begin()+j))->GetTheFirstExecutingCore());
			delete tPreemption;

			string str=string(to_string(p));
			PortionJob->SetName(PortionJob->GetName()+"__%"+str);

			PortionJob->OverwriteTheFirstExecutingCore((*AllCores)[q+k-1-1]);
			PortionJob->SetPriority(INT_MAX);
			if(PreviousJob!=NULL) {
				PortionJob->AddDependency(PreviousJob);
			}


			AllJobs->insert((AllJobs->begin()+(j+1+index)),PortionJob);

			 return k;
			}
		}
	}
}



double TestUnit::TestPeriodicAmalthea(vector<int> &CoreAssignment) {

	SchedulerFIFO *MySchedulerFIFO=new SchedulerFIFO;


	Time *MaxTime = new TimeDeterministic(1000,us);

	list<Job*>* JobList=new list<Job*>;

	vector<IAResource*> Cores;

	unsigned long long nQuartzFrequency=1;
	int nTicksPerCycle=0;

	for(int l=0;l<AmaltheaSystem::instance()->GetNoOfAmCores();l++) {
		nQuartzFrequency=AmaltheaSystem::instance()->GetAmCore(l)->GetQuartz()->GetFrequency()/1000000;		
		nTicksPerCycle=AmaltheaSystem::instance()->GetAmCore(l)->GetCoreType()->GetInstructionsPerCycle();

		if(nTicksPerCycle==0) {
			nTicksPerCycle=1;
		}

		IAResource* MyCore=new IAResource(AmaltheaSystem::instance()->GetAmCore(l)->GetName());
		MyCore->SetResourceType(AmaltheaSystem::instance()->GetAmCore(l)->GetCoreType()->GetName());
		Cores.push_back(MyCore);
	}



	int nNoOfTasks=AmaltheaSystem::instance()->GetNoOfTasks();
	for(int i=0;i<nNoOfTasks;i++) {
		Task* MyTask = AmaltheaSystem::instance()->GetTask(i);
		int nNoOfRunnables=MyTask->GetNoOfRunnables();
		Job* MyJobPrev=NULL;
		for(int j=0;j<nNoOfRunnables;j++) {
			Runnable* MyRunnable = MyTask->GetRunnable(j);
			
			
			
			Job *MyJob=new Job(DoUnique(MyRunnable->GetName()));

			if(j==0) {
				//for the 1st runnable in the task only
				AmaltheaSystem::instance()->AddJobToStimuliDestinationsIfNecessary(MyTask,MyJob);
			}

			Time *TimeReleaseA;
			if(MyTask->GetStimulus()!=NULL) {
				TimeReleaseA = new TimeDeterministic(MyTask->GetStimulus()->GetOffset().first,strToTimeUnit(MyTask->GetStimulus()->GetOffset().second));
			}
			else  {
				TimeReleaseA = new TimeDeterministic(0);
			}

			MyJob->SetReleaseTime(TimeReleaseA);

			if(MyTask->GetStimulus()!=NULL) {
				Time *TimePeriodA = new TimeDeterministic(MyTask->GetStimulus()->GetRecurrence().first,strToTimeUnit(MyTask->GetStimulus()->GetRecurrence().second));
				MyJob->SetPeriod(TimePeriodA);
			}

			int nTickExecute=MyRunnable->GetWCETInTick();

			if(AmaltheaSystem::instance()->GetNoOfAmCores()>0) {
				for(int l=0;l<AmaltheaSystem::instance()->GetNoOfAmCores();l++) {
					nQuartzFrequency=AmaltheaSystem::instance()->GetAmCore(l)->GetQuartz()->GetFrequency()/1000000;		
					nTicksPerCycle=AmaltheaSystem::instance()->GetAmCore(l)->GetCoreType()->GetInstructionsPerCycle();

					if(nTicksPerCycle==0) {
						nTicksPerCycle=1;
					}


					Time *TimeExecuteA=new TimeDeterministic(ceil((double)nTickExecute/nQuartzFrequency)*nTicksPerCycle,us);  //us, since we divided the frequency by 1000000
					MyJob->SetExecutionTimeForResource(TimeExecuteA,Cores[l]);

				}


			}
			else {

					Time *TimeExecuteA=new TimeDeterministic(ceil((double)nTickExecute/nQuartzFrequency)*nTicksPerCycle,us);  //us, since we divided the frequency by 1000000
					MyJob->SetExecutionTimeForExecutingResource(TimeExecuteA);
			}


			Time *DeadlineA = new TimeDeterministic(MyTask->GetDeadlineValue(),strToTimeUnit(MyTask->GetDeadlineUnit()));
			MyJob->SetDeadline(DeadlineA);

			if(MyJobPrev!=NULL) {
				MyJob->AddDependency(MyJobPrev);
			}

			MyJob->AddExecutingCore(Cores[CoreAssignment[j]]);
			MySchedulerFIFO->AddPeriodicJob(MyJob,MaxTime);

			JobList->push_back(MyJob);
			MyJobPrev=MyJob;
		}
		AmaltheaSystem::instance()->AddJobToStimuliSourcesIfNecessary(MyTask,MyJobPrev);


	}

	AmaltheaSystem::instance()->AddTaskDependencesFromStimuli();

	MySchedulerFIFO->Preserve();
	MySchedulerFIFO->SortJobByTime();
	MySchedulerFIFO->DisplayJobTimeWithPriorities();
	double result = static_cast<double>(MySchedulerFIFO->GetLatestJob()->GetEndTime()->GetValue()) ;


		list<TreeNode* >::iterator it1;
		int i=0;
		TreeNode* Tmp;
		for (it1 = AllTreeNodes.begin(); it1!= AllTreeNodes.end(); ++it1,i++) {
				Tmp=*it1;
				*it1=NULL;
				if(i!=0 && Tmp->t->GetJobA()->GetName()=="Start") {
				}
				else {
					delete Tmp->t->GetJobA();
				}
				delete Tmp->t;
				delete Tmp;
			}
	AllTreeNodes.clear();
	NamesSet.clear();

	delete MySchedulerFIFO;


	delete JobList;

	vector<IAResource*>::iterator itCores;
	for(itCores=Cores.begin(); itCores!=Cores.end() ; ++itCores) {
		delete *itCores;
	}

	AmaltheaSystem::instance()->ClearJobs();
	
	return result;

}

double TestUnit::TestPeriodicTDMAmalthea(vector<int> &CoreAssignment) {

	TimeDeterministic MyQuantum(200,us);
	SchedulerTDM *MySchedulerTDM=new SchedulerTDM(&MyQuantum);




	Time *MaxTime = new TimeDeterministic(1000,us);

	list<Job*>* JobList=new list<Job*>;

	vector<IAResource*> Cores;

	unsigned long long nQuartzFrequency=1;
	int nTicksPerCycle=0;

	for(int l=0;l<AmaltheaSystem::instance()->GetNoOfAmCores();l++) {
		nQuartzFrequency=AmaltheaSystem::instance()->GetAmCore(l)->GetQuartz()->GetFrequency()/1000000;		
		nTicksPerCycle=AmaltheaSystem::instance()->GetAmCore(l)->GetCoreType()->GetInstructionsPerCycle();

		if(nTicksPerCycle==0) {
			nTicksPerCycle=1;
		}

		IAResource* MyCore=new IAResource(AmaltheaSystem::instance()->GetAmCore(l)->GetName());
		MyCore->SetResourceType(AmaltheaSystem::instance()->GetAmCore(l)->GetCoreType()->GetName());
		Cores.push_back(MyCore);
	}



	int nNoOfTasks=AmaltheaSystem::instance()->GetNoOfTasks();
	for(int i=0;i<nNoOfTasks;i++) {
		Task* MyTask = AmaltheaSystem::instance()->GetTask(i);
		int nNoOfRunnables=MyTask->GetNoOfRunnables();
		Job* MyJobPrev=NULL;
		for(int j=0;j<nNoOfRunnables;j++) {
			Runnable* MyRunnable = MyTask->GetRunnable(j);
			
			
			
			Job *MyJob=new Job(DoUnique(MyRunnable->GetName()));

			if(j==0) {
				//for the 1st runnable in the task only
				AmaltheaSystem::instance()->AddJobToStimuliDestinationsIfNecessary(MyTask,MyJob);
			}

			Time *TimeReleaseA;
			if(MyTask->GetStimulus()!=NULL) {
				TimeReleaseA = new TimeDeterministic(MyTask->GetStimulus()->GetOffset().first,strToTimeUnit(MyTask->GetStimulus()->GetOffset().second));
			}
			else  {
				TimeReleaseA = new TimeDeterministic(0);
			}

			MyJob->SetReleaseTime(TimeReleaseA);

			if(MyTask->GetStimulus()!=NULL) {
				Time *TimePeriodA = new TimeDeterministic(MyTask->GetStimulus()->GetRecurrence().first,strToTimeUnit(MyTask->GetStimulus()->GetRecurrence().second));
				MyJob->SetPeriod(TimePeriodA);
			}

			int nTickExecute=MyRunnable->GetWCETInTick();

			if(AmaltheaSystem::instance()->GetNoOfAmCores()>0) {
				for(int l=0;l<AmaltheaSystem::instance()->GetNoOfAmCores();l++) {
					nQuartzFrequency=AmaltheaSystem::instance()->GetAmCore(l)->GetQuartz()->GetFrequency()/1000000;		
					nTicksPerCycle=AmaltheaSystem::instance()->GetAmCore(l)->GetCoreType()->GetInstructionsPerCycle();

					if(nTicksPerCycle==0) {
						nTicksPerCycle=1;
					}

					Time *TimeExecuteA=new TimeDeterministic(ceil((double)nTickExecute/nQuartzFrequency)*nTicksPerCycle,us);  //us, since we divided the frequency by 1000000
					MyJob->SetExecutionTimeForResource(TimeExecuteA,Cores[l]);

				}


			}
			else {

					Time *TimeExecuteA=new TimeDeterministic(ceil((double)nTickExecute/nQuartzFrequency)*nTicksPerCycle,us);  //us, since we divided the frequency by 1000000
					MyJob->SetExecutionTimeForExecutingResource(TimeExecuteA);
			}


			Time *DeadlineA = new TimeDeterministic(MyTask->GetDeadlineValue(),strToTimeUnit(MyTask->GetDeadlineUnit()));
			MyJob->SetDeadline(DeadlineA);

			if(MyJobPrev!=NULL) {
				MyJob->AddDependency(MyJobPrev);
			}

			MyJob->AddExecutingCore(Cores[CoreAssignment[j]]);
			MySchedulerTDM->AddPeriodicJob(MyJob,MaxTime);

			JobList->push_back(MyJob);
			MyJobPrev=MyJob;
		}
		AmaltheaSystem::instance()->AddJobToStimuliSourcesIfNecessary(MyTask,MyJobPrev);


	}

	AmaltheaSystem::instance()->AddTaskDependencesFromStimuli();

	MySchedulerTDM->Preserve();
	MySchedulerTDM->SortJobByTime();
	MySchedulerTDM->DisplayJobTimeWithPriorities();
	double result = static_cast<double>(MySchedulerTDM->GetLatestJob()->GetEndTime()->GetValue()) ;

		list<TreeNode* >::iterator it1;
		int i=0;
		TreeNode* Tmp;
		for (it1 = AllTreeNodes.begin(); it1!= AllTreeNodes.end(); ++it1,i++) {
				Tmp=*it1;
				*it1=NULL;
				if(i!=0 && Tmp->t->GetJobA()->GetName()=="Start") {
				}
				else {
					delete Tmp->t->GetJobA();
				}
				delete Tmp->t;
				delete Tmp;
			}
	AllTreeNodes.clear();
	NamesSet.clear();

	delete MySchedulerTDM;


	delete JobList;

	vector<IAResource*>::iterator itCores;
	for(itCores=Cores.begin(); itCores!=Cores.end() ; ++itCores) {
		delete *itCores;
	}

	AmaltheaSystem::instance()->ClearJobs();
	
	return result;

}


void TestUnit::ParseAmalthea(string &FileName) {
	AmaltheaParser MyAmaltheaParser;
	MyAmaltheaParser.ParseAmaltheaFile(FileName,AmaltheaSystem::instance());
	
}

double TestUnit::TestAmaltheaPriorities(vector<int> &TaskPriorities) {


	SchedulerPriorityNonPreemptive *MyScheduler=new SchedulerPriorityNonPreemptive;


	map<Runnable*,Job*> mapRunnableJob;

	int AddedTasks=0;

	clock_t start, end;
	start = clock();

	list<Job*>* JobList=new list<Job*>;
 
	vector<IAResource*> Cores;

	unsigned long long nQuartzFrequency=1;
	int nTicksPerCycle=0;

	int nNoOfCores=4;

	for(int l=0;l<nNoOfCores;l++) {
		nQuartzFrequency=AmaltheaSystem::instance()->GetAmCore(0)->GetQuartz()->GetFrequency()/1000000;		
		nTicksPerCycle=AmaltheaSystem::instance()->GetAmCore(0)->GetCoreType()->GetInstructionsPerCycle();

		if(nTicksPerCycle==0) {
			nTicksPerCycle=1;
		}

		IAResource* MyCore=new IAResource(AmaltheaSystem::instance()->GetAmCore(0)->GetName()+"__"+to_string(l));
		MyCore->SetResourceType(AmaltheaSystem::instance()->GetAmCore(0)->GetCoreType()->GetName());
		Cores.push_back(MyCore);
	}
	

	int nNoOfTasks=AmaltheaSystem::instance()->GetNoOfTasks();
	for(int i=0;i<nNoOfTasks;i++) {
		Task* MyTask = AmaltheaSystem::instance()->GetTask(i);
		int nNoOfRunnables=MyTask->GetNoOfRunnables();
		Job* MyJobPrev=NULL;
		for(int j=0;j<nNoOfRunnables;j++) {
			Runnable* MyRunnable = MyTask->GetRunnable(j);
			
			
			
			Job *MyJob=new Job(DoUnique(MyRunnable->GetName()));
			mapRunnableJob[MyRunnable]=MyJob;

			if(j==0) {
				//for the 1st runnable in the task only
				AmaltheaSystem::instance()->AddJobToStimuliDestinationsIfNecessary(MyTask,MyJob);
			}

			Time *TimeReleaseA;
			if(MyTask->GetStimulus()!=NULL) {
				TimeReleaseA = new TimeDeterministic(MyTask->GetStimulus()->GetOffset().first,strToTimeUnit(MyTask->GetStimulus()->GetOffset().second));
			}
			else  {
				TimeReleaseA = new TimeDeterministic(0);
			}

			MyJob->SetReleaseTime(TimeReleaseA);

			if(MyTask->GetStimulus()!=NULL) {
				Time *TimePeriodA = new TimeDeterministic(MyTask->GetStimulus()->GetRecurrence().first,strToTimeUnit(MyTask->GetStimulus()->GetRecurrence().second));
				MyJob->SetPeriod(TimePeriodA);
			}

			int nTickExecute=MyRunnable->GetWCETInTick();

			if(nNoOfCores>0) {
				for(int l=0;l<nNoOfCores;l++) {
					nQuartzFrequency=AmaltheaSystem::instance()->GetAmCore(0)->GetQuartz()->GetFrequency()/1000000;		
					nTicksPerCycle=AmaltheaSystem::instance()->GetAmCore(0)->GetCoreType()->GetInstructionsPerCycle();

					if(nTicksPerCycle==0) {
						nTicksPerCycle=1;
					}

					Time *TimeExecuteA=new TimeDeterministic(ceil((double)nTickExecute/nQuartzFrequency)*nTicksPerCycle,us);  //us, since we divided the frequency by 1000000
					MyJob->SetExecutionTimeForResource(TimeExecuteA,Cores[l]);

				}


			}
			else {

					Time *TimeExecuteA=new TimeDeterministic(ceil((double)nTickExecute/nQuartzFrequency)*nTicksPerCycle,us);  //us, since we divided the frequency by 1000000
					MyJob->SetExecutionTimeForExecutingResource(TimeExecuteA);
			}


			Time *DeadlineA = new TimeDeterministic(MyTask->GetDeadlineValue(),strToTimeUnit(MyTask->GetDeadlineUnit()));
			MyJob->SetDeadline(DeadlineA);

			MyJob->AddExecutingCore(Cores[j%nNoOfCores]);
			MyJob->SetPriority(TaskPriorities[j]);
			MyScheduler->AddJobA(MyJob);
			JobList->push_back(MyJob);
			MyJobPrev=MyJob;
		}
		AmaltheaSystem::instance()->AddJobToStimuliSourcesIfNecessary(MyTask,MyJobPrev);


	}

	AmaltheaSystem::instance()->AddTaskDependencesFromStimuli();




	MyScheduler->Preserve();
	end = clock();
	MyScheduler->ComputeDeadlineCounters();

	double result = static_cast<int>(MyScheduler->GetLatestJob()->GetEndTime()->GetValue());
	result+=	MyScheduler->GetAfterDeadlineCounter()*10000;


		list<TreeNode* >::iterator it1;
		int i=0;
		TreeNode* Tmp;
		for (it1 = AllTreeNodes.begin(); it1!= AllTreeNodes.end(); ++it1,i++) {
				Tmp=*it1;
				*it1=NULL;
				if(i!=0 && Tmp->t->GetJobA()->GetName()=="Start") {
				}
				else {
					delete Tmp->t->GetJobA();
				}
				delete Tmp->t;
				delete Tmp;
			}
	AllTreeNodes.clear();
	NamesSet.clear();
	delete MyScheduler;


	delete JobList;

	vector<IAResource*>::iterator itCores2;
	for(itCores2=Cores.begin(); itCores2!=Cores.end() ; ++itCores2) {
		delete *itCores2;
	}

	mapCoreTime.clear();
	mapJob_TreeNode.clear();
	MyCores.clear();
	MyLinks.clear();
	mapNameCore.clear();
	mapNameLink.clear();


	AmaltheaSystem::instance()->ClearJobs();

	return result;
}



double TestUnit::TestAmaltheaNoCPriorities(vector<int> &TaskPriorities,int NoCXSize, int NoCYSize) {

	const int BytesPerMS=1000;
	SchedulerPriorityPreemptive *MyScheduler=new SchedulerPriorityPreemptive;


	map<Runnable*,Job*> mapRunnableJob;

	int AddedTasks=0;

	clock_t start, end;
	start = clock();

	list<Job*>* JobList=new list<Job*>;


	unsigned long long nQuartzFrequency=1;
	int nTicksPerCycle=0;

	if(AmaltheaSystem::instance()->GetNoOfAmCores()<1) {
		cout << "Error. No core description in the Amalthea file.";
		exit(-1);
	}




	MyCores.reserve(NoCXSize*NoCYSize);
	MyLinks.reserve(4*(NoCXSize-1)*NoCYSize+2*NoCXSize*NoCYSize);


	for(int y=0;y<NoCYSize;y++) {
		for(int x=0;x<NoCXSize;x++) {
			IAResource* MyCore = new IAResource("Core_"+to_string(x)+"_"+to_string(y));
			MyCore->SetDynamicEnergyMultiplierPerClockCycle(0.5);
			MyCore->SetResourceType(AmaltheaSystem::instance()->GetAmCore(0)->GetCoreType()->GetName());
			MyCores.push_back(MyCore);
			MyScheduler->AddCore(MyCore);
			mapNameCore[MyCore->GetName()]=MyCore;
		}
	}


	vector<IAResource*>::iterator itCores;
	vector<IAResource*>::iterator itCoresNoC;

	for(int y=0;y<NoCYSize;y++) {
		for(int x=0;x<NoCXSize-1;x++) {
			IAResource* MyLink1 = new IAResource("Router_"+to_string(x)+"_"+to_string(y)+"-Router_"+to_string(x+1)+"_"+to_string(y));
			IAResource* MyLink2 = new IAResource("Router_"+to_string(x+1)+"_"+to_string(y)+"-Router_"+to_string(x)+"_"+to_string(y));
			MyLink1->SetDynamicEnergyMultiplierPerClockCycle(0.1);
			MyLink2->SetDynamicEnergyMultiplierPerClockCycle(0.1);
			MyLinks.push_back(MyLink1);
			MyLinks.push_back(MyLink2);
			MyScheduler->AddCore(MyLink1);
			MyScheduler->AddCore(MyLink2);
			mapNameLink[MyLink1->GetName()]=MyLink1;
			mapNameLink[MyLink2->GetName()]=MyLink2;
		}
	}


	for(int x=0;x<NoCXSize;x++) {
		for(int y=0;y<NoCYSize-1;y++) {
			IAResource* MyLink1 = new IAResource("Router_"+to_string(x)+"_"+to_string(y)+"-Router_"+to_string(x)+"_"+to_string(y+1));
			IAResource* MyLink2 = new IAResource("Router_"+to_string(x)+"_"+to_string(y+1)+"-Router_"+to_string(x)+"_"+to_string(y));
			MyLink1->SetDynamicEnergyMultiplierPerClockCycle(0.1);
			MyLink2->SetDynamicEnergyMultiplierPerClockCycle(0.1);
			MyLinks.push_back(MyLink1);
			MyLinks.push_back(MyLink2);
			MyScheduler->AddCore(MyLink1);
			MyScheduler->AddCore(MyLink2);
			mapNameLink[MyLink1->GetName()]=MyLink1;
			mapNameLink[MyLink2->GetName()]=MyLink2;
		}
	}


		for(int y=0;y<NoCYSize;y++) {
		for(int x=0;x<NoCXSize;x++) {
			IAResource* MyLink1 = new IAResource("Core_"+to_string(x)+"_"+to_string(y)+"-Router_"+to_string(x)+"_"+to_string(y));
			IAResource* MyLink2 = new IAResource("Router_"+to_string(x)+"_"+to_string(y)+"-Core_"+to_string(x)+"_"+to_string(y));
			MyLink1->SetDynamicEnergyMultiplierPerClockCycle(0.1);
			MyLink2->SetDynamicEnergyMultiplierPerClockCycle(0.1);
			MyLinks.push_back(MyLink1);
			MyLinks.push_back(MyLink2);
			MyScheduler->AddCore(MyLink1);
			MyScheduler->AddCore(MyLink2);
			mapNameLink[MyLink1->GetName()]=MyLink1;
			mapNameLink[MyLink2->GetName()]=MyLink2;
		}
	}

	int nNoOfTasks=AmaltheaSystem::instance()->GetNoOfTasks();
	for(int i=0;i<nNoOfTasks;i++) {
		Task* MyTask = AmaltheaSystem::instance()->GetTask(i);
		int nNoOfRunnables=MyTask->GetNoOfRunnables();
		Job* MyJobPrev=NULL;
		for(int j=0;j<nNoOfRunnables;j++) {
			Runnable* MyRunnable = MyTask->GetRunnable(j);
			
			
			
			Job *MyJob=new Job(DoUnique(MyRunnable->GetName()));
			mapRunnableJob[MyRunnable]=MyJob;

			if(j==0) {
				//for the 1st runnable in the task only
				AmaltheaSystem::instance()->AddJobToStimuliDestinationsIfNecessary(MyTask,MyJob);
			}

			Time *TimeReleaseA;
			if(MyTask->GetStimulus()!=NULL) {
				TimeReleaseA = new TimeDeterministic(MyTask->GetStimulus()->GetOffset().first,strToTimeUnit(MyTask->GetStimulus()->GetOffset().second));
			}
			else  {
				TimeReleaseA = new TimeDeterministic(0);
			}

			MyJob->SetReleaseTime(TimeReleaseA);

			if(MyTask->GetStimulus()!=NULL) {
				Time *TimePeriodA = new TimeDeterministic(MyTask->GetStimulus()->GetRecurrence().first,strToTimeUnit(MyTask->GetStimulus()->GetRecurrence().second));
				MyJob->SetPeriod(TimePeriodA);
			}

			int nTickExecute=MyRunnable->GetWCETInTick();

			for(int l=0;l<MyCores.size();l++) {
				nQuartzFrequency=AmaltheaSystem::instance()->GetAmCore(0)->GetQuartz()->GetFrequency()/1000000;		
				nTicksPerCycle=AmaltheaSystem::instance()->GetAmCore(0)->GetCoreType()->GetInstructionsPerCycle();

				if(nTicksPerCycle==0) {
					nTicksPerCycle=1;
				}

				Time *TimeExecuteA=new TimeDeterministic(ceil((double)nTickExecute/nQuartzFrequency)*nTicksPerCycle,us);  //us, since we divided the frequency by 1000000
				MyJob->SetExecutionTimeForResource(TimeExecuteA,MyCores[l]);

			}

			int IndexOfRunnable=AmaltheaSystem::instance()->GetIndexOfRunnable(MyRunnable);
			MyJob->AddExecutingCore(MyCores[j%NoCXSize*NoCYSize]);
			MyJob->SetPriority(TaskPriorities[j]);

			Time *DeadlineA = new TimeDeterministic(MyTask->GetDeadlineValue(),strToTimeUnit(MyTask->GetDeadlineUnit()));
			MyJob->SetDeadline(DeadlineA);

			if(MyJobPrev!=NULL) {
				MyJob->AddDependency(MyJobPrev);
			}


			for(int k=0;k<MyRunnable->GetNoOfInstructions();k++) {
				if(MyRunnable->GetNameOfInstruction(k)=="sw:LabelAccess") {
					Job* MyTransferJob;
					list<IAResource*>* Path;
					string LabelName=MyRunnable->GetLabelNameOfLabelAccessInstruction(k);
					Label* MyLabel=AmaltheaSystem::instance()->GetLabelByName(LabelName);
					int IndexOfLabel=AmaltheaSystem::instance()->GetIndexOfLabel(MyLabel);
					IAResource *LabelCore=MyCores[IndexOfLabel%NoCXSize*NoCYSize];
					bool IsWrite=MyRunnable->CheckIfWriteAccessInstruction(k);
					if(IsWrite) {
						MyTransferJob=new Job(DoUnique("Comm_"+MyRunnable->GetName()+"_L:"+LabelName));
						MyTransferJob->AddDependency(MyJob);
						MyJob->SynchrNoC.push_back(MyTransferJob);
						Path=GetPathBetween(MyJob->GetTheFirstExecutingCore(),LabelCore);
					}
					else {
						MyTransferJob=new Job(DoUnique("Comm_L:"+LabelName+"_"+MyRunnable->GetName()));
						MyJob->AddDependency(MyTransferJob);
						Path=GetPathBetween(LabelCore,MyJob->GetTheFirstExecutingCore());
					}

					Time *MyReleaseTime=new TimeDeterministic(0);
					MyTransferJob->SetReleaseTime(MyReleaseTime);
					Time *TimeDeadline=MyJob->GetDeadline()->Clone();
					MyTransferJob->SetDeadline(TimeDeadline);
					Time *TimePeriod=MyJob->GetPeriod()->Clone();
					MyTransferJob->SetPeriod(TimePeriod);
					MyTransferJob->SetPriority(MyJob->GetPriority());


					if(Path->size()==0) { //src and dest are in the same core
						MyTransferJob->SetExecutingCores(MyJob->GetExecutingCores());
					}
					else {
						MyTransferJob->SetExecutingCores(Path);
					}
					delete Path;


					Time *MyComputationTime=new TimeDeterministic(static_cast<int>(ceil(static_cast<double>(MyLabel->GetSize())/BytesPerMS)),ms);
					MyTransferJob->SetExecutionTimeForExecutingResource(MyComputationTime);

					MyScheduler->AddJobA(MyTransferJob);
					JobList->push_back(MyTransferJob);

					AddedTasks++;


				}
			}

			
		



			MyScheduler->AddJobA(MyJob);
			JobList->push_back(MyJob);
			AddedTasks++;

			if(MyJobPrev!=NULL && MyJob->GetTheFirstExecutingCore()!=MyJobPrev->GetTheFirstExecutingCore()) {


				Job* MySynchronizationJob;
				list<IAResource*>* Path;

				MySynchronizationJob=new Job(DoUnique("Synch_"+MyJobPrev->GetName()+"_"+MyJob->GetName()));
				MySynchronizationJob->AddDependency(MyJobPrev);
				MyJobPrev->SynchrNoC.push_back(MySynchronizationJob);
				MyJob->AddDependency(MySynchronizationJob);
				Path=GetPathBetween(MyJobPrev->GetTheFirstExecutingCore(),MyJob->GetTheFirstExecutingCore());



				Time *MyReleaseTime=new TimeDeterministic(0);
				MySynchronizationJob->SetReleaseTime(MyReleaseTime);
				Time *TimeDeadline=MyJob->GetDeadline()->Clone();
				MySynchronizationJob->SetDeadline(TimeDeadline);
				Time *TimePeriod=MyJobPrev->GetPeriod()->Clone();
				MySynchronizationJob->SetPeriod(TimePeriod);
				MySynchronizationJob->SetPriority(MyJobPrev->GetPriority());

				MySynchronizationJob->SetExecutingCores(Path);
				delete Path;


				Time *MyComputationTime=new TimeDeterministic(static_cast<int>(ceil(1.0/BytesPerMS)),ms);
				MySynchronizationJob->SetExecutionTimeForExecutingResource(MyComputationTime);

				MyScheduler->AddJobA(MySynchronizationJob);
				JobList->push_back(MySynchronizationJob);

				AddedTasks++;

			}


			MyJobPrev=MyJob;
		}
	AmaltheaSystem::instance()->AddJobToStimuliSourcesIfNecessary(MyTask,MyJobPrev);


	}

	AmaltheaSystem::instance()->AddTaskDependencesFromStimuli();

	
	MyScheduler->Preserve();
	double result = static_cast<int>(MyScheduler->GetLatestJob()->GetEndTime()->GetValue());

		list<TreeNode* >::iterator it1;
		int i=0;
		TreeNode* Tmp;
		for (it1 = AllTreeNodes.begin(); it1!= AllTreeNodes.end(); ++it1,i++) {
				Tmp=*it1;
				*it1=NULL;
				if(i!=0 && Tmp->t->GetJobA()->GetName()=="Start") {
				}
				else {
					delete Tmp->t->GetJobA();
				}
				delete Tmp->t;
				delete Tmp;
			}
	AllTreeNodes.clear();
	NamesSet.clear();

	delete MyScheduler;


	delete JobList;

	vector<IAResource*>::iterator itCores2;
	for(itCores2=MyCores.begin(); itCores2!=MyCores.end() ; ++itCores2) {
		delete *itCores2;
	}

	for(itCores2=MyLinks.begin(); itCores2!=MyLinks.end() ; ++itCores2) {
		delete *itCores2;
	}



	mapCoreTime.clear();
	mapJob_TreeNode.clear();
	MyCores.clear();
	MyLinks.clear();
	mapNameCore.clear();
	mapNameLink.clear();

	end = clock();
    cout << "Time required for execution: "
    << (double)(end-start)/CLOCKS_PER_SEC
    << " seconds." << "\n\n";

	AmaltheaSystem::instance()->ClearJobs();
	cout << "Result " << result <<endl;
	return result;
}

TestUnit::TestUnit(): CTTransactionMode(false) {
}

pair<double,double>  TestUnit::TestAmalthea(vector<int> &CoreAssignment, int nNoOfCores) {


	SchedulerFIFO *MyScheduler=new SchedulerFIFO;



	map<Runnable*,Job*> mapRunnableJob;

	int AddedTasks=0;

	clock_t start, end;
	start = clock();

	list<Job*>* JobList=new list<Job*>;
 
	vector<IAResource*> Cores;

	unsigned long long nQuartzFrequency=1;
	int nTicksPerCycle=0;


	pair<int,string> HyperPeriodPair=AmaltheaSystem::instance()->GetHyperPeriod();
	Time* HyperPeriod=NULL;
	if(HyperPeriodPair.first>0 && (HyperPeriodPair.second=="ns" || HyperPeriodPair.second=="us" || HyperPeriodPair.second=="ms" || HyperPeriodPair.second=="s")) {
		HyperPeriod=new TimeDeterministic(HyperPeriodPair.first,strToTimeUnit(HyperPeriodPair.second));
	}

	for(int l=0;l<nNoOfCores;l++) {

		nQuartzFrequency=AmaltheaSystem::instance()->GetAmCore(0)->GetQuartz()->GetFrequency()/1000000;		
		nTicksPerCycle=AmaltheaSystem::instance()->GetAmCore(0)->GetCoreType()->GetInstructionsPerCycle();


		if(nTicksPerCycle==0) {
			nTicksPerCycle=1;
		}

		IAResource* MyCore=new IAResource(AmaltheaSystem::instance()->GetAmCore(0)->GetName());
		MyCore->SetResourceType(AmaltheaSystem::instance()->GetAmCore(0)->GetCoreType()->GetName());
		MyCore->SetStaticEnergyPerTimeUnit(StaticEnergyPercentageWRTDynamicEnergy*1,us);
		MyCore->GetResourceType()->AddVoltageFrequencyLevel(1.484,1.6);
		MyCore->GetResourceType()->AddVoltageFrequencyLevel(1.420,1.4);
		MyCore->GetResourceType()->AddVoltageFrequencyLevel(1.276,1.2);
		MyCore->GetResourceType()->AddVoltageFrequencyLevel(1.164,1.0);
		MyCore->GetResourceType()->AddVoltageFrequencyLevel(1.036,0.8);
		MyCore->GetResourceType()->AddVoltageFrequencyLevel(0.956,0.6);
		MyCore->GetResourceType()->SetSwitchingPModeEnergyPenalty(1.0);
		MyCore->SetDynamicEnergyMultiplierPerClockCycle(0.5);

		MyCore->SetCurrentPMode(0);

		Cores.push_back(MyCore);
		MyScheduler->AddCore(MyCore);
	}


	int nNoOfTasks=AmaltheaSystem::instance()->GetNoOfTasks();


	for(int i=0;i<nNoOfTasks;i++) {
		Task* MyTask = AmaltheaSystem::instance()->GetTask(i);
		int nNoOfRunnables=MyTask->GetNoOfRunnables();
		Job* MyJobPrev=NULL;
		for(int j=0;j<nNoOfRunnables;j++) {
			Runnable* MyRunnable = MyTask->GetRunnable(j);
			
			
			
			Job *MyJob=new Job(DoUnique(MyRunnable->GetName()));
			mapRunnableJob[MyRunnable]=MyJob;

			if(j==0) {
				//for the 1st runnable in the task only
				AmaltheaSystem::instance()->AddJobToStimuliDestinationsIfNecessary(MyTask,MyJob);
			}

			Time *TimeReleaseA;
			if(MyTask->GetStimulus()!=NULL) {
				TimeReleaseA = new TimeDeterministic(MyTask->GetStimulus()->GetOffset().first,strToTimeUnit(MyTask->GetStimulus()->GetOffset().second));
			}
			else  {
				TimeReleaseA = new TimeDeterministic(0);
			}

			MyJob->SetReleaseTime(TimeReleaseA);

			if(MyTask->GetStimulus()!=NULL) {
				Time *TimePeriodA = new TimeDeterministic(MyTask->GetStimulus()->GetRecurrence().first,strToTimeUnit(MyTask->GetStimulus()->GetRecurrence().second));
				MyJob->SetPeriod(TimePeriodA);
			}

			int nTickExecute=MyRunnable->GetWCETInTick();

			if(nNoOfCores>0) {
				for(int l=0;l<nNoOfCores;l++) {
					nQuartzFrequency=AmaltheaSystem::instance()->GetAmCore(0)->GetQuartz()->GetFrequency()/1000000;		
					nTicksPerCycle=AmaltheaSystem::instance()->GetAmCore(0)->GetCoreType()->GetInstructionsPerCycle();

					if(nTicksPerCycle==0) {
						nTicksPerCycle=1;
					}

					Time *TimeExecuteA=new TimeDeterministic(ceil((double)nTickExecute/nQuartzFrequency)*nTicksPerCycle,us);  //us, since we divided the frequency by 1000000
					MyJob->SetExecutionTimeForResource(TimeExecuteA,Cores[l]);

				}


			}
			else {

					Time *TimeExecuteA=new TimeDeterministic(ceil((double)nTickExecute/nQuartzFrequency)*nTicksPerCycle,us);  //us, since we divided the frequency by 1000000
					MyJob->SetExecutionTimeForExecutingResource(TimeExecuteA);
			}


			Time *DeadlineA = new TimeDeterministic(MyTask->GetDeadlineValue(),strToTimeUnit(MyTask->GetDeadlineUnit()));
			MyJob->SetDeadline(DeadlineA);


			MyJob->AddExecutingCore(Cores[CoreAssignment[j]%nNoOfCores]);

			if(MyJob->GetPeriod()!=NULL && MyJob->GetPeriod()->GetValue()!=0 && HyperPeriod!=NULL) {
				MyScheduler->AddPeriodicJob(MyJob,HyperPeriod);
			}
			else {
				MyScheduler->AddJobA(MyJob);
			}

			JobList->push_back(MyJob);
			MyJobPrev=MyJob;
		}
		AmaltheaSystem::instance()->AddJobToStimuliSourcesIfNecessary(MyTask,MyJobPrev);


	}

	AmaltheaSystem::instance()->AddTaskDependencesFromStimuli();



	MyScheduler->Preserve();
	end = clock();
	MyScheduler->SortJobByTime();


	
	pair<double,double> result;
	result.first = static_cast<int>(MyScheduler->GetLatestJob()->GetEndTime()->GetValue());
	cout << "Deadline misses: " << MyScheduler->GetAfterDeadlineCounter() << endl;
	result.second=	MyScheduler->GetEnergy();

	cout << "EndTime: " << result.first << endl;
	cout << "Energy: " << result.second << endl;
	result.first=	MyScheduler->GetAfterDeadlineCounter();

		list<TreeNode* >::iterator it1;
		int i=0;
		TreeNode* Tmp;
		for (it1 = AllTreeNodes.begin(); it1!= AllTreeNodes.end(); ++it1,i++) {
				Tmp=*it1;
				*it1=NULL;
				if(i!=0 && Tmp->t->GetJobA()->GetName()=="Start") {
				}
				else {
					delete Tmp->t->GetJobA();
				}
				delete Tmp->t;
				delete Tmp;
			}
	AllTreeNodes.clear();
	NamesSet.clear();
	delete MyScheduler;


	delete JobList;

	vector<IAResource*>::iterator itCores2;
	for(itCores2=Cores.begin(); itCores2!=Cores.end() ; ++itCores2) {
		delete *itCores2;
	}

	mapCoreTime.clear();
	mapJob_TreeNode.clear();
	MyCores.clear();
	MyLinks.clear();
	mapNameCore.clear();
	mapNameLink.clear();

	AmaltheaSystem::instance()->ClearJobs();

	delete HyperPeriod;


	return result;
}











double TestUnit::TestStochasticAmalthea(vector<int> &CoreAssignment) {

	SchedulerFIFO *MySchedulerFIFO=new SchedulerFIFO;

	int l1=0;
	unsigned long long nQuartzFrequency1=AmaltheaSystem::instance()->GetAmCore(l1)->GetQuartz()->GetFrequency()/1000000;		
	int nTicksPerCycle1=AmaltheaSystem::instance()->GetAmCore(l1)->GetCoreType()->GetInstructionsPerCycle();
	unsigned long long LowerBound1=72000;
	unsigned long long UpperBound1=88000;
	double RemainPromille1=0.5;


	pair<int,string> HyperPeriodPair=AmaltheaSystem::instance()->GetHyperPeriod();
	Time* HyperPeriod=NULL;
	if(HyperPeriodPair.first>0 && (HyperPeriodPair.second=="ns" || HyperPeriodPair.second=="us" || HyperPeriodPair.second=="ms" || HyperPeriodPair.second=="s")) {
		HyperPeriod=new TimeDeterministic(HyperPeriodPair.first,strToTimeUnit(HyperPeriodPair.second));
	}

	TimeStochastic *TimeExecuteA=new TimeStochastic(us);
	TimeExecuteA->CreateWeibullDistribution(static_cast<int>(LowerBound1/nQuartzFrequency1*nTicksPerCycle1),static_cast<int>(UpperBound1/nQuartzFrequency1*nTicksPerCycle1),RemainPromille1);
	

	clock_t start, end;
	start = clock();

	list<Job*>* JobList=new list<Job*>;

	vector<IAResource*> Cores;

	unsigned long long nQuartzFrequency=1;
	int nTicksPerCycle=0;

	for(int l=0;l<AmaltheaSystem::instance()->GetNoOfAmCores();l++) {
		nQuartzFrequency=AmaltheaSystem::instance()->GetAmCore(l)->GetQuartz()->GetFrequency()/1000000;		
		nTicksPerCycle=AmaltheaSystem::instance()->GetAmCore(l)->GetCoreType()->GetInstructionsPerCycle();

		if(nTicksPerCycle==0) {
			nTicksPerCycle=1;
		}

		IAResource* MyCore=new IAResource(AmaltheaSystem::instance()->GetAmCore(l)->GetName());
		MyCore->SetResourceType(AmaltheaSystem::instance()->GetAmCore(l)->GetCoreType()->GetName());
		Cores.push_back(MyCore);
	}



	int nNoOfTasks=AmaltheaSystem::instance()->GetNoOfTasks();
	for(int i=0;i<nNoOfTasks;i++) {
		Task* MyTask = AmaltheaSystem::instance()->GetTask(i);
		int nNoOfRunnables=MyTask->GetNoOfRunnables();
		Job* MyJobPrev=NULL;
		for(int j=0;j<nNoOfRunnables;j++) {
			Runnable* MyRunnable = MyTask->GetRunnable(j);
			
			
			Job *MyJob=new Job(DoUnique(MyRunnable->GetName()));

			if(j==0) {
				//for the 1st runnable in the task only
				AmaltheaSystem::instance()->AddJobToStimuliDestinationsIfNecessary(MyTask,MyJob);
			}

			Time *TimeReleaseA;
			if(MyTask->GetStimulus()!=NULL) {
				TimeReleaseA = new TimeDeterministic(MyTask->GetStimulus()->GetOffset().first,strToTimeUnit(MyTask->GetStimulus()->GetOffset().second));
			}
			else  {
				TimeReleaseA = new TimeDeterministic(0);
			}

			MyJob->SetReleaseTime(TimeReleaseA);

			if(MyTask->GetStimulus()!=NULL) {
				Time *TimePeriodA = new TimeDeterministic(MyTask->GetStimulus()->GetRecurrence().first,strToTimeUnit(MyTask->GetStimulus()->GetRecurrence().second));
				MyJob->SetPeriod(TimePeriodA);
			}


			if(MyRunnable->CheckIfIncludesExecutionCyclesDeviationInstruction()) {
				string strDeviationName=MyRunnable->GetTheFirstDeviationType();
				if(strDeviationName=="common:WeibullEstimators") {
					double RemainPromille=MyRunnable->GetTheFirstDeviationRemainPromille();
					int LowerBound=MyRunnable->GetTheFirstDeviationLowerBound();
					int UpperBound=MyRunnable->GetTheFirstDeviationUpperBound();


					if(AmaltheaSystem::instance()->GetNoOfAmCores()>0) {
						for(int l=0;l<AmaltheaSystem::instance()->GetNoOfAmCores();l++) {
							nQuartzFrequency=AmaltheaSystem::instance()->GetAmCore(l)->GetQuartz()->GetFrequency()/1000000;		
							nTicksPerCycle=AmaltheaSystem::instance()->GetAmCore(l)->GetCoreType()->GetInstructionsPerCycle();

							if(nTicksPerCycle==0) {
								nTicksPerCycle=1;
							}
							//us, since we divided the frequency by 1000000
							TimeStochastic *TimeExecuteA=new TimeStochastic(us);
							TimeExecuteA->CreateWeibullDistribution(static_cast<int>(LowerBound/nQuartzFrequency*nTicksPerCycle),static_cast<int>(UpperBound/nQuartzFrequency*nTicksPerCycle),RemainPromille);
							MyJob->SetExecutionTimeForResource(TimeExecuteA,Cores[l]);

						}
					}
					else {

							TimeStochastic *TimeExecuteA=new TimeStochastic(us);
							TimeExecuteA->CreateWeibullDistribution(static_cast<int>(LowerBound/nQuartzFrequency*nTicksPerCycle),static_cast<int>(UpperBound/nQuartzFrequency*nTicksPerCycle),RemainPromille);
							MyJob->SetExecutionTimeForExecutingResource(TimeExecuteA);
					}
				}
				else if(strDeviationName=="common:GaussDistribution") {
					double Mean=MyRunnable->GetTheFirstDeviationMean();
					double StdDev=MyRunnable->GetTheFirstDeviationStandardDeviation();
					int LowerBound=MyRunnable->GetTheFirstDeviationLowerBound();
					int UpperBound=MyRunnable->GetTheFirstDeviationUpperBound();


					if(AmaltheaSystem::instance()->GetNoOfAmCores()>0) {
						for(int l=0;l<AmaltheaSystem::instance()->GetNoOfAmCores();l++) {
							nQuartzFrequency=AmaltheaSystem::instance()->GetAmCore(l)->GetQuartz()->GetFrequency()/1000000;		
							nTicksPerCycle=AmaltheaSystem::instance()->GetAmCore(l)->GetCoreType()->GetInstructionsPerCycle();

							if(nTicksPerCycle==0) {
								nTicksPerCycle=1;
							}
							//us, since we divided the frequency by 1000000
							TimeStochastic *TimeExecuteA=new TimeStochastic(us);
							TimeExecuteA->CreateNormalDistribution(static_cast<int>(LowerBound/nQuartzFrequency*nTicksPerCycle),static_cast<int>(UpperBound/nQuartzFrequency*nTicksPerCycle),Mean,StdDev*StdDev);
							MyJob->SetExecutionTimeForResource(TimeExecuteA,Cores[l]);

						}
					}
					else {

							TimeStochastic *TimeExecuteA=new TimeStochastic(us);
							TimeExecuteA->CreateNormalDistribution(static_cast<int>(LowerBound/nQuartzFrequency*nTicksPerCycle),static_cast<int>(UpperBound/nQuartzFrequency*nTicksPerCycle),Mean,StdDev*StdDev);
							MyJob->SetExecutionTimeForExecutingResource(TimeExecuteA);
					}
				}


			}
			else {			
				int nTickExecute=MyRunnable->GetWCETInTick();

				if(AmaltheaSystem::instance()->GetNoOfAmCores()>0) {
					for(int l=0;l<AmaltheaSystem::instance()->GetNoOfAmCores();l++) {
						nQuartzFrequency=AmaltheaSystem::instance()->GetAmCore(l)->GetQuartz()->GetFrequency()/1000000;		
						nTicksPerCycle=AmaltheaSystem::instance()->GetAmCore(l)->GetCoreType()->GetInstructionsPerCycle();

						if(nTicksPerCycle==0) {
							nTicksPerCycle=1;
						}

						Time *TimeExecuteA=new TimeDeterministic(ceil((double)nTickExecute/nQuartzFrequency)*nTicksPerCycle,us);  //us, since we divided the frequency by 1000000
						MyJob->SetExecutionTimeForResource(TimeExecuteA,Cores[l]);

					}
				}
				else {

						Time *TimeExecuteA=new TimeDeterministic(ceil((double)nTickExecute/nQuartzFrequency)*nTicksPerCycle,us);  //us, since we divided the frequency by 1000000
						MyJob->SetExecutionTimeForExecutingResource(TimeExecuteA);
				}
			}

			Time *DeadlineA = new TimeDeterministic(MyTask->GetDeadlineValue(),strToTimeUnit(MyTask->GetDeadlineUnit()));
			MyJob->SetDeadline(DeadlineA);

			if(MyJobPrev!=NULL) {
				MyJob->AddDependency(MyJobPrev);
			}

			MyJob->AddExecutingCore(Cores[CoreAssignment[j]]);

			if(MyJob->GetPeriod()!=NULL && MyJob->GetPeriod()->GetValue()!=0 && HyperPeriod!=NULL) {
				MySchedulerFIFO->AddPeriodicJob(MyJob,HyperPeriod);
			}
			else {
				MySchedulerFIFO->AddJobA(MyJob);
			}


			JobList->push_back(MyJob);
			MyJobPrev=MyJob;
		}
		AmaltheaSystem::instance()->AddJobToStimuliSourcesIfNecessary(MyTask,MyJobPrev);


	}

	AmaltheaSystem::instance()->AddTaskDependencesFromStimuli();

	MySchedulerFIFO->Preserve();
	MySchedulerFIFO->SortJobByTime();
	MySchedulerFIFO->DisplayJobTimeWithPriorities();
	double result = static_cast<double>(MySchedulerFIFO->GetLatestJob()->GetEndTime()->GetValue());


		list<TreeNode* >::iterator it1;
		int i=0;
		TreeNode* Tmp;
		for (it1 = AllTreeNodes.begin(); it1!= AllTreeNodes.end(); ++it1,i++) {
				Tmp=*it1;
				*it1=NULL;
				if(i!=0 && Tmp->t->GetJobA()->GetName()=="Start") {
				}
				else {
					delete Tmp->t->GetJobA();
				}
				delete Tmp->t;
				delete Tmp;
			}
	AllTreeNodes.clear();
	NamesSet.clear();

	delete MySchedulerFIFO;


	delete JobList;

	vector<IAResource*>::iterator itCores;
	for(itCores=Cores.begin(); itCores!=Cores.end() ; ++itCores) {
		delete *itCores;
	}
		end = clock();
    cout << "Time required for execution: "
    << (double)(end-start)/CLOCKS_PER_SEC
    << " seconds." << "\n\n";

	AmaltheaSystem::instance()->ClearJobs();
	return result;
}





pair<double,double> TestUnit::TestAmaltheaNoCNoLabelMapping(vector<int> &CoreAssignment,int NoCXSize, int NoCYSize, int IdleCores, vector<int> *PModeAssignment) {

	const int BytesPerMS=1000;

	SchedulerFIFO *MyScheduler=new SchedulerFIFO;
	map<Runnable*,Job*> mapRunnableJob;
	list<Job*> TransferJobToSecondPass;

	int AddedTasks=0;

	clock_t start, end;
	start = clock();

	list<Job*>* JobList=new list<Job*>;
	multimap<string,string> LabelWriters;
	multimap<string,string> LabelReaders;

	unsigned long long nQuartzFrequency=1;
	int nTicksPerCycle=0;

	if(AmaltheaSystem::instance()->GetNoOfAmCores()<1) {
		cout << "Error. No core description in the Amalthea file.";
		exit(-1);
	}


	pair<int,string> HyperPeriodPair=AmaltheaSystem::instance()->GetHyperPeriod();
	Time* HyperPeriod=NULL;
	if(HyperPeriodPair.first>0 && (HyperPeriodPair.second=="ns" || HyperPeriodPair.second=="us" || HyperPeriodPair.second=="ms" || HyperPeriodPair.second=="s")) {
		HyperPeriod=new TimeDeterministic(HyperPeriodPair.first,strToTimeUnit(HyperPeriodPair.second));
	}

	MyCores.reserve(NoCXSize*NoCYSize);
	MyLinks.reserve(4*(NoCXSize-1)*NoCYSize+2*NoCXSize*NoCYSize);


	int CoreFrequency=AmaltheaSystem::instance()->GetAmCore(0)->GetQuartz()->GetFrequency();

	int IndexOfCore=0;
	for(int y=0;y<NoCYSize;y++) {
		for(int x=0;x<NoCXSize;x++) {
			IAResource* MyCore = new IAResource("Core_"+to_string(x)+"_"+to_string(y));


			MyCore->SetResourceType(AmaltheaSystem::instance()->GetAmCore(0)->GetCoreType()->GetName());
			MyCore->SetDynamicEnergyMultiplierPerClockCycle(DynamicEnergyCore);

			MyCore->GetResourceType()->SetMaxFrequencyInHz(CoreFrequency);
			MyCore->SetStaticEnergyPerTimeUnit(StaticEnergyCore*StaticCoreFrequency,s);
			if(PModeAssignment!=NULL && PModeAssignment->size()>y*NoCXSize+x) {
				MyCore->GetResourceType()->AddVoltageFrequencyLevel(1.484,1.6);
				MyCore->GetResourceType()->AddVoltageFrequencyLevel(1.420,1.4);
				MyCore->GetResourceType()->AddVoltageFrequencyLevel(1.276,1.2);
				MyCore->GetResourceType()->AddVoltageFrequencyLevel(1.164,1.0);
				MyCore->GetResourceType()->AddVoltageFrequencyLevel(1.036,0.8);
				MyCore->GetResourceType()->AddVoltageFrequencyLevel(0.956,0.6);
				MyCore->GetResourceType()->SetSwitchingPModeEnergyPenalty(0);
				MyCore->SetCurrentPMode(PModeAssignment->at(y*NoCXSize+x));
			}
			if(IndexOfCore>=NoCYSize*NoCXSize-IdleCores) {
				MyCore->SetIsIdle(true);
			}
			IndexOfCore++;
			MyCores.push_back(MyCore);
			MyScheduler->AddCore(MyCore);
			mapNameCore[MyCore->GetName()]=MyCore;

		}
	}


	vector<IAResource*>::iterator itCores;
	vector<IAResource*>::iterator itCoresNoC;


	for(int y=0;y<NoCYSize;y++) {
		for(int x=0;x<NoCXSize-1;x++) {
			IAResource* MyLink1 = new IAResource("Router_"+to_string(x)+"_"+to_string(y)+"-Router_"+to_string(x+1)+"_"+to_string(y));
			IAResource* MyLink2 = new IAResource("Router_"+to_string(x+1)+"_"+to_string(y)+"-Router_"+to_string(x)+"_"+to_string(y));

			MyLink1->GetResourceType()->SetMaxFrequencyInHz(CoreFrequency);
			MyLink1->SetStaticEnergyPerTimeUnit(StaticEnergyLink*StaticCoreFrequency,s);
			MyLink2->GetResourceType()->SetMaxFrequencyInHz(CoreFrequency);
			MyLink2->SetStaticEnergyPerTimeUnit(StaticEnergyLink*StaticCoreFrequency,s);
			MyLink1->SetIsIdle(true);
			MyLink2->SetIsIdle(true);

			MyLink1->SetDynamicEnergyMultiplierPerClockCycle(DynamicEnergyLink);
			MyLink2->SetDynamicEnergyMultiplierPerClockCycle(DynamicEnergyLink);
			MyLinks.push_back(MyLink1);
			MyLinks.push_back(MyLink2);
			MyScheduler->AddCore(MyLink1);
			MyScheduler->AddCore(MyLink2);
			mapNameLink[MyLink1->GetName()]=MyLink1;
			mapNameLink[MyLink2->GetName()]=MyLink2;
		}
	}


	for(int x=0;x<NoCXSize;x++) {
		for(int y=0;y<NoCYSize-1;y++) {
			IAResource* MyLink1 = new IAResource("Router_"+to_string(x)+"_"+to_string(y)+"-Router_"+to_string(x)+"_"+to_string(y+1));
			IAResource* MyLink2 = new IAResource("Router_"+to_string(x)+"_"+to_string(y+1)+"-Router_"+to_string(x)+"_"+to_string(y));
			MyLink1->SetDynamicEnergyMultiplierPerClockCycle(DynamicEnergyLink);
			MyLink2->SetDynamicEnergyMultiplierPerClockCycle(DynamicEnergyLink);

			MyLink1->GetResourceType()->SetMaxFrequencyInHz(CoreFrequency);
			MyLink1->SetStaticEnergyPerTimeUnit(StaticEnergyLink*StaticCoreFrequency,s);
			MyLink2->GetResourceType()->SetMaxFrequencyInHz(CoreFrequency);
			MyLink2->SetStaticEnergyPerTimeUnit(StaticEnergyLink*StaticCoreFrequency,s);
			MyLink1->SetIsIdle(true);
			MyLink2->SetIsIdle(true);

			MyLinks.push_back(MyLink1);
			MyLinks.push_back(MyLink2);
			MyScheduler->AddCore(MyLink1);
			MyScheduler->AddCore(MyLink2);
			mapNameLink[MyLink1->GetName()]=MyLink1;
			mapNameLink[MyLink2->GetName()]=MyLink2;
		}
	}


		for(int y=0;y<NoCYSize;y++) {
		for(int x=0;x<NoCXSize;x++) {
			IAResource* MyLink1 = new IAResource("Core_"+to_string(x)+"_"+to_string(y)+"-Router_"+to_string(x)+"_"+to_string(y));
			IAResource* MyLink2 = new IAResource("Router_"+to_string(x)+"_"+to_string(y)+"-Core_"+to_string(x)+"_"+to_string(y));
			MyLink1->SetDynamicEnergyMultiplierPerClockCycle(DynamicEnergyLink);
			MyLink2->SetDynamicEnergyMultiplierPerClockCycle(DynamicEnergyLink);

			MyLink1->GetResourceType()->SetMaxFrequencyInHz(CoreFrequency);
			MyLink1->SetStaticEnergyPerTimeUnit(StaticEnergyLink*StaticCoreFrequency,s);
			MyLink2->GetResourceType()->SetMaxFrequencyInHz(CoreFrequency);
			MyLink2->SetStaticEnergyPerTimeUnit(StaticEnergyLink*StaticCoreFrequency,s);
			MyLink1->SetIsIdle(true);
			MyLink2->SetIsIdle(true);


			MyLinks.push_back(MyLink1);
			MyLinks.push_back(MyLink2);
			MyScheduler->AddCore(MyLink1);
			MyScheduler->AddCore(MyLink2);
			mapNameLink[MyLink1->GetName()]=MyLink1;
			mapNameLink[MyLink2->GetName()]=MyLink2;
		}
	}

	int nNoOfTasks=AmaltheaSystem::instance()->GetNoOfTasks();
	for(int i=0;i<nNoOfTasks;i++) {
		Task* MyTask = AmaltheaSystem::instance()->GetTask(i);
		
		int nNoOfRunnables=MyTask->GetNoOfRunnables();
		Job* MyJobPrev=NULL;
		for(int j=0;j<nNoOfRunnables;j++) {
			Runnable* MyRunnable = MyTask->GetRunnable(j);
			
			
			
			Job *MyJob=new Job(DoUnique(MyRunnable->GetName()));
			mapRunnableJob[MyRunnable]=MyJob;

			if(j==0) {
				//for the 1st runnable in the task only
				AmaltheaSystem::instance()->AddJobToStimuliDestinationsIfNecessary(MyTask,MyJob);
			}

			Time *TimeReleaseA;
			if(MyTask->GetStimulus()!=NULL) {
				TimeReleaseA = new TimeDeterministic(MyTask->GetStimulus()->GetOffset().first,strToTimeUnit(MyTask->GetStimulus()->GetOffset().second));
			}
			else  {
				TimeReleaseA = new TimeDeterministic(0);
			}

			MyJob->SetReleaseTime(TimeReleaseA);

			if(MyTask->GetStimulus()!=NULL) {
				Time *TimePeriodA = new TimeDeterministic(MyTask->GetStimulus()->GetRecurrence().first,strToTimeUnit(MyTask->GetStimulus()->GetRecurrence().second));
				MyJob->SetPeriod(TimePeriodA);
			}

			int nTickExecute=MyRunnable->GetWCETInTick();

			for(int l=0;l<MyCores.size();l++) {
				nQuartzFrequency=AmaltheaSystem::instance()->GetAmCore(0)->GetQuartz()->GetFrequency()/1000000;		
				nTicksPerCycle=AmaltheaSystem::instance()->GetAmCore(0)->GetCoreType()->GetInstructionsPerCycle();

				if(nTicksPerCycle==0) {
					nTicksPerCycle=1;
				}
				Time *TimeExecuteA=new TimeDeterministic(ceil((double)nTickExecute/nQuartzFrequency)*nTicksPerCycle*ExecutionTimeMultiplier,us);  //us, since we divided the frequency by 1000000
				MyJob->SetExecutionTimeForResource(TimeExecuteA,MyCores[l]);

			}

			int IndexOfRunnable=AmaltheaSystem::instance()->GetIndexOfRunnable(MyRunnable);
			MyJob->AddExecutingCore(MyCores[CoreAssignment[IndexOfRunnable]%(NoCXSize*NoCYSize-IdleCores)]);


			Time *DeadlineA = new TimeDeterministic(MyTask->GetDeadlineValue(),strToTimeUnit(MyTask->GetDeadlineUnit()));
			MyJob->SetDeadline(DeadlineA);


			for(int k=0;k<MyRunnable->GetNoOfInstructions();k++) {
				if(MyRunnable->GetNameOfInstruction(k)=="sw:LabelAccess") {

					string LabelName=MyRunnable->GetLabelNameOfLabelAccessInstruction(k);

					bool IsWrite=MyRunnable->CheckIfWriteAccessInstruction(k);
					if(IsWrite) {
						LabelWriters.insert(pair<string,string>(LabelName,MyRunnable->GetName()));
					}
					else {
						LabelReaders.insert(pair<string,string>(LabelName,MyRunnable->GetName()));
					}
				}
			}

			

			if(MyJob->GetPeriod()!=NULL && MyJob->GetPeriod()->GetValue()!=0 && HyperPeriod!=NULL) {
				MyScheduler->AddPeriodicJob(MyJob,HyperPeriod);
			}
			else {
				MyScheduler->AddJobA(MyJob);
			}

			JobList->push_back(MyJob);
			AddedTasks++;

			if(MyJobPrev!=NULL && MyJob->GetTheFirstExecutingCore()!=MyJobPrev->GetTheFirstExecutingCore()) {
				//synchronization between subsequent runnables situated in different cores


				Job* MySynchronizationJob;
				list<IAResource*>* Path;

				MySynchronizationJob=new Job(DoUnique("Synch_"+MyJobPrev->GetName()+"_"+MyJob->GetName()));
				MySynchronizationJob->AddDependency(MyJobPrev);
				MyJobPrev->SynchrNoC.push_back(MySynchronizationJob);
				MyJob->AddDependency(MySynchronizationJob);
				Path=GetPathBetween(MyJobPrev->GetTheFirstExecutingCore(),MyJob->GetTheFirstExecutingCore());



				Time *MyReleaseTime=new TimeDeterministic(0);
				MySynchronizationJob->SetReleaseTime(MyReleaseTime);
				Time *TimeDeadline=MyJob->GetDeadline()->Clone();
				MySynchronizationJob->SetDeadline(TimeDeadline);
				Time *TimePeriod=MyJobPrev->GetPeriod()->Clone();
				MySynchronizationJob->SetPeriod(TimePeriod);
				MySynchronizationJob->SetPriority(MyJobPrev->GetPriority());

				MySynchronizationJob->SetExecutingCores(Path);

				for_each(Path->begin(),Path->end(), [] (IAResource* Resource) {
					Resource->SetIsIdle(false);
			    }); 
				

				delete Path;


				Time *MyComputationTime=new TimeDeterministic(static_cast<int>(ceil(1.0/BytesPerMS))*250,us);
				MySynchronizationJob->SetExecutionTimeForExecutingResource(MyComputationTime);

				
				if(MySynchronizationJob->GetPeriod()!=NULL && MySynchronizationJob->GetPeriod()->GetValue()!=0 && HyperPeriod!=NULL) {
					MyScheduler->AddPeriodicJob(MySynchronizationJob,HyperPeriod);
				}
				else {
					MyScheduler->AddJobA(MySynchronizationJob);
				}



				JobList->push_back(MySynchronizationJob);

				AddedTasks++;


			}



			MyJobPrev=MyJob;
		}


	AmaltheaSystem::instance()->AddJobToStimuliSourcesIfNecessary(MyTask,MyJobPrev);
	}


	//adding communication to labels

	for(multimap<string, string>::iterator it = LabelWriters.begin();  it != LabelWriters.end(); ++it) {
		string LabelName=(*it).first;
		string WriterName=(*it).second;

		pair<multimap<string, string>::iterator, multimap<string, string>::iterator> Readers;
		Readers = LabelReaders.equal_range(LabelName);

		for (multimap<string, string>::iterator it2 = Readers.first;  it2 != Readers.second; ++it2) {
			string ReaderName=(*it2).second;

			Job* MyTransferJob;
			list<IAResource*>* Path;
			Label* MyLabel=AmaltheaSystem::instance()->GetLabelByName(LabelName);

			MyTransferJob=new Job(DoUnique("Comm_"+WriterName+"_To:"+ReaderName));
			Runnable *RunnableWriter=AmaltheaSystem::instance()->GetRunnableByName(WriterName);
			Job *JobWriter=mapRunnableJob.at(RunnableWriter);
			MyTransferJob->AddDependency(JobWriter);
			JobWriter->SynchrNoC.push_back(MyTransferJob);

			Runnable *RunnableReader=AmaltheaSystem::instance()->GetRunnableByName(ReaderName);
			Job *JobReader=mapRunnableJob.at(RunnableReader);

//			JobReader->AddDependency(MyTransferJob);

			Path=GetPathBetween(JobWriter->GetTheFirstExecutingCore(),JobReader->GetTheFirstExecutingCore());




			Time *MyReleaseTime=new TimeDeterministic(0);
			MyTransferJob->SetReleaseTime(MyReleaseTime);
			Time *TimeDeadline=JobWriter->GetDeadline()->Clone();
			MyTransferJob->SetDeadline(TimeDeadline);
			Time *TimePeriod=JobWriter->GetPeriod()->Clone();
			MyTransferJob->SetPeriod(TimePeriod);
			MyTransferJob->SetPriority(JobWriter->GetPriority());


			if(Path->size()==0) { //src and dest are in the same core
				MyTransferJob->SetExecutingCores(JobWriter->GetExecutingCores());
			}
			else {
				MyTransferJob->SetExecutingCores(Path);
			}

			for_each(Path->begin(),Path->end(), [] (IAResource* Resource) {
					Resource->SetIsIdle(false);
			    }); 

			delete Path;


			Time *MyComputationTime=new TimeDeterministic(static_cast<int>(ceil(static_cast<double>(MyLabel->GetSize())/BytesPerMS)*100),us);
//					Time *MyComputationTime=new TimeDeterministic(static_cast<int>(ceil(static_cast<double>(MyLabel->GetSize())/BytesPerMS)),ms);
			MyTransferJob->SetExecutionTimeForExecutingResource(MyComputationTime);

			if(MyTransferJob->GetPeriod()!=NULL && MyTransferJob->GetPeriod()->GetValue()!=0 && HyperPeriod!=NULL) {
				int NoOfJobs=MyScheduler->GetAllJobsList().size();
				MyScheduler->AddPeriodicJob(MyTransferJob,HyperPeriod,false);
				int NoOfJobs2=MyScheduler->GetAllJobsList().size();
				if(NoOfJobs2==NoOfJobs) {
					TransferJobToSecondPass.push_back(MyTransferJob);
				}
			}
			else {
				MyScheduler->AddJobA(MyTransferJob);
			}
			JobList->push_back(MyTransferJob);

			AddedTasks++;
		}
	}
 




	list<Job*>::iterator it;
	for (it=TransferJobToSecondPass.begin();it!=TransferJobToSecondPass.end();++it) {
		MyScheduler->AddPeriodicJob(*it,HyperPeriod);
	}

	AmaltheaSystem::instance()->AddTaskDependencesFromStimuli();

	
	cout << "NoOfTaks: " << AddedTasks << endl;

	MyScheduler->Preserve();
	double result = static_cast<int>(MyScheduler->GetLatestFirstJobOfPeriodicTask()->GetEndTime()->GetValue()); //for periodic task
	cout << "Makespan: " << result << endl;

	MyScheduler->ComputeDeadlineCounters();
	double MyEnergy=MyScheduler->GetEnergy();
	result=	MyScheduler->GetAfterDeadlineCounter();
	cout << "BD: " << MyScheduler->GetBeforeDeadlineCounter() << ", AD: " << MyScheduler->GetAfterDeadlineCounter() << endl;


		list<TreeNode* >::iterator it1;
		int i=0;
		TreeNode* Tmp;
		for (it1 = AllTreeNodes.begin(); it1!= AllTreeNodes.end(); ++it1,i++) {
				Tmp=*it1;
				*it1=NULL;
				if(i!=0 && Tmp->t->GetJobA()->GetName()=="Start") {
				}
				else {
					delete Tmp->t->GetJobA();
				}
				delete Tmp->t;
				delete Tmp;
			}
	AllTreeNodes.clear();
	NamesSet.clear();

	delete MyScheduler;


	delete JobList;

	vector<IAResource*>::iterator itCores2;
	for(itCores2=MyCores.begin(); itCores2!=MyCores.end() ; ++itCores2) {
		delete *itCores2;
	}

	int nIdleLinks=0;
	for(itCores2=MyLinks.begin(); itCores2!=MyLinks.end() ; ++itCores2) {
		if((*itCores2)->GetIsIdle()) {
			nIdleLinks++;
		}
		delete *itCores2;
	}



	mapCoreTime.clear();
	mapJob_TreeNode.clear();
	MyCores.clear();
	MyLinks.clear();
	mapNameCore.clear();
	mapNameLink.clear();

	end = clock();
	cout << "Idle links: " << nIdleLinks << endl;
	cout << "PModes: ";
	for_each(PModeAssignment->begin(),PModeAssignment->end(), [] (int PMode) {
		cout << PMode << " ";
	}); 
	cout << endl;

	AmaltheaSystem::instance()->ClearJobs();
	delete HyperPeriod;

	return pair<double,double>(-1*result,-1*MyEnergy);
}


pair<double,double> TestUnit::TestAmaltheaTriCore(vector<int> &CoreAssignment,vector<int> &LabelAssignment, int NoOfCores, int NoOfMemories, vector<int> *PModeAssignment) {





	const int BytesPerMS=100000000;
	TimeDeterministic ClockPeriod(1,ns);	


map<string, pair<int,int> > MappingMap;


	SchedulerFIFO *MyScheduler=new SchedulerFIFO;
	map<Runnable*,Job*> mapRunnableJob;
	list<Job*> TransferJobToSecondPass;

	int AddedTasks=0;

	clock_t start, end;
	start = clock();

	list<Job*>* JobList=new list<Job*>;


	unsigned long long nQuartzFrequency=1;
	int nTicksPerCycle=0;

	if(AmaltheaSystem::instance()->GetNoOfAmCores()<1) {
		std::cout << "Error. No core description in the Amalthea file.";
		exit(-1);
	}


	pair<int,string> HyperPeriodPair=AmaltheaSystem::instance()->GetHyperPeriod();
	Time* HyperPeriod=NULL;
	if(HyperPeriodPair.first>0 && (HyperPeriodPair.second=="ns" || HyperPeriodPair.second=="us" || HyperPeriodPair.second=="ms" || HyperPeriodPair.second=="s")) {
		HyperPeriod=new TimeDeterministic(HyperPeriodPair.first,strToTimeUnit(HyperPeriodPair.second));
	}

	MyCores.reserve(NoOfCores+NoOfMemories);
	MyLinks.reserve(NoOfCores*NoOfMemories);

	long CoreFrequency=AmaltheaSystem::instance()->GetAmCore(0)->GetQuartz()->GetFrequency();
	CoreFrequency=10000000; 


	for(int x=0;x<NoOfCores;x++) {
		IAResource* MyCore = new IAResource("Core_"+to_string(x));
		MyCore->SetResourceType(AmaltheaSystem::instance()->GetAmCore(0)->GetCoreType()->GetName());
		MyCore->SetDynamicEnergyMultiplierPerClockCycle(DynamicEnergyCore);
		MyCore->GetResourceType()->SetMaxFrequencyInHz(CoreFrequency);
		MyCore->SetStaticEnergyPerTimeUnit(StaticEnergyCore*StaticCoreFrequency,s);
		MyCore->SetIsIdle(false);

		if(PModeAssignment!=NULL && PModeAssignment->size()>x) {
			MyCore->GetResourceType()->AddVoltageFrequencyLevel(1.484,1.6);
			MyCore->GetResourceType()->AddVoltageFrequencyLevel(1.420,1.4);
			MyCore->GetResourceType()->AddVoltageFrequencyLevel(1.276,1.2);
			MyCore->GetResourceType()->AddVoltageFrequencyLevel(1.164,1.0);
			MyCore->GetResourceType()->AddVoltageFrequencyLevel(1.036,0.8);
			MyCore->GetResourceType()->AddVoltageFrequencyLevel(0.956,0.6);
			MyCore->GetResourceType()->SetSwitchingPModeEnergyPenalty(0);
			MyCore->SetCurrentPMode(PModeAssignment->at(x));
		}
		MyCores.push_back(MyCore);
		MyScheduler->AddCore(MyCore);
		mapNameCore[MyCore->GetName()]=MyCore;
	}


	for(int x=0;x<NoOfMemories;x++) {
		IAResource* MyMemory = new IAResource("Memory_"+to_string(x));
		MyMemory->SetResourceType(AmaltheaSystem::instance()->GetAmCore(0)->GetCoreType()->GetName());
		MyMemory->SetDynamicEnergyMultiplierPerClockCycle(DynamicEnergyCore);
		MyMemory->GetResourceType()->SetMaxFrequencyInHz(CoreFrequency);
		MyMemory->SetStaticEnergyPerTimeUnit(StaticEnergyCore*StaticCoreFrequency,s);
		MyMemory->SetIsIdle(false);

		if(PModeAssignment!=NULL && PModeAssignment->size()>x) {
			MyMemory->GetResourceType()->AddVoltageFrequencyLevel(1.484,1.6);
			MyMemory->GetResourceType()->AddVoltageFrequencyLevel(1.420,1.4);
			MyMemory->GetResourceType()->AddVoltageFrequencyLevel(1.276,1.2);
			MyMemory->GetResourceType()->AddVoltageFrequencyLevel(1.164,1.0);
			MyMemory->GetResourceType()->AddVoltageFrequencyLevel(1.036,0.8);
			MyMemory->GetResourceType()->AddVoltageFrequencyLevel(0.956,0.6);
			MyMemory->GetResourceType()->SetSwitchingPModeEnergyPenalty(0);
			MyMemory->SetCurrentPMode(PModeAssignment->at(x));
		}
		MyCores.push_back(MyMemory);
		MyScheduler->AddCore(MyMemory);
		mapNameCore[MyMemory->GetName()]=MyMemory;
	}



	vector<IAResource*>::iterator itCores;
	vector<IAResource*>::iterator itCoresNoC;


		


	for(int y=0;y<NoOfMemories;y++) {
		for(int x=0;x<NoOfCores-1;x++) {
			IAResource* MyLink1 = new IAResource("Core_"+to_string(x)+"_"+to_string(y)+"-Memory_"+to_string(x+1)+"_"+to_string(y));
			IAResource* MyLink2 = new IAResource("Memory_"+to_string(x+1)+"_"+to_string(y)+"-Core_"+to_string(x)+"_"+to_string(y));


			MyLink1->GetResourceType()->SetMaxFrequencyInHz(CoreFrequency);
			MyLink1->SetStaticEnergyPerTimeUnit(StaticEnergyLink*StaticCoreFrequency,s);
			MyLink2->GetResourceType()->SetMaxFrequencyInHz(CoreFrequency);
			MyLink2->SetStaticEnergyPerTimeUnit(StaticEnergyLink*StaticCoreFrequency,s);
			MyLink1->SetIsIdle(false);
			MyLink2->SetIsIdle(false);

			MyLink1->SetDynamicEnergyMultiplierPerClockCycle(DynamicEnergyLink);
			MyLink2->SetDynamicEnergyMultiplierPerClockCycle(DynamicEnergyLink);
			MyLink1->SetStaticEnergyPerTimeUnit(0,s);
			MyLink2->SetStaticEnergyPerTimeUnit(0,s);
			MyLink1->SetDynamicEnergyMultiplierPerClockCycle(0);
			MyLink2->SetDynamicEnergyMultiplierPerClockCycle(0);

			MyLinks.push_back(MyLink1);
			MyLinks.push_back(MyLink2);
			MyScheduler->AddCore(MyLink1);
			MyScheduler->AddCore(MyLink2);
			mapNameLink[MyLink1->GetName()]=MyLink1;
			mapNameLink[MyLink2->GetName()]=MyLink2;
		}
	}



	int nNoOfTasks=AmaltheaSystem::instance()->GetNoOfTasks();
	for(int i=0;i<nNoOfTasks;i++) {
		Task* MyTask = AmaltheaSystem::instance()->GetTask(i);
		
		int nNoOfRunnables=MyTask->GetNoOfRunnables();
		Job* MyJobPrev=NULL;
		for(int j=0;j<nNoOfRunnables;j++) {
			Runnable* MyRunnable = MyTask->GetRunnable(j);
			
			
			
			Job *MyJob=new Job(DoUnique(MyRunnable->GetName()));
			mapRunnableJob[MyRunnable]=MyJob;

			if(j==0) {
				//for the 1st runnable in the task only
				AmaltheaSystem::instance()->AddJobToStimuliDestinationsIfNecessary(MyTask,MyJob);
			}

			Time *TimeReleaseA;
			if(MyTask->GetStimulus()!=NULL) {
				TimeReleaseA = new TimeDeterministic(MyTask->GetStimulus()->GetOffset().first,strToTimeUnit(MyTask->GetStimulus()->GetOffset().second));
			}
			else  {
				TimeReleaseA = new TimeDeterministic(0);
			}

			MyJob->SetReleaseTime(TimeReleaseA);

			if(MyTask->GetStimulus()!=NULL) {
				Time *TimePeriodA = new TimeDeterministic(MyTask->GetStimulus()->GetRecurrence().first,strToTimeUnit(MyTask->GetStimulus()->GetRecurrence().second));
				MyJob->SetPeriod(TimePeriodA);
			}

			int nTickExecute=MyRunnable->GetWCETInTick();

			for(int l=0;l<MyCores.size();l++) {
				nQuartzFrequency=CoreFrequency/1000000;

				nTicksPerCycle=1;
				Time *TimeExecuteA=new TimeDeterministic(ceil((double)nTickExecute/nQuartzFrequency)*nTicksPerCycle*ExecutionTimeMultiplier,us);  //us, since we divided the frequency by 1000000
				MyJob->SetExecutionTimeForResource(TimeExecuteA,MyCores[l]);

			}
		
			int IndexOfRunnable=AmaltheaSystem::instance()->GetIndexOfRunnable(MyRunnable);
			MyJob->AddExecutingCore(MyCores[CoreAssignment[IndexOfRunnable]%(NoOfCores+NoOfMemories)]);

			Time *DeadlineA = new TimeDeterministic(MyTask->GetDeadlineValue(),strToTimeUnit(MyTask->GetDeadlineUnit()));
			MyJob->SetDeadline(DeadlineA);

			if(MyJobPrev!=NULL) {
				MyJob->AddDependency(MyJobPrev);
			}



		
			for(int k=0;k<MyRunnable->GetNoOfInstructions();k++) {
				if(MyRunnable->GetNameOfInstruction(k)=="sw:LabelAccess") {
					Job* MyTransferJob;
					list<IAResource*>* Path;
					string LabelName=MyRunnable->GetLabelNameOfLabelAccessInstruction(k);
					Label* MyLabel=AmaltheaSystem::instance()->GetLabelByName(LabelName);

					int IndexOfLabel=AmaltheaSystem::instance()->GetIndexOfLabel(MyLabel);
					IAResource *LabelCore=MyCores[LabelAssignment[IndexOfLabel]%(NoOfCores+NoOfMemories)];

					bool IsWrite=MyRunnable->CheckIfWriteAccessInstruction(k);
					if(IsWrite) {
						MyTransferJob=new Job(DoUnique("Comm_"+MyRunnable->GetName()+"_L:"+LabelName));
						MyTransferJob->AddDependency(MyJob);
						MyJob->SynchrNoC.push_back(MyTransferJob);

						Path=new list<IAResource*>;
						Path->push_back(MyJob->GetTheFirstExecutingCore());
						Path->push_back(LabelCore);

					}
					else {
						MyTransferJob=new Job(DoUnique("Comm_L:"+LabelName+"_"+MyRunnable->GetName()));
						MyJob->AddDependency(MyTransferJob);

						Path=new list<IAResource*>;
						Path->push_back(LabelCore);
						Path->push_back(MyJob->GetTheFirstExecutingCore());
					}

					Time *MyReleaseTime=new TimeDeterministic(0);
					MyTransferJob->SetReleaseTime(MyReleaseTime);
					Time *TimeDeadline=MyJob->GetDeadline()->Clone();
					MyTransferJob->SetDeadline(TimeDeadline);
					Time *TimePeriod=MyJob->GetPeriod()->Clone();
					MyTransferJob->SetPeriod(TimePeriod);
					MyTransferJob->SetPriority(MyJob->GetPriority());


					if(Path->size()==0) { //src and dest are in the same core
						MyTransferJob->SetExecutingCores(MyJob->GetExecutingCores());
					}
					else {
						MyTransferJob->SetExecutingCores(Path);
					}
					int TransferTimeinClockCycles;
					if(Path->empty()) {
						TransferTimeinClockCycles=ZeroHopDelayinClockCycles;
					}
					else {
						TransferTimeinClockCycles=OneHopDelayinClockCycles*Path->size()+OneRouterDelayinClockCycles*(Path->size()-1);
					}

					delete Path;


					Time *MyComputationTime=new TimeDeterministic(static_cast<int>(ceil(static_cast<double>(MyLabel->GetSize())/FlitSize)*TransferTimeinClockCycles*ClockPeriod.GetValue()),ClockPeriod.GetUnit());
					MyTransferJob->SetExecutionTimeForExecutingResource(MyComputationTime);

					if(MyTransferJob->GetPeriod()!=NULL && MyTransferJob->GetPeriod()->GetValue()!=0 && HyperPeriod!=NULL) {
						int NoOfJobs=MyScheduler->GetAllJobsList().size();
						MyScheduler->AddPeriodicJob(MyTransferJob,HyperPeriod,false);
						int NoOfJobs2=MyScheduler->GetAllJobsList().size();
						if(NoOfJobs2==NoOfJobs) {
							TransferJobToSecondPass.push_back(MyTransferJob);
						}
					}
					else {
						MyScheduler->AddJobA(MyTransferJob);
					}
					JobList->push_back(MyTransferJob);

					AddedTasks++;


				}
			}


			if(MyJob->GetPeriod()!=NULL && MyJob->GetPeriod()->GetValue()!=0 && HyperPeriod!=NULL) {
				MyScheduler->AddPeriodicJob(MyJob,HyperPeriod);
			}
			else {
				MyScheduler->AddJobA(MyJob);
			}

			JobList->push_back(MyJob);
			AddedTasks++;

			if(MyJobPrev!=NULL && MyJob->GetTheFirstExecutingCore()!=MyJobPrev->GetTheFirstExecutingCore()) {
				//synchronization between subsequent runnables situated in different cores


				Job* MySynchronizationJob;
				list<IAResource*>* Path;

				MySynchronizationJob=new Job(DoUnique("Synch_"+MyJobPrev->GetName()+"_"+MyJob->GetName()));
				MySynchronizationJob->AddDependency(MyJobPrev);
				MyJobPrev->SynchrNoC.push_back(MySynchronizationJob);
				MyJob->AddDependency(MySynchronizationJob);
				
				Path=new list<IAResource*>;
				Path->push_back(MyJobPrev->GetTheFirstExecutingCore());
				Path->push_back(MyJob->GetTheFirstExecutingCore());



				Time *MyReleaseTime=new TimeDeterministic(0);
				MySynchronizationJob->SetReleaseTime(MyReleaseTime);
				Time *TimeDeadline=MyJob->GetDeadline()->Clone();
				MySynchronizationJob->SetDeadline(TimeDeadline);
				Time *TimePeriod=MyJobPrev->GetPeriod()->Clone();
				MySynchronizationJob->SetPeriod(TimePeriod);
				MySynchronizationJob->SetPriority(MyJobPrev->GetPriority());

				MySynchronizationJob->SetExecutingCores(Path);

				int TransferTimeinClockCycles;
				if(Path->empty()) {
					TransferTimeinClockCycles=ZeroHopDelayinClockCycles;
				}
				else {
					TransferTimeinClockCycles=OneHopDelayinClockCycles*Path->size()+OneRouterDelayinClockCycles*(Path->size()-1);
				}
				delete Path;

				Time *MyComputationTime=new TimeDeterministic(static_cast<int>(TransferTimeinClockCycles*ClockPeriod.GetValue()),ClockPeriod.GetUnit());
				MySynchronizationJob->SetExecutionTimeForExecutingResource(MyComputationTime);

				
				if(MySynchronizationJob->GetPeriod()!=NULL && MySynchronizationJob->GetPeriod()->GetValue()!=0 && HyperPeriod!=NULL) {
					MyScheduler->AddPeriodicJob(MySynchronizationJob,HyperPeriod);
				}
				else {
					MyScheduler->AddJobA(MySynchronizationJob);
				}



				JobList->push_back(MySynchronizationJob);

				AddedTasks++;

			}

			MyJobPrev=MyJob;
		}


	AmaltheaSystem::instance()->AddJobToStimuliSourcesIfNecessary(MyTask,MyJobPrev);
	}

	list<Job*>::iterator it;
	for (it=TransferJobToSecondPass.begin();it!=TransferJobToSecondPass.end();++it) {
		MyScheduler->AddPeriodicJob(*it,HyperPeriod);
	}

	AmaltheaSystem::instance()->AddTaskDependencesFromStimuli();

	
	std::cout << "NoOfTaks: " << AddedTasks << endl;

	MyScheduler->Preserve();

	double result = static_cast<int>(MyScheduler->GetLatestFirstJobOfPeriodicTask()->GetEndTime()->GetValue()); //beware! GetLatest... can return NULL
	
	cout << "Makespan: " << result << MyScheduler->GetLatestJob()->GetEndTime()->GetUnitAsString()<< endl;

	MyScheduler->ComputeDeadlineCounters();
	double MyEnergy=MyScheduler->GetEnergy();
	result+=	static_cast<double>(MyScheduler->GetAfterDeadlineCounter())*5000000.0;
	cout << "BD: " << MyScheduler->GetBeforeDeadlineCounter() << ", AD: " << MyScheduler->GetAfterDeadlineCounter() << endl;


		list<TreeNode* >::iterator it1;
		int i=0;
		TreeNode* Tmp;
		for (it1 = AllTreeNodes.begin(); it1!= AllTreeNodes.end(); ++it1,i++) {
				Tmp=*it1;
				*it1=NULL;
				if(i!=0 && Tmp->t->GetJobA()->GetName()=="Start") {
				}
				else {
					delete Tmp->t->GetJobA();
				}
				delete Tmp->t;
				delete Tmp;
			}
	AllTreeNodes.clear();
	NamesSet.clear();

	delete MyScheduler;


	delete JobList;

	vector<IAResource*>::iterator itCores2;
	for(itCores2=MyCores.begin(); itCores2!=MyCores.end() ; ++itCores2) {
		delete *itCores2;
	}

	for(itCores2=MyLinks.begin(); itCores2!=MyLinks.end() ; ++itCores2) {
		delete *itCores2;
	}



	mapCoreTime.clear();
	mapJob_TreeNode.clear();
	MyCores.clear();
	MyLinks.clear();
	mapNameCore.clear();
	mapNameLink.clear();

	end = clock();
	AmaltheaSystem::instance()->ClearJobs();
	delete HyperPeriod;

	return pair<double,double>(result,MyEnergy);
}



pair<double,double> TestUnit::TestAmaltheaNoC(vector<int> &CoreAssignment,vector<int> &LabelAssignment,int NoCXSize, int NoCYSize, int IdleCores, vector<int> *PModeAssignment) {



	const int BytesPerMS=100000000;
	TimeDeterministic ClockPeriod(1,ns);	


map<string, pair<int,int> > MappingMap;

	map<string, pair<int,int> >::iterator itMap;
	for(itMap=MappingMap.begin();itMap!=MappingMap.end();++itMap) {
		if(rand()%5==0) {
		 (*itMap).second=pair<int,int>(rand()%4,rand()%4);
		}
	}


	SchedulerFIFO *MyScheduler=new SchedulerFIFO;
	map<Runnable*,Job*> mapRunnableJob;
	list<Job*> TransferJobToSecondPass;

	int AddedTasks=0;

	clock_t start, end;
	start = clock();

	list<Job*>* JobList=new list<Job*>;


	unsigned long long nQuartzFrequency=1;
	int nTicksPerCycle=0;

	if(AmaltheaSystem::instance()->GetNoOfAmCores()<1) {
		std::cout << "Error. No core description in the Amalthea file.";
		exit(-1);
	}


	pair<int,string> HyperPeriodPair=AmaltheaSystem::instance()->GetHyperPeriod();
	Time* HyperPeriod=NULL;
	if(HyperPeriodPair.first>0 && (HyperPeriodPair.second=="ns" || HyperPeriodPair.second=="us" || HyperPeriodPair.second=="ms" || HyperPeriodPair.second=="s")) {
		HyperPeriod=new TimeDeterministic(HyperPeriodPair.first,strToTimeUnit(HyperPeriodPair.second));
	}

	MyCores.reserve(NoCXSize*NoCYSize);
	MyLinks.reserve(4*(NoCXSize-1)*NoCYSize+2*NoCXSize*NoCYSize);

	long CoreFrequency=AmaltheaSystem::instance()->GetAmCore(0)->GetQuartz()->GetFrequency();
	CoreFrequency=1000000000; //1GHz for compatibility with Khalid's simulator

	for(int y=0;y<NoCYSize;y++) {
		for(int x=0;x<NoCXSize;x++) {





			IAResource* MyCore = new IAResource("Core_"+to_string(x)+"_"+to_string(y));



			MyCore->SetResourceType(AmaltheaSystem::instance()->GetAmCore(0)->GetCoreType()->GetName());
			MyCore->SetDynamicEnergyMultiplierPerClockCycle(DynamicEnergyCore);

			MyCore->GetResourceType()->SetMaxFrequencyInHz(CoreFrequency);
			MyCore->SetStaticEnergyPerTimeUnit(StaticEnergyCore*StaticCoreFrequency,s);
			MyCore->SetIsIdle(false);

			if(PModeAssignment!=NULL && PModeAssignment->size()>y*NoCXSize+x) {
				MyCore->GetResourceType()->AddVoltageFrequencyLevel(1.484,1.6);
				MyCore->GetResourceType()->AddVoltageFrequencyLevel(1.420,1.4);
				MyCore->GetResourceType()->AddVoltageFrequencyLevel(1.276,1.2);
				MyCore->GetResourceType()->AddVoltageFrequencyLevel(1.164,1.0);
				MyCore->GetResourceType()->AddVoltageFrequencyLevel(1.036,0.8);
				MyCore->GetResourceType()->AddVoltageFrequencyLevel(0.956,0.6);
				MyCore->GetResourceType()->SetSwitchingPModeEnergyPenalty(0);
				MyCore->SetCurrentPMode(PModeAssignment->at(y*NoCXSize+x));
			}
			MyCores.push_back(MyCore);
			MyScheduler->AddCore(MyCore);
			mapNameCore[MyCore->GetName()]=MyCore;
		}
	}


	vector<IAResource*>::iterator itCores;
	vector<IAResource*>::iterator itCoresNoC;


		


	for(int y=0;y<NoCYSize;y++) {
		for(int x=0;x<NoCXSize-1;x++) {
			IAResource* MyLink1 = new IAResource("Router_"+to_string(x)+"_"+to_string(y)+"-Router_"+to_string(x+1)+"_"+to_string(y));
			IAResource* MyLink2 = new IAResource("Router_"+to_string(x+1)+"_"+to_string(y)+"-Router_"+to_string(x)+"_"+to_string(y));
//			MyLink1->SetDynamicEnergyMultiplierPerClockCycle(0.1);
//			MyLink2->SetDynamicEnergyMultiplierPerClockCycle(0.1);


			MyLink1->GetResourceType()->SetMaxFrequencyInHz(CoreFrequency);
			MyLink1->SetStaticEnergyPerTimeUnit(StaticEnergyLink*StaticCoreFrequency,s);
			MyLink2->GetResourceType()->SetMaxFrequencyInHz(CoreFrequency);
			MyLink2->SetStaticEnergyPerTimeUnit(StaticEnergyLink*StaticCoreFrequency,s);
			MyLink1->SetIsIdle(false);
			MyLink2->SetIsIdle(false);

			MyLink1->SetDynamicEnergyMultiplierPerClockCycle(DynamicEnergyLink);
			MyLink2->SetDynamicEnergyMultiplierPerClockCycle(DynamicEnergyLink);
			MyLink1->SetStaticEnergyPerTimeUnit(0,s);
			MyLink2->SetStaticEnergyPerTimeUnit(0,s);
			MyLink1->SetDynamicEnergyMultiplierPerClockCycle(0);
			MyLink2->SetDynamicEnergyMultiplierPerClockCycle(0);

			MyLinks.push_back(MyLink1);
			MyLinks.push_back(MyLink2);
			MyScheduler->AddCore(MyLink1);
			MyScheduler->AddCore(MyLink2);
			mapNameLink[MyLink1->GetName()]=MyLink1;
			mapNameLink[MyLink2->GetName()]=MyLink2;
		}
	}


	for(int x=0;x<NoCXSize;x++) {
		for(int y=0;y<NoCYSize-1;y++) {
			IAResource* MyLink1 = new IAResource("Router_"+to_string(x)+"_"+to_string(y)+"-Router_"+to_string(x)+"_"+to_string(y+1));
			IAResource* MyLink2 = new IAResource("Router_"+to_string(x)+"_"+to_string(y+1)+"-Router_"+to_string(x)+"_"+to_string(y));

			MyLink1->GetResourceType()->SetMaxFrequencyInHz(CoreFrequency);
			MyLink1->SetStaticEnergyPerTimeUnit(StaticEnergyLink*StaticCoreFrequency,s);
			MyLink2->GetResourceType()->SetMaxFrequencyInHz(CoreFrequency);
			MyLink2->SetStaticEnergyPerTimeUnit(StaticEnergyLink*StaticCoreFrequency,s);
			MyLink1->SetIsIdle(false);
			MyLink2->SetIsIdle(false);

			MyLink1->SetDynamicEnergyMultiplierPerClockCycle(DynamicEnergyLink);
			MyLink2->SetDynamicEnergyMultiplierPerClockCycle(DynamicEnergyLink);
			MyLink1->SetStaticEnergyPerTimeUnit(0,s);
			MyLink2->SetStaticEnergyPerTimeUnit(0,s);
			MyLink1->SetDynamicEnergyMultiplierPerClockCycle(0);
			MyLink2->SetDynamicEnergyMultiplierPerClockCycle(0);


			MyLinks.push_back(MyLink1);
			MyLinks.push_back(MyLink2);
			MyScheduler->AddCore(MyLink1);
			MyScheduler->AddCore(MyLink2);
			mapNameLink[MyLink1->GetName()]=MyLink1;
			mapNameLink[MyLink2->GetName()]=MyLink2;
		}
	}


		for(int y=0;y<NoCYSize;y++) {
		for(int x=0;x<NoCXSize;x++) {
			IAResource* MyLink1 = new IAResource("Core_"+to_string(x)+"_"+to_string(y)+"-Router_"+to_string(x)+"_"+to_string(y));
			IAResource* MyLink2 = new IAResource("Router_"+to_string(x)+"_"+to_string(y)+"-Core_"+to_string(x)+"_"+to_string(y));

			MyLink1->GetResourceType()->SetMaxFrequencyInHz(CoreFrequency);
			MyLink1->SetStaticEnergyPerTimeUnit(StaticEnergyLink*StaticCoreFrequency,s);
			MyLink2->GetResourceType()->SetMaxFrequencyInHz(CoreFrequency);
			MyLink2->SetStaticEnergyPerTimeUnit(StaticEnergyLink*StaticCoreFrequency,s);
			MyLink1->SetIsIdle(false);
			MyLink2->SetIsIdle(false);

			MyLink1->SetDynamicEnergyMultiplierPerClockCycle(DynamicEnergyLink);
			MyLink2->SetDynamicEnergyMultiplierPerClockCycle(DynamicEnergyLink);
			MyLink1->SetStaticEnergyPerTimeUnit(0,s);
			MyLink2->SetStaticEnergyPerTimeUnit(0,s);
			MyLink1->SetDynamicEnergyMultiplierPerClockCycle(0);
			MyLink2->SetDynamicEnergyMultiplierPerClockCycle(0);
			
			MyLinks.push_back(MyLink1);
			MyLinks.push_back(MyLink2);
			MyScheduler->AddCore(MyLink1);
			MyScheduler->AddCore(MyLink2);
			mapNameLink[MyLink1->GetName()]=MyLink1;
			mapNameLink[MyLink2->GetName()]=MyLink2;
		}
	}

	int nNoOfTasks=AmaltheaSystem::instance()->GetNoOfTasks();
	for(int i=0;i<nNoOfTasks;i++) {
		Task* MyTask = AmaltheaSystem::instance()->GetTask(i);
		
		int nNoOfRunnables=MyTask->GetNoOfRunnables();
		Job* MyJobPrev=NULL;
		for(int j=0;j<nNoOfRunnables;j++) {
			Runnable* MyRunnable = MyTask->GetRunnable(j);
			
			
			
			Job *MyJob=new Job(DoUnique(MyRunnable->GetName()));
			mapRunnableJob[MyRunnable]=MyJob;

			if(j==0) {
				//for the 1st runnable in the task only
				AmaltheaSystem::instance()->AddJobToStimuliDestinationsIfNecessary(MyTask,MyJob);
			}

			Time *TimeReleaseA;
			if(MyTask->GetStimulus()!=NULL) {
				TimeReleaseA = new TimeDeterministic(MyTask->GetStimulus()->GetOffset().first,strToTimeUnit(MyTask->GetStimulus()->GetOffset().second));
			}
			else  {
				TimeReleaseA = new TimeDeterministic(0);
			}

			MyJob->SetReleaseTime(TimeReleaseA);

			if(MyTask->GetStimulus()!=NULL) {
				Time *TimePeriodA = new TimeDeterministic(MyTask->GetStimulus()->GetRecurrence().first,strToTimeUnit(MyTask->GetStimulus()->GetRecurrence().second));
				MyJob->SetPeriod(TimePeriodA);
			}

			int nTickExecute=MyRunnable->GetWCETInTick();

			for(int l=0;l<MyCores.size();l++) {
				nQuartzFrequency=AmaltheaSystem::instance()->GetAmCore(0)->GetQuartz()->GetFrequency()/1000000;		
				nQuartzFrequency=1000;

				nTicksPerCycle=AmaltheaSystem::instance()->GetAmCore(0)->GetCoreType()->GetInstructionsPerCycle();

				if(nTicksPerCycle==0) {
					nTicksPerCycle=1;
				}
				Time *TimeExecuteA=new TimeDeterministic(ceil((double)nTickExecute/nQuartzFrequency)*nTicksPerCycle*ExecutionTimeMultiplier,us);  //us, since we divided the frequency by 1000000
				MyJob->SetExecutionTimeForResource(TimeExecuteA,MyCores[l]);

			}
#ifdef MapDirectlyFromList
		pair<int,int> MappingMapToBeMapped;		
		MappingMapToBeMapped=MappingMap.at(MyJob->GetName());
		int XToBeMapped=MappingMapToBeMapped.first;
		int YToBeMapped=MappingMapToBeMapped.second;

		MyJob->AddExecutingCore(MyCores[YToBeMapped*NoCXSize + XToBeMapped]);
#else			
			int IndexOfRunnable=AmaltheaSystem::instance()->GetIndexOfRunnable(MyRunnable);
			MyJob->AddExecutingCore(MyCores[CoreAssignment[IndexOfRunnable]%(NoCXSize*NoCYSize-IdleCores)]);
#endif

			Time *DeadlineA = new TimeDeterministic(MyTask->GetDeadlineValue(),strToTimeUnit(MyTask->GetDeadlineUnit()));
			MyJob->SetDeadline(DeadlineA);

			if(MyJobPrev!=NULL) {
				MyJob->AddDependency(MyJobPrev);
			}



		
			for(int k=0;k<MyRunnable->GetNoOfInstructions();k++) {
				if(MyRunnable->GetNameOfInstruction(k)=="sw:LabelAccess") {
					Job* MyTransferJob;
					list<IAResource*>* Path;
					string LabelName=MyRunnable->GetLabelNameOfLabelAccessInstruction(k);
					Label* MyLabel=AmaltheaSystem::instance()->GetLabelByName(LabelName);
#ifdef MapDirectlyFromList
		pair<int,int> MappingMapToBeMapped;		
		MappingMapToBeMapped=MappingMap.at(MyJob->GetName());
		int XToBeMapped=MappingMapToBeMapped.first;
		int YToBeMapped=MappingMapToBeMapped.second;

		IAResource *LabelCore=MyCores[YToBeMapped*NoCXSize + XToBeMapped];
#else

					int IndexOfLabel=AmaltheaSystem::instance()->GetIndexOfLabel(MyLabel);
					IAResource *LabelCore=MyCores[LabelAssignment[IndexOfLabel]%(NoCXSize*NoCYSize-IdleCores)];
#endif
					bool IsWrite=MyRunnable->CheckIfWriteAccessInstruction(k);
					if(IsWrite) {
						MyTransferJob=new Job(DoUnique("Comm_"+MyRunnable->GetName()+"_L:"+LabelName));
						MyTransferJob->AddDependency(MyJob);
						MyJob->SynchrNoC.push_back(MyTransferJob);
						Path=GetPathBetween(MyJob->GetTheFirstExecutingCore(),LabelCore);
					}
					else {
						MyTransferJob=new Job(DoUnique("Comm_L:"+LabelName+"_"+MyRunnable->GetName()));
						MyJob->AddDependency(MyTransferJob);
						Path=GetPathBetween(LabelCore,MyJob->GetTheFirstExecutingCore());
					}

					Time *MyReleaseTime=new TimeDeterministic(0);
					MyTransferJob->SetReleaseTime(MyReleaseTime);
					Time *TimeDeadline=MyJob->GetDeadline()->Clone();
					MyTransferJob->SetDeadline(TimeDeadline);
					Time *TimePeriod=MyJob->GetPeriod()->Clone();
					MyTransferJob->SetPeriod(TimePeriod);
					MyTransferJob->SetPriority(MyJob->GetPriority());


					if(Path->size()==0) { //src and dest are in the same core
						MyTransferJob->SetExecutingCores(MyJob->GetExecutingCores());
					}
					else {
						MyTransferJob->SetExecutingCores(Path);
					}
					int TransferTimeinClockCycles;
					if(Path->empty()) {
						TransferTimeinClockCycles=ZeroHopDelayinClockCycles;
					}
					else {
						TransferTimeinClockCycles=OneHopDelayinClockCycles*Path->size()+OneRouterDelayinClockCycles*(Path->size()-1);
					}

					delete Path;


					Time *MyComputationTime=new TimeDeterministic(static_cast<int>(ceil(static_cast<double>(MyLabel->GetSize())/FlitSize)*TransferTimeinClockCycles*ClockPeriod.GetValue()),ClockPeriod.GetUnit());
					MyTransferJob->SetExecutionTimeForExecutingResource(MyComputationTime);

					if(MyTransferJob->GetPeriod()!=NULL && MyTransferJob->GetPeriod()->GetValue()!=0 && HyperPeriod!=NULL) {
						int NoOfJobs=MyScheduler->GetAllJobsList().size();
						MyScheduler->AddPeriodicJob(MyTransferJob,HyperPeriod,false);
						int NoOfJobs2=MyScheduler->GetAllJobsList().size();
						if(NoOfJobs2==NoOfJobs) {
							TransferJobToSecondPass.push_back(MyTransferJob);
						}
					}
					else {
						MyScheduler->AddJobA(MyTransferJob);
					}
					JobList->push_back(MyTransferJob);

					AddedTasks++;


				}
			}


			if(MyJob->GetPeriod()!=NULL && MyJob->GetPeriod()->GetValue()!=0 && HyperPeriod!=NULL) {
				MyScheduler->AddPeriodicJob(MyJob,HyperPeriod);
			}
			else {
				MyScheduler->AddJobA(MyJob);
			}

			JobList->push_back(MyJob);
			AddedTasks++;

			if(MyJobPrev!=NULL && MyJob->GetTheFirstExecutingCore()!=MyJobPrev->GetTheFirstExecutingCore()) {
				//synchronization between subsequent runnables situated in different cores


				Job* MySynchronizationJob;
				list<IAResource*>* Path;

				MySynchronizationJob=new Job(DoUnique("Synch_"+MyJobPrev->GetName()+"_"+MyJob->GetName()));
				MySynchronizationJob->AddDependency(MyJobPrev);
				MyJobPrev->SynchrNoC.push_back(MySynchronizationJob);
				MyJob->AddDependency(MySynchronizationJob);
				Path=GetPathBetween(MyJobPrev->GetTheFirstExecutingCore(),MyJob->GetTheFirstExecutingCore());



				Time *MyReleaseTime=new TimeDeterministic(0);
				MySynchronizationJob->SetReleaseTime(MyReleaseTime);
				Time *TimeDeadline=MyJob->GetDeadline()->Clone();
				MySynchronizationJob->SetDeadline(TimeDeadline);
				Time *TimePeriod=MyJobPrev->GetPeriod()->Clone();
				MySynchronizationJob->SetPeriod(TimePeriod);
				MySynchronizationJob->SetPriority(MyJobPrev->GetPriority());

				MySynchronizationJob->SetExecutingCores(Path);

				int TransferTimeinClockCycles;
				if(Path->empty()) {
					TransferTimeinClockCycles=ZeroHopDelayinClockCycles;
				}
				else {
					TransferTimeinClockCycles=OneHopDelayinClockCycles*Path->size()+OneRouterDelayinClockCycles*(Path->size()-1);
				}
				delete Path;

				Time *MyComputationTime=new TimeDeterministic(static_cast<int>(TransferTimeinClockCycles*ClockPeriod.GetValue()),ClockPeriod.GetUnit());
				MySynchronizationJob->SetExecutionTimeForExecutingResource(MyComputationTime);

				
				if(MySynchronizationJob->GetPeriod()!=NULL && MySynchronizationJob->GetPeriod()->GetValue()!=0 && HyperPeriod!=NULL) {
					MyScheduler->AddPeriodicJob(MySynchronizationJob,HyperPeriod);
				}
				else {
					MyScheduler->AddJobA(MySynchronizationJob);
				}



				JobList->push_back(MySynchronizationJob);

				AddedTasks++;

			}



		


			MyJobPrev=MyJob;
		}


	AmaltheaSystem::instance()->AddJobToStimuliSourcesIfNecessary(MyTask,MyJobPrev);
	}

	list<Job*>::iterator it;
	for (it=TransferJobToSecondPass.begin();it!=TransferJobToSecondPass.end();++it) {
		MyScheduler->AddPeriodicJob(*it,HyperPeriod);
	}

	AmaltheaSystem::instance()->AddTaskDependencesFromStimuli();

	

	MyScheduler->Preserve();
	MyScheduler->SortJobByTime();

	double result = static_cast<int>(MyScheduler->GetLatestJob()->GetEndTime()->GetValue());
	

	MyScheduler->ComputeDeadlineCounters();
	double MyEnergy=MyScheduler->GetEnergy();
	result+=	MyScheduler->GetAfterDeadlineCounter()*50000;
	cout << "Energy: " << MyEnergy << " [uJ]"<< endl;

	

		list<TreeNode* >::iterator it1;
		int i=0;
		TreeNode* Tmp;
		for (it1 = AllTreeNodes.begin(); it1!= AllTreeNodes.end(); ++it1,i++) {
				Tmp=*it1;
				*it1=NULL;
				if(i!=0 && Tmp->t->GetJobA()->GetName()=="Start") {
				}
				else {
					delete Tmp->t->GetJobA();
				}
				delete Tmp->t;
				delete Tmp;
			}
	AllTreeNodes.clear();
	NamesSet.clear();

	delete MyScheduler;


	delete JobList;

	vector<IAResource*>::iterator itCores2;
	for(itCores2=MyCores.begin(); itCores2!=MyCores.end() ; ++itCores2) {
		delete *itCores2;
	}

	for(itCores2=MyLinks.begin(); itCores2!=MyLinks.end() ; ++itCores2) {
		delete *itCores2;
	}



	mapCoreTime.clear();
	mapJob_TreeNode.clear();
	MyCores.clear();
	MyLinks.clear();
	mapNameCore.clear();
	mapNameLink.clear();

	end = clock();
	AmaltheaSystem::instance()->ClearJobs();
	delete HyperPeriod;

	return pair<double,double>(result,MyEnergy);
}







bool TestUnit::RealTimeAnalysisAmalthea(vector<int> &CoreAssignment) {

	bool result=true;

	SchedulerFIFO *MySchedulerFIFO=new SchedulerFIFO;


	list<Job*>* JobList=new list<Job*>;

	vector<IAResource*> Cores;

	unsigned long long nQuartzFrequency=1;
	int nTicksPerCycle=0;

	for(int l=0;l<AmaltheaSystem::instance()->GetNoOfAmCores();l++) {
		nQuartzFrequency=AmaltheaSystem::instance()->GetAmCore(l)->GetQuartz()->GetFrequency()/1000000;		
		nTicksPerCycle=AmaltheaSystem::instance()->GetAmCore(l)->GetCoreType()->GetInstructionsPerCycle();

		if(nTicksPerCycle==0) {
			nTicksPerCycle=1;
		}

		IAResource* MyCore=new IAResource(AmaltheaSystem::instance()->GetAmCore(l)->GetName());
		MyCore->SetResourceType(AmaltheaSystem::instance()->GetAmCore(l)->GetCoreType()->GetName());
		Cores.push_back(MyCore);
	}



	int nNoOfTasks=AmaltheaSystem::instance()->GetNoOfTasks();
	for(int i=0;i<nNoOfTasks;i++) {
		Task* MyTask = AmaltheaSystem::instance()->GetTask(i);
		int nNoOfRunnables=MyTask->GetNoOfRunnables();
		Job* MyJobPrev=NULL;
		for(int j=0;j<nNoOfRunnables;j++) {
			Runnable* MyRunnable = MyTask->GetRunnable(j);
			
			
			
			Job *MyJob=new Job(DoUnique(MyRunnable->GetName()));

			if(j==0) {
				//for the 1st runnable in the task only
				AmaltheaSystem::instance()->AddJobToStimuliDestinationsIfNecessary(MyTask,MyJob);
			}

			Time *TimeReleaseA;
			if(MyTask->GetStimulus()!=NULL) {
				TimeReleaseA = new TimeDeterministic(MyTask->GetStimulus()->GetOffset().first,strToTimeUnit(MyTask->GetStimulus()->GetOffset().second));
			}
			else  {
				TimeReleaseA = new TimeDeterministic(0);
			}

			MyJob->SetReleaseTime(TimeReleaseA);

			if(MyTask->GetStimulus()!=NULL) {
				Time *TimePeriodA = new TimeDeterministic(MyTask->GetStimulus()->GetRecurrence().first,strToTimeUnit(MyTask->GetStimulus()->GetRecurrence().second));
				MyJob->SetPeriod(TimePeriodA);
			}

			int nTickExecute=MyRunnable->GetWCETInTick();

			if(AmaltheaSystem::instance()->GetNoOfAmCores()>0) {
				for(int l=0;l<AmaltheaSystem::instance()->GetNoOfAmCores();l++) {
					nQuartzFrequency=AmaltheaSystem::instance()->GetAmCore(l)->GetQuartz()->GetFrequency()/1000000;		
					nTicksPerCycle=AmaltheaSystem::instance()->GetAmCore(l)->GetCoreType()->GetInstructionsPerCycle();

					if(nTicksPerCycle==0) {
						nTicksPerCycle=1;
					}

					Time *TimeExecuteA=new TimeDeterministic(ceil((double)nTickExecute/nQuartzFrequency)*nTicksPerCycle,us);  //us, since we divided the frequency by 1000000
					MyJob->SetExecutionTimeForResource(TimeExecuteA,Cores[l]);

				}


			}
			else {

					Time *TimeExecuteA=new TimeDeterministic(ceil((double)nTickExecute/nQuartzFrequency)*nTicksPerCycle,us);  //us, since we divided the frequency by 1000000
					MyJob->SetExecutionTimeForExecutingResource(TimeExecuteA);
			}


			Time *DeadlineA = new TimeDeterministic(MyTask->GetDeadlineValue(),strToTimeUnit(MyTask->GetDeadlineUnit()));
			MyJob->SetDeadline(DeadlineA);

			if(MyJobPrev!=NULL) {
				MyJob->AddDependency(MyJobPrev);
			}

			MyJob->AddExecutingCore(Cores[CoreAssignment[j]]);
			MySchedulerFIFO->AddJobA(MyJob);
			JobList->push_back(MyJob);
			MyJobPrev=MyJob;
		}
		AmaltheaSystem::instance()->AddJobToStimuliSourcesIfNecessary(MyTask,MyJobPrev);


	}

	AmaltheaSystem::instance()->AddTaskDependencesFromStimuli();




	vector<IAResource*>::iterator itCores;
	for(itCores=Cores.begin(); itCores!=Cores.end() ; ++itCores) {
		cout << (*itCores)->GetName() << ": ";
		if(MySchedulerFIFO->PerformRealTimeAnalysisForCore(*itCores)) {
			cout << "Scheduable" << endl;
		}
		else {
			cout << "Nonscheduable" << endl;
			result=false;
		}


	}








		list<TreeNode* >::iterator it1;
		int i=0;
		TreeNode* Tmp;
		for (it1 = AllTreeNodes.begin(); it1!= AllTreeNodes.end(); ++it1,i++) {
				Tmp=*it1;
				*it1=NULL;
				if(i!=0 && Tmp->t->GetJobA()->GetName()=="Start") {
				}
				else {
					delete Tmp->t->GetJobA();
				}
				delete Tmp->t;
				delete Tmp;
			}
	AllTreeNodes.clear();
	NamesSet.clear();

	delete MySchedulerFIFO;


	delete JobList;

	for(itCores=Cores.begin(); itCores!=Cores.end() ; ++itCores) {
		delete *itCores;
	}
	
	AmaltheaSystem::instance()->ClearJobs();
	return result;


}






Time* TestUnit::CTCreateTimeDeterministic(long long ValueIn,TimeUnit UnitIn) {
	Time* MyExecutionTime=new TimeDeterministic(ValueIn,UnitIn);
	return MyExecutionTime;

}


void TestUnit::CTBeginTransaction() {
	CTTransactionTasks.clear();
	CTTransactionMode=true;
	CTmapCoreTimeBackupForTransactionRollback.clear();

	vector<IAResource*>::iterator it1;


	for(it1=CTCores.begin();it1!=CTCores.end();++it1) {
		if(mapCoreTime.count(*it1)>0)
		CTmapCoreTimeBackupForTransactionRollback[*it1]=mapCoreTime.at(*it1)->Clone();
	}



}

void TestUnit::CTCommitTransaction() {
	CTTransactionTasks.clear();
	CTTransactionMode=false;

	vector<IAResource*>::iterator it1;

	for(it1=CTCores.begin();it1!=CTCores.end();++it1) {
		if(CTmapCoreTimeBackupForTransactionRollback.count(*it1)>0)
		delete CTmapCoreTimeBackupForTransactionRollback[*it1];
	}

	CTmapCoreTimeBackupForTransactionRollback.clear();
}

void TestUnit::CTRollbackTransaction() {
	list<string>::iterator it;

	for(it=CTTransactionTasks.begin();it!=CTTransactionTasks.end();++it) {
		CTRemoveJobFromCore(&(*it),0);
		CTRemoveJob(&(*it));
	}
	CTTransactionTasks.clear();
	CTTransactionMode=false;

	vector<IAResource*>::iterator it1;

	for(it1=CTCores.begin();it1!=CTCores.end();++it1) {
		if(mapCoreTime.count(*it1)>0)
		delete mapCoreTime[*it1];
	}

	mapCoreTime.clear();
	mapCoreTime=CTmapCoreTimeBackupForTransactionRollback;
	CTmapCoreTimeBackupForTransactionRollback.clear();
}


void TestUnit::CTCreateJob(string *NameIn) {
	Job* MyJob= new Job(*NameIn);
	CTJobMap[*NameIn]=MyJob;


}

void TestUnit::CTRemoveJob(string *NameIn) {
	CTJobMap.erase(*NameIn);
}

void TestUnit::CTUpdateExecutionTime(string *NameIn,int ValueIn) {
	Time* MyTime=new TimeDeterministic(ValueIn,ps);
	CTJobMap.at(*NameIn)->SetExecutionTimeForExecutingResource(MyTime);

	list<IAResource*>::iterator it;


	Job *MyJob=CTSchedulerFIFO->FindJobByName(*NameIn);
	if(MyJob==NULL) {
		return;
	}

	MyJob->SetExecutionTimeForExecutingResource(MyTime);
	JobTree *MyJobTree = CTSchedulerFIFO->GetJobTree();

	Time *TimeStart=MyJob->GetStartTime()->Clone();
	Time *OldEndTime=MyJob->GetEndTime()->Clone();
	MyJob->SetStartAndEndTime(TimeStart);
	delete TimeStart;

				if(MyJob->GetExecutingCores()->empty()) {
					if(mapCoreTime.find(NULL)!=mapCoreTime.end() && *mapCoreTime.at(NULL)==*OldEndTime) {
						delete(mapCoreTime[NULL]);
						mapCoreTime[NULL]=MyJob->GetEndTime()->Clone();
					}

			}
			else {
				for(it=MyJob->GetExecutingCores()->begin();it!=MyJob->GetExecutingCores()->end();++it) {
					if(mapCoreTime.find(*it)!=mapCoreTime.end()&&*mapCoreTime.at(*it)==*OldEndTime) {
						delete(mapCoreTime[*it]);
						mapCoreTime[*it]=MyJob->GetEndTime()->Clone();
					}


				}
			}

}

void TestUnit::CTUpdateReleaseTime(string *NameIn,int ValueIn) {
	Time* MyTime=new TimeDeterministic(ValueIn,ps);
	CTJobMap.at(*NameIn)->SetReleaseTime(MyTime);
}



void TestUnit::CTSetExecutionTimeForExecutingResource(string *NameIn,long long MyTimeVal,TimeUnit MyTimeUnit) {
	Time* MyTime=new TimeDeterministic(MyTimeVal,MyTimeUnit);
	CTJobMap.at(*NameIn)->SetExecutionTimeForExecutingResource(MyTime);
}

void TestUnit::CTSetReleaseTime(string *NameIn,long long MyTimeVal,TimeUnit MyTimeUnit) {
	Time* MyTime=new TimeDeterministic(MyTimeVal,MyTimeUnit);
	CTJobMap.at(*NameIn)->SetReleaseTime(MyTime);
}

void TestUnit::CTSetDeadline(string *NameIn,long long MyTimeVal,TimeUnit MyTimeUnit) {
	Time* MyTime=new TimeDeterministic(MyTimeVal,MyTimeUnit);
	CTJobMap.at(*NameIn)->SetDeadline(MyTime);
}


bool TestUnit::CTCheckSchedulabilityFIFO() {

	SchedulerFIFO MySchedulerFIFO;

	bool bResult=true;

	map<string,Job*>::iterator it;
	string MyJobName;
	int Counter=CTJobMap.size();

	for(it=CTJobMap.begin();it!=CTJobMap.end();++it) {
		(*it).second->ClearDependencies();
		(*it).second->SetReady(false);
		(*it).second->SetScheduled(false);
		if(Counter-- == 1) {
			Time *MyTime;
			MyTime=((*it).second->GetExecutionTimeForExecutingResource());
			Time *MyTimeOffset;
			MyTimeOffset=new TimeDeterministic(2,ns);
			Time *TimeResult=Add(*MyTime,*MyTimeOffset);				//2ns extra are used for maintaining consistency with SystemC simulator
			delete MyTimeOffset;
			delete MyTime;
			(*it).second->SetExecutionTimeForExecutingResource(TimeResult);
		}
		MySchedulerFIFO.AddJobA((*it).second);
	}

	MySchedulerFIFO.Preserve();




	if(MySchedulerFIFO.GetAfterDeadlineCounter()>0) {
		bResult=false;
	}
	else {
		--it;
		Job* MyJob=(*it).second;
	}
	mapCoreTime.clear();
	return bResult;
}


void TestUnit::CTInitCheckSchedulabilityIncrementalFIFO() {
	CTSchedulerFIFO = new SchedulerFIFO();
	CTSchedulerFIFO->AddEndJob();
	CTSchedulerFIFO->DetermineDependencyLevelOfAllJobs();
	CTSchedulerFIFO->Initialize();
	Job *StartJob=CTSchedulerFIFO->FindJobByName("Start");
	StartJob->SetReady(true);
	StartJob->SetScheduled(true);
}


bool TestUnit::CTTryAddParentJobName(string *NameIn,string *ParentJobName) {
	Job *MyJob=CTJobMap.at(*NameIn);

	map<string,Job*>::iterator it;
	it=CTJobMap.find(*ParentJobName);

	if(it==CTJobMap.end()) {
		return false;
	}
	else {
		MyJob->AddDependency((*it).second);
		return true;
	}



}

void TestUnit::CTRemoveCheckSchedulabilityIncrementalFIFO() {
	delete CTSchedulerFIFO;
}


bool TestUnit::CTCheckSchedulabilityIncrementalFIFO(string *NameIn) {
	bool bResult;
	Job *MyJob=CTJobMap.at(*NameIn);

	Time *MyTime;
	MyTime=MyJob->GetExecutionTimeForExecutingResource();

	Time *MyTimeOffset;
	MyTimeOffset=new TimeDeterministic(2,ns);
	Time *TimeResult=Add(*MyTime,*MyTimeOffset);				//2ns extra are used for maintaining consistency with SystemC simulator
	delete MyTimeOffset;

	delete MyTime;
	MyJob->SetExecutionTimeForExecutingResource(TimeResult);


	CTSchedulerFIFO->AddJobA(MyJob);
	JobTree *MyJobTree = CTSchedulerFIFO->GetJobTree();
	Job *EndJob=MyJobTree->GetRoot()->GetJobA();
	TreeNode *EndTreeNode=MyJobTree->FindTreeNode(MyJobTree->GetRootTreeNode(),EndJob);
	JobTreeNode *EndJobTreeNode=MyJobTree->FindNode(MyJobTree->GetRootTreeNode(),EndJob);


	Job *StartJob=CTSchedulerFIFO->FindJobByName("Start");
	TreeNode *StartTreeNode=MyJobTree->FindTreeNode(MyJobTree->GetRootTreeNode(),StartJob);
	JobTreeNode *StartJobTreeNode=MyJobTree->FindNode(MyJobTree->GetRootTreeNode(),StartJob);

	
	JobTreeNode *MyJobTreeNode=new JobTreeNode(MyJob);

	TreeNode *MyTreeNode = new TreeNode();
	AllTreeNodes.push_back(MyTreeNode);
	mapJob_TreeNode[MyJob]=MyTreeNode;
		
	MyTreeNode->t=MyJobTreeNode;
	MyTreeNode->AddChildren(StartTreeNode);
	EndTreeNode->AddChildren(MyTreeNode);


	for(int i=0;i<MyJob->GetDependentOnListSize();i++) {
		Job *ParentJob=MyJob->GetDependentOnListElement(i);
		if(ParentJob->GetName()!="Start") {
			TreeNode *ParentTreeNode=MyJobTree->FindTreeNode(MyJobTree->GetRootTreeNode(),ParentJob);
			MyTreeNode->AddChildren(ParentTreeNode);
		}
	}


	


	Time *t=MyJobTree->DetermineStartTime(MyJob);
	MyJob->SetStartAndEndTime(t);


	Time* CurrentTime=MyJob->GetEndTime();

	if(MyJob->GetName()!="End"&&*CurrentTime<=*MyJob->GetDeadline()) {
		CTSchedulerFIFO->IncreaseBeforeDeadlineCounter();
		MyJob->SetScheduled(true);
			list<IAResource*>::iterator it;
			
			if(MyJob->GetName()!="CriticalPath") {


				if(MyJob->GetExecutingCores()->empty()) {
						delete mapCoreTime[NULL];
						mapCoreTime[NULL]=CurrentTime->Clone();
				}
				else {
					for(it=MyJob->GetExecutingCores()->begin();it!=MyJob->GetExecutingCores()->end();++it) {
						delete mapCoreTime[*it];
						mapCoreTime[*it]=CurrentTime->Clone();
					}
				}
				if(CTTransactionMode) {
					CTTransactionTasks.push_back(*NameIn);
				}
			}
		bResult=true;


	}
	else {
		MyJobTree->RemoveJustAddedNode(mapJob_TreeNode.at(MyJob));
		CTSchedulerFIFO->RemoveFromAllJobsAndAllJobsMap(MyJob);
		bResult=false;
	}
	return bResult;
}



void TestUnit::CTSetNoOfCores(int NoOfProcessorsIn) {
	CTCores.resize(NoOfProcessorsIn);
	for(int i=0;i<NoOfProcessorsIn;i++) {
		IAResource *MyCore=new IAResource("Core_"+to_string(i));
		CTCores[i]=MyCore;
	}
}

void TestUnit::CTRemoveCores() {
	vector<IAResource*>::iterator it;
	for(it=CTCores.begin();it!=CTCores.end();++it) {
		delete (*it);
	}
	CTJobCoreMap.clear();
}


void TestUnit::CTAssignJobToCore(string *NameIn,int PUChosen) {
	CTJobCoreMap[*NameIn]=CTCores[PUChosen];
	if(CTJobMap.at(*NameIn)->GetTheFirstExecutingCore()==NULL) {
		CTJobMap.at(*NameIn)->AddExecutingCore(CTCores[PUChosen]);
	}
	else {
		CTJobMap[*NameIn]->OverwriteTheFirstExecutingCore(CTCores[PUChosen]);
	}
}

void TestUnit::CTRemoveJobFromCore(string *NameIn,int PUChosen) {
	CTJobMap.at(*NameIn)->RemoveExecutingCores(CTJobCoreMap[*NameIn]);
	CTJobCoreMap.erase(*NameIn);
}




