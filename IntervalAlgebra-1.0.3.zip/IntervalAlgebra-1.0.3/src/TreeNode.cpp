#include <limits.h>
#include <map>
#include "TreeNode.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


namespace IntervalAlgebra
{
		TreeNode::TreeNode(): VisitedAtIteration(-1){
		}


		TreeNode::~TreeNode() {
		}



		void TreeNode::RemoveFromThisNode() {
		}


	   void TreeNode::AddChildren(TreeNode *tn) {
		   children.push_back(tn);
		   multimapJob_ParentTreeNode.insert(pair<Job*,TreeNode*>(tn->t->GetJobA(),this));
	   }


	   void TreeNode::AddChildrenToEachParent(TreeNode *tn, int Iteration) {

		vector<TreeNode*> ::iterator it;
		bool Found=false;
		if(t->GetJobA()->DependsDirectlyOn(tn->t->GetJobA())) {
			for (it = children.begin(); !Found && it!= children.end(); ++it) {
				if((*it)==tn) {
					Found=true;
					break;
				}
			}
			if(!Found) {
				AddChildren(tn);
			}
		}

		this->VisitedAtIteration=Iteration;
		for (it = children.begin(); it!= children.end(); ++it) {
			if((*it)->VisitedAtIteration!=Iteration) {
				(*it)->AddChildrenToEachParent(tn,Iteration);
			}
		}
	  }
	   
	Job* TreeNode::FindTheEarliestReadyJobOfTheHighestPriority(TreeNode* RootTreeNode,Time *CurrentTime, Job* JobIn, unsigned int HighestPriority,int iteration){

		Job* EarliestJob=JobIn;
		VisitedAtIteration=iteration;

		if(t->GetJobA()->IsReady() && !t->GetJobA()->IsScheduled()) {
			
			if(EarliestJob==NULL || (*GetReadyTime(RootTreeNode,t->GetJobA())<*GetReadyTime(RootTreeNode,EarliestJob) 
			&&(CurrentTime==NULL || !((*GetReadyTime(RootTreeNode,t->GetJobA())<=*CurrentTime) &&  *GetReadyTime(RootTreeNode,EarliestJob)<=*CurrentTime)))) {  //if both release time are before the current time, we can treat them as equal
				EarliestJob=t->GetJobA();
				HighestPriority=t->GetJobA()->GetPriority();
			}
			else if(EarliestJob==NULL||((*GetReadyTime(RootTreeNode,t->GetJobA())==*GetReadyTime(RootTreeNode,EarliestJob) 
			|| CurrentTime==NULL || ((*GetReadyTime(RootTreeNode,t->GetJobA())<=*CurrentTime) &&  *GetReadyTime(RootTreeNode,EarliestJob)<=*CurrentTime))  
			&& t->GetJobA()->GetPriority()>HighestPriority)) {
				EarliestJob=t->GetJobA();
				HighestPriority=t->GetJobA()->GetPriority();
			}

		}

		vector<TreeNode*> ::iterator it;
		for (it = children.begin(); it!= children.end(); ++it) {
			if((*it)->VisitedAtIteration!=iteration) {
				EarliestJob=(*it)->FindTheEarliestReadyJobOfTheHighestPriority(RootTreeNode,CurrentTime,EarliestJob,HighestPriority,iteration);
				if(EarliestJob!=NULL) {
					HighestPriority=EarliestJob->GetPriority();
				}
			}
		}

		return EarliestJob;

	}

	Job* TreeNode::FindTheEarliestReadyJobOfTheHighestPriorityForCore(TreeNode* RootTreeNode,Time *CurrentTime, Job* JobIn, unsigned int HighestPriority,IAResource* CoreIn,int iteration){

		Job* EarliestJob=JobIn;
		VisitedAtIteration=iteration;




		if(t->GetJobA()->IsReady() && !t->GetJobA()->IsScheduled() && t->GetJobA()->CheckIfExecutedByCore(CoreIn)) {

			if(this->t->GetJobA()->GetName()=="7__$1") {
				cout << "a";
			}
			if (CurrentTime==NULL || *GetTheLatestEndTimeOfChildren(RootTreeNode,t->GetJobA())<=*CurrentTime) {

				if(EarliestJob==NULL || (*GetReadyTime(RootTreeNode,t->GetJobA())<*GetReadyTime(RootTreeNode,EarliestJob) 
				&&(CurrentTime==NULL || !((*GetReadyTime(RootTreeNode,t->GetJobA())<=*CurrentTime) &&  *GetReadyTime(RootTreeNode,EarliestJob)<=*CurrentTime)))) {  //if both release time are before the current time, we can treat them as equal
					EarliestJob=t->GetJobA();
					HighestPriority=t->GetJobA()->GetPriority();
				}
				else if((EarliestJob==NULL||((*GetReadyTime(RootTreeNode,t->GetJobA())==*GetReadyTime(RootTreeNode,EarliestJob) 
				|| (CurrentTime!=NULL && *GetReadyTime(RootTreeNode,t->GetJobA())<=*CurrentTime) &&  *GetReadyTime(RootTreeNode,EarliestJob)<=*CurrentTime))  
				&& t->GetJobA()->GetPriority()>HighestPriority)) {
					EarliestJob=t->GetJobA();
					HighestPriority=t->GetJobA()->GetPriority();
				}
			}

		}

		vector<TreeNode*> ::iterator it;
		for (it = children.begin(); it!= children.end(); ++it) {
			if((*it)->VisitedAtIteration!=iteration) {
				EarliestJob=(*it)->FindTheEarliestReadyJobOfTheHighestPriorityForCore(RootTreeNode,CurrentTime,EarliestJob,HighestPriority,CoreIn,iteration);
				if(EarliestJob!=NULL) {
					HighestPriority=EarliestJob->GetPriority();
				}
			}
		}

		return EarliestJob;

	}

	Job* TreeNode::FindTheEarliestReadyJobOfTheHighestPriorityAndPriorityHigherThan(TreeNode* RootTreeNode,Job* ReferenceJob,Job* JobIn, unsigned int HighestPriority,int iteration) {
		Job* EarliestJob;
		Time *TaskReadyTime;
		EarliestJob=JobIn;

		VisitedAtIteration=iteration;


		if(GetTheLatestEndTimeOfChildren(RootTreeNode,t->GetJobA())!=NULL && !t->GetJobA()->IsScheduled() && t->GetJobA()->GetPriority()>ReferenceJob->GetPriority()) {
			if(*t->GetJobA()->GetReleaseTime()<*GetTheLatestEndTimeOfChildren(RootTreeNode,t->GetJobA())) {
				TaskReadyTime=GetTheLatestEndTimeOfChildren(RootTreeNode,t->GetJobA()); 
			}
			else {
				TaskReadyTime=t->GetJobA()->GetReleaseTime();
			}

			if(DetermineTheEarliestNonAllocatedTimeForExecutingCores(RootTreeNode,t->GetJobA())!=NULL
			&& *DetermineTheEarliestNonAllocatedTimeForExecutingCores(RootTreeNode,t->GetJobA())>*TaskReadyTime) {
				TaskReadyTime=DetermineTheEarliestNonAllocatedTimeForExecutingCores(RootTreeNode,t->GetJobA());
			}

			if(EarliestJob==NULL || *TaskReadyTime<*GetReadyTime(RootTreeNode,EarliestJob)) {
				EarliestJob=t->GetJobA();
				HighestPriority=EarliestJob->GetPriority();
			}
			else if((EarliestJob==NULL || *TaskReadyTime==*GetReadyTime(RootTreeNode,EarliestJob) && t->GetJobA()->GetPriority()>HighestPriority)) {
				EarliestJob=t->GetJobA();
				HighestPriority=t->GetJobA()->GetPriority();
			}

		}

		vector<TreeNode*> ::iterator it;
		for (it = children.begin(); it!= children.end(); ++it) {
			if((*it)->VisitedAtIteration!=iteration) {
				EarliestJob=(*it)->FindTheEarliestReadyJobOfTheHighestPriorityAndPriorityHigherThan(RootTreeNode,ReferenceJob,EarliestJob,HighestPriority,iteration);
				if(EarliestJob!=NULL && EarliestJob->GetPriority()>0) {
					HighestPriority=EarliestJob->GetPriority();
				}
			}
		}

		return EarliestJob;
	}


	Job* TreeNode::FindTheEarliestReadyJobOfTheHighestPriorityAndPriorityHigherThanForCore(TreeNode* RootTreeNode,Job* ReferenceJob,IAResource* CoreIn, Job* JobIn, unsigned int HighestPriority,int iteration) {
		Job* EarliestJob;
		Time *TaskReadyTime;

		VisitedAtIteration=iteration;

		EarliestJob=JobIn;




			if(!ReferenceJob->IsDependentOn(t->GetJobA()) && !(
				(ReferenceJob->GetName().find("__")!=string::npos && !(ReferenceJob->GetName()).compare(0,ReferenceJob->GetName().find("__"),t->GetJobA()->GetName(),0,ReferenceJob->GetName().find("__"))) ||
				!((ReferenceJob->GetName()).compare(0,ReferenceJob->GetName().length(),t->GetJobA()->GetName(),0,ReferenceJob->GetName().length()))
				)
				
				
				) {



				if(GetTheLatestEndTimeOfChildren(RootTreeNode,t->GetJobA())!=NULL && !t->GetJobA()->IsScheduled() && t->GetJobA()->GetPriority()>ReferenceJob->GetPriority() && t->GetJobA()->CheckIfExecutedByCore(CoreIn)) {


					if(*t->GetJobA()->GetReleaseTime()<*GetTheLatestEndTimeOfChildren(RootTreeNode,t->GetJobA())) {
						TaskReadyTime=GetTheLatestEndTimeOfChildren(RootTreeNode,t->GetJobA()); 
					}
					else {
						TaskReadyTime=t->GetJobA()->GetReleaseTime();
					}

					if(DetermineTheEarliestNonAllocatedTimeForExecutingCores(RootTreeNode,t->GetJobA())!=NULL
					&& *DetermineTheEarliestNonAllocatedTimeForExecutingCores(RootTreeNode,t->GetJobA())>*TaskReadyTime) {
						TaskReadyTime=DetermineTheEarliestNonAllocatedTimeForExecutingCores(RootTreeNode,t->GetJobA());
					}

					if(EarliestJob==NULL || *TaskReadyTime<*EarliestJob->GetReleaseTime()) {
						EarliestJob=t->GetJobA();
						HighestPriority=EarliestJob->GetPriority();

					}
					else if((EarliestJob==NULL || *TaskReadyTime==*EarliestJob->GetReleaseTime()) && t->GetJobA()->GetPriority()>HighestPriority) {
						EarliestJob=t->GetJobA();
						HighestPriority=t->GetJobA()->GetPriority();
					}

				}
			}
		vector<TreeNode*> ::iterator it;
		for (it = children.begin(); it!= children.end(); ++it) {
			if((*it)->VisitedAtIteration!=iteration) {

				EarliestJob=(*it)->FindTheEarliestReadyJobOfTheHighestPriorityAndPriorityHigherThanForCore(RootTreeNode,ReferenceJob,CoreIn,EarliestJob,HighestPriority,iteration);
				if(EarliestJob!=NULL && EarliestJob->GetPriority()>0) {
					HighestPriority=EarliestJob->GetPriority();
				}
			}
		}



		return EarliestJob;
	}


	Time* TreeNode::GetTheLatestEndTimeOfChildren(TreeNode* RootTreeNode,Job* JobIn) {
		Time *result=NULL;
		TreeNode* MyTreeNode;
		MyTreeNode=FindNodeWithJobFromRoot(RootTreeNode,JobIn);
		
		result=MyTreeNode->FindTheLatestEndTimeOfChildren();
		return result;
	}


	Job* TreeNode::FindJobExecutedByCoreAtTime(TreeNode* RootTreeNode,Job *JobIn,IAResource *CoreIn,Time* TimeIn,int iteration) {
		Job* JobTmp=JobIn;

		VisitedAtIteration=iteration;


		if(t->GetJobA()->IsScheduled() && t->GetJobA()->CheckIfExecutedByCore(CoreIn)) {
			Time *StartTime=t->GetJobA()->GetStartTime();
			Time *EndTime=t->GetJobA()->GetEndTime();
			if(StartTime!=NULL && EndTime!=NULL && *StartTime<*TimeIn && *TimeIn < *EndTime) {
				JobTmp=t->GetJobA();
				return JobTmp;
			}
		}

		vector<TreeNode*> ::iterator it;
		for (it = this->children.begin(); it!= this->children.end(); ++it) {
			if((*it)->VisitedAtIteration!=iteration) {
				JobTmp=(*it)->FindJobExecutedByCoreAtTime(RootTreeNode,JobTmp,CoreIn,TimeIn,iteration);
			}
		}

		return JobTmp;

	}


	Job* TreeNode::FindTheEarliestReadyJobForCore(TreeNode* RootTreeNode,Job* JobIn,IAResource* CoreIn,int iteration) {
		Job* JobTmp=JobIn;

		VisitedAtIteration=iteration;

		if(t->GetJobA()->IsReady() && !t->GetJobA()->IsScheduled() && t->GetJobA()->CheckIfExecutedByCore(CoreIn)) {

			if(JobTmp==NULL || *t->GetJobA()->GetReleaseTime()<=*JobTmp->GetReleaseTime()) {
				JobTmp=t->GetJobA();
			}
		}

		vector<TreeNode*> ::iterator it;
		for (it = this->children.begin(); it!= this->children.end(); ++it) {
			if((*it)->VisitedAtIteration!=iteration) {
				JobTmp=(*it)->FindTheEarliestReadyJobForCore(RootTreeNode,JobTmp,CoreIn,iteration);
			}
		}

		return JobTmp;
	}

	Job* TreeNode::FindTheEarliestReadyJob(TreeNode* RootTreeNode,Job* JobIn,int iteration) {

		Job* EarliestJob=JobIn;


		VisitedAtIteration=iteration;


		if(t->GetJobA()->IsReady() && !t->GetJobA()->IsScheduled() ) {




			Time* Tt;
			Time* TEarliest;
			Time* TtReady;
			Time* TEarliestReady;



			if(EarliestJob!=t->GetJobA()) {
				Tt=DetermineTheEarliestNonAllocatedTimeForExecutingCores(t->GetJobA());
				TtReady=GetReadyTime(RootTreeNode,t->GetJobA());
				if(EarliestJob!=NULL) {
					TEarliest=DetermineTheEarliestNonAllocatedTimeForExecutingCores(EarliestJob);
					TEarliestReady=GetReadyTime(RootTreeNode,EarliestJob);
				}
				else {
					TEarliest=NULL;
					TEarliestReady=NULL;
				}

				if(EarliestJob==NULL 
				|| (*TtReady<*TEarliestReady 
				&& Tt!=NULL 
				&& TEarliest !=NULL
				&& *Tt <=*TEarliest)

				|| (*TtReady<*TEarliestReady 
				&& Tt==NULL 
				&& TEarliest ==NULL)

				|| (TEarliest!=NULL
				&&*TtReady<*TEarliest
				&& Tt==NULL)) {
					EarliestJob=t->GetJobA();
				}
			}
		}
		vector<TreeNode*> ::iterator it;
		for (it = this->children.begin(); it!= this->children.end(); ++it) {
			if((*it)->VisitedAtIteration!=iteration) {
				EarliestJob=(*it)->FindTheEarliestReadyJob(RootTreeNode,EarliestJob,iteration);

			}
		}

		return EarliestJob;
	}

	Job* TreeNode::FindTheEarliestReadyJobButNotOriginatedFrom(TreeNode* RootTreeNode,string OriginalIDOfthePreviousJobID,Job* JobIn,int iteration) {

		Job* EarliestJob=JobIn;
		VisitedAtIteration=iteration;


		if(t->GetJobA()->IsReady() && !t->GetJobA()->IsScheduled()) {

			if(t->GetJobA()->GetOriginalName()!=OriginalIDOfthePreviousJobID 
			&&(EarliestJob==NULL 
			|| (*GetReadyTime(RootTreeNode,t->GetJobA())<=*GetReadyTime(RootTreeNode,EarliestJob) 
			&& DetermineTheEarliestNonAllocatedTimeForExecutingCores(RootTreeNode,t->GetJobA())!=NULL 
			&& DetermineTheEarliestNonAllocatedTimeForExecutingCores(RootTreeNode,EarliestJob) !=NULL
			&& *DetermineTheEarliestNonAllocatedTimeForExecutingCores(RootTreeNode,t->GetJobA()) <=*DetermineTheEarliestNonAllocatedTimeForExecutingCores(RootTreeNode,EarliestJob))

			|| (*GetReadyTime(RootTreeNode,t->GetJobA())<=*GetReadyTime(RootTreeNode,EarliestJob) 
			&& DetermineTheEarliestNonAllocatedTimeForExecutingCores(RootTreeNode,t->GetJobA())==NULL 
			&& DetermineTheEarliestNonAllocatedTimeForExecutingCores(RootTreeNode,EarliestJob) ==NULL)

			|| (DetermineTheEarliestNonAllocatedTimeForExecutingCores(RootTreeNode,EarliestJob)!=NULL
			&&*GetReadyTime(RootTreeNode,t->GetJobA())<=*DetermineTheEarliestNonAllocatedTimeForExecutingCores(RootTreeNode,EarliestJob)
			&& DetermineTheEarliestNonAllocatedTimeForExecutingCores(RootTreeNode,t->GetJobA())==NULL))) {
				EarliestJob=t->GetJobA();
			}
		}

		vector<TreeNode*> ::iterator it;
		for (it = children.begin(); it!= children.end(); ++it) {
			if((*it)->VisitedAtIteration!=iteration) {
				EarliestJob=(*it)->FindTheEarliestReadyJobButNotOriginatedFrom(RootTreeNode,OriginalIDOfthePreviousJobID,EarliestJob,iteration);
			}
		}

		return EarliestJob;
	}


	Job* TreeNode::FindTheEarliestReadyJobButNotOriginatedFromForCore(TreeNode* RootTreeNode,string OriginalIDOfthePreviousJobID,Job* JobIn,IAResource* CoreIn,int iteration) {

		Job* EarliestJob=JobIn;
		VisitedAtIteration=iteration;

		if(t->GetJobA()->IsReady() && !t->GetJobA()->IsScheduled() && t->GetJobA()->CheckIfExecutedByCore(CoreIn)) {

			if(t->GetJobA()->GetOriginalName()!=OriginalIDOfthePreviousJobID 
			&&(EarliestJob==NULL 
			|| (*GetReadyTime(RootTreeNode,t->GetJobA())<=*GetReadyTime(RootTreeNode,EarliestJob) 
			&& DetermineTheEarliestNonAllocatedTimeForExecutingCores(RootTreeNode,t->GetJobA())!=NULL 
			&& DetermineTheEarliestNonAllocatedTimeForExecutingCores(RootTreeNode,EarliestJob) !=NULL
			&& *DetermineTheEarliestNonAllocatedTimeForExecutingCores(RootTreeNode,t->GetJobA()) <=*DetermineTheEarliestNonAllocatedTimeForExecutingCores(RootTreeNode,EarliestJob))

			|| (*GetReadyTime(RootTreeNode,t->GetJobA())<=*GetReadyTime(RootTreeNode,EarliestJob) 
			&& DetermineTheEarliestNonAllocatedTimeForExecutingCores(RootTreeNode,t->GetJobA())==NULL 
			&& DetermineTheEarliestNonAllocatedTimeForExecutingCores(RootTreeNode,EarliestJob) ==NULL)

			|| (DetermineTheEarliestNonAllocatedTimeForExecutingCores(RootTreeNode,EarliestJob)!=NULL
			&&*GetReadyTime(RootTreeNode,t->GetJobA())<=*DetermineTheEarliestNonAllocatedTimeForExecutingCores(RootTreeNode,EarliestJob)
			&& DetermineTheEarliestNonAllocatedTimeForExecutingCores(RootTreeNode,t->GetJobA())==NULL))) {
				EarliestJob=t->GetJobA();
			}
		}

		vector<TreeNode*> ::iterator it;
		for (it = children.begin(); it!= children.end(); ++it) {
			if((*it)->VisitedAtIteration!=iteration) {
				EarliestJob=(*it)->FindTheEarliestReadyJobButNotOriginatedFromForCore(RootTreeNode,OriginalIDOfthePreviousJobID,EarliestJob,CoreIn,iteration);
			}
		}

		return EarliestJob;
	}

	TreeNode* TreeNode::FindNodeWithJob(Job* JobIn) {
		
		if(mapJob_TreeNode.find(JobIn)!=mapJob_TreeNode.end()) {
			return mapJob_TreeNode[JobIn];
		}
		else return NULL;
	}


	TreeNode* TreeNode::FindNodeWithJobFromRoot(TreeNode* RootTreeNode,Job* JobIn) {
		return RootTreeNode->FindNodeWithJob(JobIn);
	}

   Time* TreeNode::FindTheLatestEndTimeOfChildren() {
		vector<TreeNode*> ::iterator it;
		
		Time* result=NULL;

		for (it = this->children.begin(); it!= this->children.end(); ++it) {
			if((*it)->t->GetJobA()->IsScheduled()==false) {
				return NULL;
			}
			else if(result==NULL || *(*it)->t->GetJobA()->GetEndTime()>*result) {
				result=(*it)->t->GetJobA()->GetEndTime();
			}

		}
		return result;
   }


   Time* TreeNode::DetermineTheLatestEndTimeOfChildren(TreeNode* RootTreeNode,Job* JobIn) {
	   TreeNode* tn=FindNodeWithJobFromRoot(RootTreeNode,JobIn);
	   return tn->FindTheLatestEndTimeOfChildren();
   }


	Time* TreeNode::FindTheEarliestNonAllocatedTime(IAResource* CoreIn) {
		Time *Result;
		if(mapCoreTime.find(CoreIn)!=mapCoreTime.end()) {
			Result=mapCoreTime.at(CoreIn);
			}
		else {
			Result = NULL;
		}
		return Result;

	}

  Time* TreeNode::GetReadyTime(TreeNode* RootTreeNode,Job* JobIn) {
	  Time *result;
	  Time *TheLatestEndTimeOfChildren=GetTheLatestEndTimeOfChildren(RootTreeNode,JobIn);
			if(TheLatestEndTimeOfChildren!=NULL && *JobIn->GetReleaseTime()<*TheLatestEndTimeOfChildren) {
				result=TheLatestEndTimeOfChildren; 
			}
			else {
				result=JobIn->GetReleaseTime();
			}

			if(DetermineTheEarliestNonAllocatedTimeForExecutingCores(JobIn)!=NULL
			&& *DetermineTheEarliestNonAllocatedTimeForExecutingCores(JobIn)>*result) {
				result=DetermineTheEarliestNonAllocatedTimeForExecutingCores(JobIn);
			}


			return result;
	}

	void TreeNode::CopyChildrenFrom(TreeNode* NewChildTreeNode) {
		children.insert(children.end(),NewChildTreeNode->children.begin(),NewChildTreeNode->children.end());
	}

	void TreeNode::ClearChildren() {
		children.clear();
	}

	
	Time* TreeNode::DetermineTheEarliestNonAllocatedTimeForExecutingCores(Job* JobIn) {
		Time* result=NULL;
		list<IAResource*>* ExecutingCores=JobIn->GetExecutingCores();
		if(ExecutingCores->size()==0) {
			return NULL;
		}
		list<IAResource*>::iterator it;
		for(it=ExecutingCores->begin(),++it;it!=ExecutingCores->end();++it) {
			if(mapCoreTime.find(*it)!=mapCoreTime.end()) {
				if(result==NULL || *result < *mapCoreTime.at(*it)) {
					result=mapCoreTime.at(*it);
				}
			}
		}
		return result;
	}

	Time* TreeNode::DetermineTheEarliestNonAllocatedTimeForExecutingCores(TreeNode* RootTreeNode,Job* JobIn) {
		if(JobIn->GetExecutingCores()->size()<=1) {
			return RootTreeNode->DetermineTheEarliestNonAllocatedTimeForCore(RootTreeNode,JobIn->GetTheFirstExecutingCore());
		}
		else {
			list<IAResource*>* ExecutingCores=JobIn->GetExecutingCores();
			Time *result=RootTreeNode->DetermineTheEarliestNonAllocatedTimeForCore(RootTreeNode,*ExecutingCores->begin());
			list<IAResource*>::iterator it;
			for(it=ExecutingCores->begin(),++it;it!=ExecutingCores->end();++it) {
				Time* TheEarliestNonAllocatedTimeForCore=DetermineTheEarliestNonAllocatedTimeForCore(RootTreeNode,*it);
				if((result==NULL && TheEarliestNonAllocatedTimeForCore!=NULL) || (result !=NULL && TheEarliestNonAllocatedTimeForCore!=NULL && *result < *TheEarliestNonAllocatedTimeForCore)) {
					result=TheEarliestNonAllocatedTimeForCore;
				}
			}
			return result;
		}


	}


	Time* TreeNode::DetermineTheEarliestNonAllocatedTimeForCore(TreeNode* RootTreeNode,IAResource *CoreIn) {
		return FindTheEarliestNonAllocatedTime(CoreIn);
	}




}
