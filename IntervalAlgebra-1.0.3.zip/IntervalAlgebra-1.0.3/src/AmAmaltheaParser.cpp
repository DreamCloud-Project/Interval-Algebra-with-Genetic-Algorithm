
#include <string>
#include <iostream>
#include <sstream>
#include <stdexcept>
#include <list>

#include <sys/types.h>
#include <sys/stat.h>
#include <errno.h>




#include "AmAmaltheaParser.h"




using namespace xercesc;
using namespace IntervalAlgebra;
using namespace std;




/**
 *  Constructor initializes xerces-C libraries.
 *  The XML tags and attributes which we seek are defined.
 *  The xerces-C DOM parser infrastructure is initialized.
 */

AmaltheaParser::AmaltheaParser()
{
   try
   {
      XMLPlatformUtils::Initialize();  // Initialize Xerces infrastructure
   }
   catch( XMLException& e )
   {
      char* message = XMLString::transcode( e.getMessage() );
      cerr << "XML toolkit initialization error: " << message << endl;
      XMLString::release( &message );
      // throw exception here to return ERROR_XERCES_INIT
   }

   // Tags and attributes used in XML file.
   // Can't call transcode till after Xerces Initialize()
   TAG_root        = XMLString::transcode("sw:SWModel");


	TAG_labels= XMLString::transcode("labels");
	TAG_runnables= XMLString::transcode("runnables");
	TAG_remoteAccesses= XMLString::transcode("remoteAccesses");
	TAG_deviation= XMLString::transcode("deviation");
	TAG_lowerBound= XMLString::transcode("lowerBound");
	TAG_upperBound= XMLString::transcode("upperBound");
	TAG_distribution= XMLString::transcode("distribution");
	TAG_mean= XMLString::transcode("mean");
	TAG_size= XMLString::transcode("size");
	TAG_sd=  XMLString::transcode("sd");
	TAG_tasks=  XMLString::transcode("tasks");
	TAG_deadline=  XMLString::transcode("deadline");
	TAG_callGraph=  XMLString::transcode("callGraph");
	TAG_graphEntries=  XMLString::transcode("graphEntries");
	TAG_calls=  XMLString::transcode("calls");
	TAG_swModel=  XMLString::transcode("swModel");
	TAG_runnableItems=  XMLString::transcode("runnableItems");
	TAG_stimuliModel=  XMLString::transcode("stimuliModel");
	TAG_stimuli_stimuliModel=  XMLString::transcode("stimuli:StimuliModel");


	TAG_stimuli=  XMLString::transcode("stimuli");
	TAG_offset=  XMLString::transcode("offset");
	TAG_recurrence=  XMLString::transcode("recurrence");
	TAG_hwModel=  XMLString::transcode("hwModel");
	TAG_coreTypes=  XMLString::transcode("coreTypes");
	TAG_system=  XMLString::transcode("system");
	TAG_ecus=  XMLString::transcode("ecus");
	TAG_quartzes=  XMLString::transcode("quartzes");
	TAG_microcontrollers=  XMLString::transcode("microcontrollers");
	TAG_cores=  XMLString::transcode("cores");
	TAG_prescaler=  XMLString::transcode("prescaler");
	TAG_hw_hwModel=  XMLString::transcode("hw:HWModel"); 
	TAG_sw_swModel=  XMLString::transcode("sw:SWModel");
	TAG_items=  XMLString::transcode("items"); 
	TAG_runnableItem=  XMLString::transcode("runnableItem"); 
	TAG_stimulus=  XMLString::transcode("stimulus"); 



	ATTR_name= XMLString::transcode("name");
	ATTR_xsi_type= XMLString::transcode("xsi:type");
	ATTR_data= XMLString::transcode("data");
	ATTR_value= XMLString::transcode("value");
	ATTR_pRemainPromille= XMLString::transcode("pRemainPromille");
	ATTR_tags= XMLString::transcode("tags");
	ATTR_numberBits= XMLString::transcode("numberBits");
	ATTR_access= XMLString::transcode("access");
	ATTR_priority= XMLString::transcode("priority");
	ATTR_multipleTaskActivationLimit= XMLString::transcode("multipleTaskActivationLimit");
	ATTR_unit= XMLString::transcode("unit");
	ATTR_runnable= XMLString::transcode("runnable");
	ATTR_preemption=XMLString::transcode("preemption");
	ATTR_xmi_id=XMLString::transcode("xmi:id");
	ATTR_stimuli=XMLString::transcode("stimuli");

	ATTR_instructionsPerCycle=XMLString::transcode("instructionsPerCycle");
	ATTR_frequency=XMLString::transcode("frequency");
	ATTR_coreType=XMLString::transcode("coreType");
	ATTR_quartz=XMLString::transcode("quartz");
	ATTR_stimulus=XMLString::transcode("stimulus");
	ATTR_href=XMLString::transcode("href");


	m_Parser = new XercesDOMParser;
}

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


/**
 *  Class destructor frees memory used to hold the XML tag and 
 *  attribute definitions. It als terminates use of the xerces-C
 *  framework.
 */

AmaltheaParser::~AmaltheaParser()
{
	// Free memory

	delete m_Parser;

	try
	{
		XMLString::release( &TAG_labels );
		XMLString::release( &TAG_runnables );
		XMLString::release( &TAG_remoteAccesses );
		XMLString::release( &TAG_deviation );
		XMLString::release( &TAG_lowerBound );
		XMLString::release( &TAG_upperBound );
		XMLString::release( &TAG_distribution );
		XMLString::release( &TAG_mean );
		XMLString::release( &TAG_sd );
		XMLString::release( &TAG_runnableItems );
		XMLString::release( &TAG_size );
		XMLString::release( &TAG_stimuliModel );
		XMLString::release( &TAG_stimuli );
		XMLString::release( &TAG_offset );
		XMLString::release( &TAG_recurrence );
		XMLString::release( &TAG_tasks );
		XMLString::release( &TAG_deadline );
		XMLString::release( &TAG_callGraph );
		XMLString::release( &TAG_graphEntries );
		XMLString::release( &TAG_calls );
		XMLString::release( &TAG_hwModel );
		XMLString::release( &TAG_swModel );
		XMLString::release( &TAG_coreTypes );
		XMLString::release( &TAG_system );
		XMLString::release( &TAG_ecus );
		XMLString::release( &TAG_quartzes );
		XMLString::release( &TAG_microcontrollers );
		XMLString::release( &TAG_cores );
		XMLString::release( &TAG_prescaler );
		XMLString::release( &TAG_hw_hwModel );
		XMLString::release( &TAG_sw_swModel );
		XMLString::release( &TAG_stimuli_stimuliModel );
		XMLString::release( &TAG_items );
		XMLString::release( &TAG_runnableItem );
		XMLString::release( &TAG_stimulus );


		XMLString::release( &ATTR_name );
		XMLString::release( &ATTR_xsi_type );
		XMLString::release( &ATTR_data );
		XMLString::release( &ATTR_value );
		XMLString::release( &ATTR_pRemainPromille );
		XMLString::release( &ATTR_tags );
		XMLString::release( &ATTR_numberBits );
		XMLString::release( &ATTR_access );
		XMLString::release( &ATTR_priority );
		XMLString::release( &ATTR_multipleTaskActivationLimit );
		XMLString::release( &ATTR_unit );
		XMLString::release( &ATTR_runnable );
		XMLString::release( &ATTR_preemption );
		XMLString::release( &ATTR_xmi_id );
		XMLString::release( &ATTR_stimuli );
		XMLString::release( &ATTR_instructionsPerCycle );
		XMLString::release( &ATTR_frequency );
		XMLString::release( &ATTR_coreType );
		XMLString::release( &ATTR_quartz );
		XMLString::release( &ATTR_stimulus );
		XMLString::release( &ATTR_href );


	}
	catch( ... )
	{
		cerr << "Unknown exception encountered in TagNamesdtor" << endl;
	}

	// Terminate Xerces

	try
	{
		XMLPlatformUtils::Terminate();  // Terminate after release of memory
	}
	catch( xercesc::XMLException& e )
	{
		char* message = xercesc::XMLString::transcode( e.getMessage() );
		cerr << "XML ttolkit teardown error: " << message << endl;
		XMLString::release( &message );
	}
}

string AmaltheaParser::GetAttributeAsString(DOMElement* MyElement,XMLCh* MyAttr) {
	const XMLCh* xmlch_string = MyElement->getAttribute(MyAttr);
	return XMLString::transcode(xmlch_string);
}

DOMNodeList* AmaltheaParser::GetElementWithTagswModel(DOMNode* root) {

	DOMNodeList* result=NULL;
		if( root->getNodeType() &&  // true is not NULL
			root->getNodeType() == DOMNode::ELEMENT_NODE ) // is element 
		{
			DOMElement* currentElement = dynamic_cast< xercesc::DOMElement* >( root );
			if( XMLString::equals(currentElement->getTagName(), TAG_sw_swModel) || XMLString::equals(currentElement->getTagName(), TAG_swModel) ) { 
				result = currentElement->getChildNodes();
				return result;
			}
		}


	DOMNodeList* children=root->getChildNodes();
	unsigned int nodeCount = children->getLength();


	for( XMLSize_t xx = 0; xx < nodeCount; ++xx )
	{
		DOMNode* currentNode = children->item(xx);
		if( currentNode->getNodeType() &&  // true is not NULL
			currentNode->getNodeType() == DOMNode::ELEMENT_NODE ) // is element 
		{
			// Found node which is an Element. Re-cast node as element
			DOMElement* currentElement = dynamic_cast< xercesc::DOMElement* >( currentNode );
			if( XMLString::equals(currentElement->getTagName(), TAG_sw_swModel) || XMLString::equals(currentElement->getTagName(), TAG_swModel) ) { 
				result = currentElement->getChildNodes();
				return result;
			}


		}
	}
	return result;

}

DOMNodeList* AmaltheaParser::GetElementWithTaghwModel(DOMNode* root) {

	DOMNodeList* result=NULL;
		if( root->getNodeType() &&  // true is not NULL
			root->getNodeType() == DOMNode::ELEMENT_NODE ) // is element 
		{
			DOMElement* currentElement = dynamic_cast< xercesc::DOMElement* >( root );
			if( XMLString::equals(currentElement->getTagName(), TAG_hw_hwModel) || XMLString::equals(currentElement->getTagName(), TAG_hwModel)) { 
				result = currentElement->getChildNodes();
				return result;
			}
		}


	DOMNodeList* children=root->getChildNodes();
	unsigned int nodeCount = children->getLength();



	for( XMLSize_t xx = 0; xx < nodeCount; ++xx )
	{
		DOMNode* currentNode = children->item(xx);
		if( currentNode->getNodeType() &&  // true is not NULL
			currentNode->getNodeType() == DOMNode::ELEMENT_NODE ) // is element 
		{
			// Found node which is an Element. Re-cast node as element
			DOMElement* currentElement = dynamic_cast< xercesc::DOMElement* >( currentNode );
			if( XMLString::equals(currentElement->getTagName(), TAG_hw_hwModel) || XMLString::equals(currentElement->getTagName(), TAG_hwModel)) { 
				result = currentElement->getChildNodes();
				return result;
			}


		}
	}
	return result;
}



DOMNodeList* AmaltheaParser::GetElementWithTagStimuliModel(DOMNode* root) {

	DOMNodeList* result=NULL;
		if( root->getNodeType() &&  // true is not NULL
			root->getNodeType() == DOMNode::ELEMENT_NODE ) // is element 
		{
			DOMElement* currentElement = dynamic_cast< xercesc::DOMElement* >( root );
			if( XMLString::equals(currentElement->getTagName(), TAG_stimuli_stimuliModel) || XMLString::equals(currentElement->getTagName(), TAG_stimuliModel)) { 
				result = currentElement->getChildNodes();
				return result;
			}
		}


	DOMNodeList* children=root->getChildNodes();
	unsigned int nodeCount = children->getLength();



	for( XMLSize_t xx = 0; xx < nodeCount; ++xx )
	{
		DOMNode* currentNode = children->item(xx);
		if( currentNode->getNodeType() &&  // true is not NULL
			currentNode->getNodeType() == DOMNode::ELEMENT_NODE ) // is element 
		{
			// Found node which is an Element. Re-cast node as element
			DOMElement* currentElement = dynamic_cast< xercesc::DOMElement* >( currentNode );
			if( XMLString::equals(currentElement->getTagName(), TAG_stimuli_stimuliModel) || XMLString::equals(currentElement->getTagName(), TAG_stimuliModel)) { 
				result = currentElement->getChildNodes();
				return result;
			}


		}
	}
	return result;
}



int AmaltheaParser::ParseAmaltheaFileHWModelForCoresNo(DOMNodeList* const children , AmaltheaSystem* MyAmaltheaSystem) {

	if (children==NULL) {
		return -1; // no hw model
	}

	int result=0;
	unsigned int nodeCount = children->getLength();


	for( XMLSize_t xx = 0; xx < nodeCount; ++xx )
	{
		DOMNode* currentNode = children->item(xx);
		if( currentNode->getNodeType() &&  // true is not NULL
			currentNode->getNodeType() == DOMNode::ELEMENT_NODE ) // is element 
		{
			// Found node which is an Element. Re-cast node as element
			DOMElement* currentElement = dynamic_cast< xercesc::DOMElement* >( currentNode );

			if( XMLString::equals(currentElement->getTagName(), TAG_system))
			{
				DOMNodeList* childrenLev2 = currentElement->getChildNodes();
				const  XMLSize_t nodeCountLev2 = childrenLev2->getLength();
				for( XMLSize_t xxLev2 = 0; xxLev2 < nodeCountLev2; ++xxLev2 )
				{
					DOMNode* currentNodeLev2 = childrenLev2->item(xxLev2);
					if( currentNodeLev2->getNodeType() &&  // true is not NULL
						currentNodeLev2->getNodeType() == DOMNode::ELEMENT_NODE ) // is element 
					{
						DOMElement* currentElementLev2 = dynamic_cast< xercesc::DOMElement* >( currentNodeLev2 );
						if( XMLString::equals(currentElementLev2->getTagName(), TAG_ecus))
						{
							const XMLCh* xmlch_stringLev2 = currentElementLev2->getAttribute(ATTR_name);
							string strSize = XMLString::transcode(xmlch_stringLev2);


							DOMNodeList* childrenLev3 = currentElementLev2->getChildNodes();
							const  XMLSize_t nodeCountLev3 = childrenLev3->getLength();
							for( XMLSize_t xxLev3 = 0; xxLev3 < nodeCountLev3; ++xxLev3 )
							{
								DOMNode* currentNodeLev3 = childrenLev3->item(xxLev3);
								if( currentNodeLev3->getNodeType() &&  // true is not NULL
									currentNodeLev3->getNodeType() == DOMNode::ELEMENT_NODE ) // is element 
								{
									DOMElement* currentElementLev3 = dynamic_cast< xercesc::DOMElement* >( currentNodeLev3 );
									if( XMLString::equals(currentElementLev3->getTagName(), TAG_microcontrollers))
									{
										const XMLCh* xmlch_Name = currentElementLev3->getAttribute(ATTR_name);
										string strName = XMLString::transcode(xmlch_Name);




											DOMNodeList* childrenLev4 = currentElementLev3->getChildNodes();
											const  XMLSize_t nodeCountLev4 = childrenLev4->getLength();
											for( XMLSize_t xxLev4 = 0; xxLev4 < nodeCountLev4; ++xxLev4 )
											{
												DOMNode* currentNodeLev4 = childrenLev4->item(xxLev4);
												if( currentNodeLev4->getNodeType() &&  // true is not NULL
													currentNodeLev4->getNodeType() == DOMNode::ELEMENT_NODE ) // is element 
												{
													DOMElement* currentElementLev4 = dynamic_cast< xercesc::DOMElement* >( currentNodeLev4 );
														
													if( XMLString::equals(currentElementLev4->getTagName(), TAG_cores))
													{
														result++;
													}
												}
											}
										}
									}
								}
						}
					}
				}
			}
		}
	}
	return result;

}


int	AmaltheaParser::ParseAmaltheaFileRunnableForNo(DOMNodeList* const children , AmaltheaSystem* MyAmaltheaSystem) {
	int result=0;
	unsigned int nodeCount = children->getLength();

	for( XMLSize_t xx = 0; xx < nodeCount; ++xx )
	{
		DOMNode* currentNode = children->item(xx);
		if( currentNode->getNodeType() &&  // true is not NULL
			currentNode->getNodeType() == DOMNode::ELEMENT_NODE ) // is element 
		{
			// Found node which is an Element. Re-cast node as element
			DOMElement* currentElement = dynamic_cast< xercesc::DOMElement* >( currentNode );


			if( XMLString::equals(currentElement->getTagName(), TAG_runnables))
			{
				result++;
			}
		}
	}
	return result;
}


void AmaltheaParser::ParseAmaltheaFileHWModel(DOMNodeList* const children , AmaltheaSystem* MyAmaltheaSystem) {

		if (children==NULL) {
			return; // no hw model
		}

		unsigned int nodeCount = children->getLength();


		for( XMLSize_t xx = 0; xx < nodeCount; ++xx )
		{
			DOMNode* currentNode = children->item(xx);
			if( currentNode->getNodeType() &&  // true is not NULL
				currentNode->getNodeType() == DOMNode::ELEMENT_NODE ) // is element 
			{
				// Found node which is an Element. Re-cast node as element
				DOMElement* currentElement = dynamic_cast< xercesc::DOMElement* >( currentNode );

				if( XMLString::equals(currentElement->getTagName(), TAG_coreTypes))
				{
					CoreType* MyCoreType=new CoreType(GetAttributeAsString(currentElement,ATTR_name));
					MyCoreType->SetID(GetAttributeAsString(currentElement,ATTR_xmi_id));
					MyCoreType->SetInstructionsPerCycle(atoi(GetAttributeAsString(currentElement,ATTR_instructionsPerCycle).c_str()));
					MyAmaltheaSystem->AddCoreType(MyCoreType,MyCoreType->GetID());
				}
				else if( XMLString::equals(currentElement->getTagName(), TAG_system))
				{
					DOMNodeList* childrenLev2 = currentElement->getChildNodes();
					const  XMLSize_t nodeCountLev2 = childrenLev2->getLength();
					for( XMLSize_t xxLev2 = 0; xxLev2 < nodeCountLev2; ++xxLev2 )
					{
						DOMNode* currentNodeLev2 = childrenLev2->item(xxLev2);
						if( currentNodeLev2->getNodeType() &&  // true is not NULL
							currentNodeLev2->getNodeType() == DOMNode::ELEMENT_NODE ) // is element 
						{
							DOMElement* currentElementLev2 = dynamic_cast< xercesc::DOMElement* >( currentNodeLev2 );
							if( XMLString::equals(currentElementLev2->getTagName(), TAG_ecus))
							{
								const XMLCh* xmlch_stringLev2 = currentElementLev2->getAttribute(ATTR_name);
								string strSize = XMLString::transcode(xmlch_stringLev2);


								DOMNodeList* childrenLev3 = currentElementLev2->getChildNodes();
								const  XMLSize_t nodeCountLev3 = childrenLev3->getLength();
								for( XMLSize_t xxLev3 = 0; xxLev3 < nodeCountLev3; ++xxLev3 )
								{
									DOMNode* currentNodeLev3 = childrenLev3->item(xxLev3);
									if( currentNodeLev3->getNodeType() &&  // true is not NULL
										currentNodeLev3->getNodeType() == DOMNode::ELEMENT_NODE ) // is element 
									{
										DOMElement* currentElementLev3 = dynamic_cast< xercesc::DOMElement* >( currentNodeLev3 );
										if( XMLString::equals(currentElementLev3->getTagName(), TAG_quartzes))
										{
											Quartz* MyQuartz=new Quartz(GetAttributeAsString(currentElementLev3,ATTR_name));
											MyQuartz->SetID(GetAttributeAsString(currentElementLev3,ATTR_xmi_id));
											MyQuartz->SetFrequency(atoi(GetAttributeAsString(currentElementLev3,ATTR_frequency).c_str()));
											MyAmaltheaSystem->AddQuartz(MyQuartz,MyQuartz->GetID());

										}
										else if( XMLString::equals(currentElementLev3->getTagName(), TAG_microcontrollers))
										{
											const XMLCh* xmlch_Name = currentElementLev3->getAttribute(ATTR_name);
											string strName = XMLString::transcode(xmlch_Name);




												DOMNodeList* childrenLev4 = currentElementLev3->getChildNodes();
												const  XMLSize_t nodeCountLev4 = childrenLev4->getLength();
												for( XMLSize_t xxLev4 = 0; xxLev4 < nodeCountLev4; ++xxLev4 )
												{
													DOMNode* currentNodeLev4 = childrenLev4->item(xxLev4);
													if( currentNodeLev4->getNodeType() &&  // true is not NULL
														currentNodeLev4->getNodeType() == DOMNode::ELEMENT_NODE ) // is element 
													{
														DOMElement* currentElementLev4 = dynamic_cast< xercesc::DOMElement* >( currentNodeLev4 );
														
														if( XMLString::equals(currentElementLev4->getTagName(), TAG_cores))
														{
															AmCore* MyCore = new AmCore(GetAttributeAsString(currentElementLev4,ATTR_name));
															MyCore->SetCoreType(MyAmaltheaSystem->GetCoreType(GetAttributeAsString(currentElementLev4,ATTR_coreType)));


															DOMNodeList* childrenLev5 = currentElementLev4->getChildNodes();
															const  XMLSize_t nodeCountLev5 = childrenLev5->getLength();
															for( XMLSize_t xxLev5 = 0; xxLev5 < nodeCountLev5; ++xxLev5 )
															{
																DOMNode* currentNodeLev5 = childrenLev5->item(xxLev5);
																if( currentNodeLev5->getNodeType() &&  // true is not NULL
																	currentNodeLev5->getNodeType() == DOMNode::ELEMENT_NODE ) // is element 
																{
																	DOMElement* currentElementLev5 = dynamic_cast< xercesc::DOMElement* >( currentNodeLev5 );
																	if( XMLString::equals(currentElementLev5->getTagName(), TAG_prescaler))
																	{
																		MyCore->SetName(GetAttributeAsString(currentElementLev5,ATTR_name));
																		MyCore->SetID(GetAttributeAsString(currentElementLev5,ATTR_xmi_id));
																		MyCore->SetQuartz(MyAmaltheaSystem->GetQuartz(GetAttributeAsString(currentElementLev5,ATTR_quartz)));

																	}
																}
															}

															MyAmaltheaSystem->AddAmCore(MyCore,MyCore->GetID());


														}
													}
												}
											}
										}
									}
							}
						}
					}
				}
			}
		}
}

void AmaltheaParser::ParseAmaltheaFileStimuli(DOMNodeList* const currentElement , AmaltheaSystem* MyAmaltheaSystem) {




					const  XMLSize_t nodeCountLev2 = currentElement->getLength();
					for( XMLSize_t xxLev2 = 0; xxLev2 < nodeCountLev2; ++xxLev2 )
					{
						DOMNode* currentNodeLev2 = currentElement->item(xxLev2);
						if( currentNodeLev2->getNodeType() &&  // true is not NULL
							currentNodeLev2->getNodeType() == DOMNode::ELEMENT_NODE ) // is element 
						{
							DOMElement* currentElementLev2 = dynamic_cast< xercesc::DOMElement* >( currentNodeLev2 );
							if( XMLString::equals(currentElementLev2->getTagName(), TAG_stimuli))
							{
								Stimulus* MyStimulus=new Stimulus(GetAttributeAsString(currentElementLev2,ATTR_name));
								MyStimulus->SetID(GetAttributeAsString(currentElementLev2,ATTR_xmi_id));


								DOMNodeList* childrenLev3 = currentElementLev2->getChildNodes();
								const  XMLSize_t nodeCountLev3 = childrenLev3->getLength();
								for( XMLSize_t xxLev3 = 0; xxLev3 < nodeCountLev3; ++xxLev3 )
								{
									DOMNode* currentNodeLev3 = childrenLev3->item(xxLev3);
									if( currentNodeLev3->getNodeType() &&  // true is not NULL
										currentNodeLev3->getNodeType() == DOMNode::ELEMENT_NODE ) // is element 
									{
										DOMElement* currentElementLev3 = dynamic_cast< xercesc::DOMElement* >( currentNodeLev3 );
										if( XMLString::equals(currentElementLev3->getTagName(), TAG_offset))
										{
											string strValue = GetAttributeAsString(currentElementLev3,ATTR_value);
											string strUnit = GetAttributeAsString(currentElementLev3,ATTR_unit);
											if(strValue=="") {
												strValue="0";
											}
											if(strUnit=="") {
												strUnit="ms";
											}

											MyStimulus->SetOffset(pair<int,string>(atoi(strValue.c_str()),strUnit));
										}
										else if( XMLString::equals(currentElementLev3->getTagName(), TAG_recurrence))
										{
											string strValue = GetAttributeAsString(currentElementLev3,ATTR_value);
											string strUnit = GetAttributeAsString(currentElementLev3,ATTR_unit);
											if(strValue=="") {
												strValue="0";
											}
											if(strUnit=="") {
												strUnit="ms";
											}
											MyStimulus->SetRecurrence(pair<int,string>(atoi(strValue.c_str()),strUnit));
										}
									}
								}

								if(MyStimulus->GetID()!="") {
								MyAmaltheaSystem->AddStimulus(MyStimulus,MyStimulus->GetID());
								}
								else {
								MyAmaltheaSystem->AddStimulus(MyStimulus);

								}
							}
						}
					}

}

void AmaltheaParser::FillRemoteAccessInstruction(DOMElement* currentElementLev2,RemoteAccessInstruction *MyRemoteAccessInstruction,AmaltheaSystem *MyAmaltheaSystem,Runnable *MyRunnable) {
	Label* MyLabel=MyAmaltheaSystem->GetLabel(GetAttributeAsString(currentElementLev2,ATTR_data));
	MyRemoteAccessInstruction->SetLabel(MyLabel);
	
	string strAccess = GetAttributeAsString(currentElementLev2,ATTR_access);
	if(strAccess=="write") {
		MyRemoteAccessInstruction->SetWrite(true);
		MyAmaltheaSystem->AddLabelsSource(MyLabel,MyRunnable);

	}
	else {
		MyRemoteAccessInstruction->SetWrite(false);
		MyAmaltheaSystem->AddLabelsDest(MyLabel,MyRunnable);
	}
}

void AmaltheaParser::FillExecutionCyclesConstantInstruction(DOMElement* currentElementLev2,ExecutionCyclesConstantInstruction *MyExecutionCyclesConstantInstruction) {
	MyExecutionCyclesConstantInstruction->SetValue(atoi(GetAttributeAsString(currentElementLev2,ATTR_value).c_str()));
}

void AmaltheaParser::AnalyseGroup(DOMElement* currentElementLev2,AmaltheaSystem *MyAmaltheaSystem,Runnable *MyRunnable){
	DOMNodeList* childrenLev3 = currentElementLev2->getChildNodes();
	const  XMLSize_t nodeCountLev3 = childrenLev3->getLength();
	for( XMLSize_t xxLev3 = 0; xxLev3 < nodeCountLev3; ++xxLev3 )
	{
		DOMNode* currentNodeLev3 = childrenLev3->item(xxLev3);
		if( currentNodeLev3->getNodeType() &&  // true is not NULL
			currentNodeLev3->getNodeType() == DOMNode::ELEMENT_NODE ) // is element 
		{
			DOMElement* currentElementLev3 = dynamic_cast< xercesc::DOMElement* >( currentNodeLev3 );
			if( XMLString::equals(currentElementLev3->getTagName(), TAG_items))
			{

				DOMNodeList* childrenLev4 = currentElementLev3->getChildNodes();
				const  XMLSize_t nodeCountLev4 = childrenLev4->getLength();
				for( XMLSize_t xxLev4 = 0; xxLev4 < nodeCountLev4; ++xxLev4 )
				{
					DOMNode* currentNodeLev4 = childrenLev4->item(xxLev4);
					if( currentNodeLev4->getNodeType() &&  // true is not NULL
						currentNodeLev4->getNodeType() == DOMNode::ELEMENT_NODE ) // is element 
					{
						DOMElement* currentElementLev4 = dynamic_cast< xercesc::DOMElement* >( currentNodeLev4 );
						if( XMLString::equals(currentElementLev4->getTagName(), TAG_runnableItem))
						{
								string strInstructionType = GetAttributeAsString(currentElementLev4,ATTR_xsi_type);

								if(strInstructionType=="sw:LabelAccess") {
									RemoteAccessInstruction* MyRemoteAccessInstruction= new RemoteAccessInstruction(strInstructionType);
									FillRemoteAccessInstruction(currentElementLev4,MyRemoteAccessInstruction,MyAmaltheaSystem,MyRunnable);
									MyRunnable->AddInstruction(MyRemoteAccessInstruction);
								}
								else if(strInstructionType=="sw:InstructionsDeviation") {
									ExecutionCyclesDeviationInstruction* MyExecutionCyclesDeviationInstruction = new ExecutionCyclesDeviationInstruction(strInstructionType);
									FillExecutionCyclesDeviationInstruction(currentElementLev4, MyExecutionCyclesDeviationInstruction);
									MyRunnable->AddInstruction(MyExecutionCyclesDeviationInstruction);

								}
								else if(strInstructionType=="sw:InstructionsConstant") {
									ExecutionCyclesConstantInstruction* MyExecutionCyclesConstantInstruction = new ExecutionCyclesConstantInstruction(strInstructionType);
									FillExecutionCyclesConstantInstruction(currentElementLev4,MyExecutionCyclesConstantInstruction);
									MyRunnable->AddInstruction(MyExecutionCyclesConstantInstruction);
								}
								else if(strInstructionType=="sw:Group") {
									AnalyseGroup(currentElementLev4,MyAmaltheaSystem,MyRunnable);
								}
								else {
									cerr<<"Not recognised instruction: " << strInstructionType << endl;
									
								}
							
	
						}

					}
				}
			}
		}
	}
}





void AmaltheaParser::FillExecutionCyclesDeviationInstruction(DOMElement* currentElementLev2, ExecutionCyclesDeviationInstruction *MyExecutionCyclesDeviationInstruction) {

	DOMNodeList* childrenLev3 = currentElementLev2->getChildNodes();
	const  XMLSize_t nodeCountLev3 = childrenLev3->getLength();
	for( XMLSize_t xxLev3 = 0; xxLev3 < nodeCountLev3; ++xxLev3 )
	{
		DOMNode* currentNodeLev3 = childrenLev3->item(xxLev3);
		if( currentNodeLev3->getNodeType() &&  // true is not NULL
			currentNodeLev3->getNodeType() == DOMNode::ELEMENT_NODE ) // is element 
		{
			DOMElement* currentElementLev3 = dynamic_cast< xercesc::DOMElement* >( currentNodeLev3 );
			if( XMLString::equals(currentElementLev3->getTagName(), TAG_deviation))
			{


				DOMNodeList* childrenLev4 = currentElementLev3->getChildNodes();
				const  XMLSize_t nodeCountLev4 = childrenLev4->getLength();
				for( XMLSize_t xxLev4 = 0; xxLev4 < nodeCountLev4; ++xxLev4 )
				{
					DOMNode* currentNodeLev4 = childrenLev4->item(xxLev4);
					if( currentNodeLev4->getNodeType() &&  // true is not NULL
						currentNodeLev4->getNodeType() == DOMNode::ELEMENT_NODE ) // is element 
					{
						DOMElement* currentElementLev4 = dynamic_cast< xercesc::DOMElement* >( currentNodeLev4 );
						if( XMLString::equals(currentElementLev4->getTagName(), TAG_upperBound))
						{
							MyExecutionCyclesDeviationInstruction->SetUpperBound(atoi(GetAttributeAsString(currentElementLev4,ATTR_value).c_str()));
						}
						else if( XMLString::equals(currentElementLev4->getTagName(), TAG_lowerBound))
						{
							MyExecutionCyclesDeviationInstruction->SetLowerBound(atoi(GetAttributeAsString(currentElementLev4,ATTR_value).c_str()));
						}
						else if( XMLString::equals(currentElementLev4->getTagName(), TAG_distribution))
						{
							MyExecutionCyclesDeviationInstruction->SetType(GetAttributeAsString(currentElementLev4,ATTR_xsi_type));

							if(MyExecutionCyclesDeviationInstruction->GetType()=="common:WeibullEstimators") {
								MyExecutionCyclesDeviationInstruction->SetRemainPromille(atof(GetAttributeAsString(currentElementLev4,ATTR_pRemainPromille).c_str()));
							}

							DOMNodeList* childrenLev5 = currentElementLev4->getChildNodes();
							const  XMLSize_t nodeCountLev5 = childrenLev5->getLength();
							for( XMLSize_t xxLev5 = 0; xxLev5 < nodeCountLev5; ++xxLev5 )
							{
								DOMNode* currentNodeLev5 = childrenLev5->item(xxLev5);
								if( currentNodeLev5->getNodeType() &&  // true is not NULL
									currentNodeLev5->getNodeType() == DOMNode::ELEMENT_NODE ) // is element 
								{
									DOMElement* currentElementLev5 = dynamic_cast< xercesc::DOMElement* >( currentNodeLev5 );
									if( XMLString::equals(currentElementLev5->getTagName(), TAG_mean))
									{
										MyExecutionCyclesDeviationInstruction->SetMean(atof(GetAttributeAsString(currentElementLev5,ATTR_value).c_str()));
									}
									else if( XMLString::equals(currentElementLev5->getTagName(), TAG_sd))
									{
										MyExecutionCyclesDeviationInstruction->SetSD(atof(GetAttributeAsString(currentElementLev5,ATTR_value).c_str()));
									}
								}
							}
						}
					}
				}
			}
		}
	}
}

void AmaltheaParser::ParseAmaltheaFileRunnable(DOMNodeList* const children , AmaltheaSystem* MyAmaltheaSystem) {
		unsigned int nodeCount = children->getLength();

		for( XMLSize_t xx = 0; xx < nodeCount; ++xx )
		{
			DOMNode* currentNode = children->item(xx);
			if( currentNode->getNodeType() &&  // true is not NULL
				currentNode->getNodeType() == DOMNode::ELEMENT_NODE ) // is element 
			{
				// Found node which is an Element. Re-cast node as element
				DOMElement* currentElement = dynamic_cast< xercesc::DOMElement* >( currentNode );


				if( XMLString::equals(currentElement->getTagName(), TAG_runnables))
				{
					Runnable *MyRunnable = new Runnable(GetAttributeAsString(currentElement,ATTR_name));
					MyRunnable->SetTags(GetAttributeAsString(currentElement,ATTR_tags));
					MyRunnable->SetID(GetAttributeAsString(currentElement,ATTR_xmi_id));



					DOMNodeList* childrenLev2 = currentElement->getChildNodes();
					const  XMLSize_t nodeCountLev2 = childrenLev2->getLength();
					for( XMLSize_t xxLev2 = 0; xxLev2 < nodeCountLev2; ++xxLev2 )
					{
						DOMNode* currentNodeLev2 = childrenLev2->item(xxLev2);
						if( currentNodeLev2->getNodeType() &&  // true is not NULL
							currentNodeLev2->getNodeType() == DOMNode::ELEMENT_NODE ) // is element 
						{
							DOMElement* currentElementLev2 = dynamic_cast< xercesc::DOMElement* >( currentNodeLev2 );
							if( XMLString::equals(currentElementLev2->getTagName(), TAG_size))
							{
								MyRunnable->SetSize(atoi(GetAttributeAsString(currentElementLev2,ATTR_numberBits).c_str()));

							}
							else if( XMLString::equals(currentElementLev2->getTagName(), TAG_runnableItems))
							{
								string strInstructionType = GetAttributeAsString(currentElementLev2,ATTR_xsi_type);

								if(strInstructionType=="sw:LabelAccess") {
									RemoteAccessInstruction* MyRemoteAccessInstruction= new RemoteAccessInstruction(strInstructionType);
									FillRemoteAccessInstruction(currentElementLev2,MyRemoteAccessInstruction,MyAmaltheaSystem,MyRunnable);
									MyRunnable->AddInstruction(MyRemoteAccessInstruction);
								}
								else if(strInstructionType=="sw:InstructionsDeviation") {
									ExecutionCyclesDeviationInstruction* MyExecutionCyclesDeviationInstruction = new ExecutionCyclesDeviationInstruction(strInstructionType);
									FillExecutionCyclesDeviationInstruction(currentElementLev2, MyExecutionCyclesDeviationInstruction);
									MyRunnable->AddInstruction(MyExecutionCyclesDeviationInstruction);

								}
								else if(strInstructionType=="sw:InstructionsConstant") {
									ExecutionCyclesConstantInstruction* MyExecutionCyclesConstantInstruction = new ExecutionCyclesConstantInstruction(strInstructionType);
									FillExecutionCyclesConstantInstruction(currentElementLev2,MyExecutionCyclesConstantInstruction);
									MyRunnable->AddInstruction(MyExecutionCyclesConstantInstruction);
								}
								else if(strInstructionType=="sw:Group") {
									AnalyseGroup(currentElementLev2,MyAmaltheaSystem,MyRunnable);
								}
								else {
									cerr<<"Not recognised instruction: " << strInstructionType << endl;
									
								}
							
	
							}

						}

					}
					if(MyRunnable->GetID()!="") {
					MyAmaltheaSystem->AddRunnable(MyRunnable,MyRunnable->GetID());
					}
					else {
					MyAmaltheaSystem->AddRunnable(MyRunnable);
					}

				}
			}
		}
}

void AmaltheaParser::ParseAmaltheaFileTasks(DOMNodeList* const children , AmaltheaSystem* MyAmaltheaSystem) {

		unsigned int nodeCount = children->getLength();

		for( XMLSize_t xx = 0; xx < nodeCount; ++xx )
		{
			DOMNode* currentNode = children->item(xx);
			if( currentNode->getNodeType() &&  // true is not NULL
				currentNode->getNodeType() == DOMNode::ELEMENT_NODE ) // is element 
			{
				// Found node which is an Element. Re-cast node as element
				DOMElement* currentElement = dynamic_cast< xercesc::DOMElement* >( currentNode );


				if( XMLString::equals(currentElement->getTagName(), TAG_tasks))
				{
					Task *MyTask = new Task(GetAttributeAsString(currentElement,ATTR_name));

					string strPriority = GetAttributeAsString(currentElement,ATTR_priority);
					if(strPriority!="") {
						MyTask->SetPriority(atoi(strPriority.c_str()));
					}

					string strMultipleTaskActivationLimit = GetAttributeAsString(currentElement,ATTR_multipleTaskActivationLimit);
					if(strMultipleTaskActivationLimit!="") {
						MyTask->SetMultipleTaskActivationLimit(atoi(strMultipleTaskActivationLimit.c_str()));
					}

					string strPreemption = GetAttributeAsString(currentElement,ATTR_preemption);
					if(strPreemption!="") {
						MyTask->SetPreemption(strPreemption);
					}

					string strStimulus = GetAttributeAsString(currentElement,ATTR_stimuli);
					if(strStimulus!="") {
								if(strStimulus.find(" ")!=string::npos) {
									strStimulus.erase(strStimulus.find(" "),strStimulus.length()-strStimulus.find(" "));
								}


						
								if(strStimulus.find("#")!=string::npos) {
									strStimulus.erase(0,strStimulus.find("#")+1);
								}

								Stimulus* MyStimulus=MyAmaltheaSystem->GetStimulus(strStimulus);
								MyStimulus->AddDestination(MyTask);
								MyTask->SetStimulus(MyAmaltheaSystem->GetStimulus(strStimulus));
					}
					


					DOMNodeList* childrenLev2 = currentElement->getChildNodes();
					const  XMLSize_t nodeCountLev2 = childrenLev2->getLength();
					for( XMLSize_t xxLev2 = 0; xxLev2 < nodeCountLev2; ++xxLev2 )
					{
						DOMNode* currentNodeLev2 = childrenLev2->item(xxLev2);
						if( currentNodeLev2->getNodeType() &&  // true is not NULL
							currentNodeLev2->getNodeType() == DOMNode::ELEMENT_NODE ) // is element 
						{
							DOMElement* currentElementLev2 = dynamic_cast< xercesc::DOMElement* >( currentNodeLev2 );
							if( XMLString::equals(currentElementLev2->getTagName(), TAG_deadline))
							{
								string strValue = GetAttributeAsString(currentElementLev2,ATTR_value);
								string strUnit = GetAttributeAsString(currentElementLev2,ATTR_unit);
								
								MyTask->SetDeadline(pair<int,string>(atoi(strValue.c_str()),strUnit));
							}
							else if( XMLString::equals(currentElementLev2->getTagName(), TAG_callGraph))
							{


									DOMNodeList* childrenLev3 = currentElementLev2->getChildNodes();
									const  XMLSize_t nodeCountLev3 = childrenLev3->getLength();
									for( XMLSize_t xxLev2 = 0; xxLev2 < nodeCountLev3; ++xxLev2 )
									{
										DOMNode* currentNodeLev3 = childrenLev3->item(xxLev2);
										if( currentNodeLev3->getNodeType() &&  // true is not NULL
											currentNodeLev3->getNodeType() == DOMNode::ELEMENT_NODE ) // is element 
										{
											DOMElement* currentElementLev3 = dynamic_cast< xercesc::DOMElement* >( currentNodeLev3 );
											if( XMLString::equals(currentElementLev3->getTagName(), TAG_graphEntries))
											{


												DOMNodeList* childrenLev4 = currentElementLev3->getChildNodes();
												const  XMLSize_t nodeCountLev4 = childrenLev4->getLength();
												for( XMLSize_t xxLev4 = 0; xxLev4 < nodeCountLev4; ++xxLev4 )
												{
													DOMNode* currentNodeLev4 = childrenLev4->item(xxLev4);
													if( currentNodeLev4->getNodeType() &&  // true is not NULL
														currentNodeLev4->getNodeType() == DOMNode::ELEMENT_NODE ) // is element 
													{
														DOMElement* currentElementLev4 = dynamic_cast< xercesc::DOMElement* >( currentNodeLev4 );
														if( XMLString::equals(currentElementLev4->getTagName(), TAG_calls))
														{

															string strType = GetAttributeAsString(currentElementLev4,ATTR_xsi_type);
															if(strType=="sw:TaskRunnableCall") {
																MyTask->AddRunnable(MyAmaltheaSystem->GetRunnableByID(GetAttributeAsString(currentElementLev4,ATTR_runnable)));
															}
															else if(strType=="sw:InterProcessActivation") {
																
																string strStimulus=GetAttributeAsString(currentElementLev4,ATTR_stimulus);
																if(strStimulus=="") { //the name can be also proveded in a child with <stimulus 

																	DOMNodeList* childrenLev5 = currentElementLev4->getChildNodes();
																	const  XMLSize_t nodeCountLev5 = childrenLev5->getLength();
																	for( XMLSize_t xxLev5 = 0; xxLev5 < nodeCountLev5; ++xxLev5 )
																	{
																		DOMNode* currentNodeLev5 = childrenLev5->item(xxLev5);
																		if( currentNodeLev5->getNodeType() &&  // true is not NULL
																			currentNodeLev5->getNodeType() == DOMNode::ELEMENT_NODE ) // is element 
																		{
																			DOMElement* currentElementLev5 = dynamic_cast< xercesc::DOMElement* >( currentNodeLev5 );
																			if( XMLString::equals(currentElementLev5->getTagName(), TAG_stimulus))
																			{
																				strStimulus=GetAttributeAsString(currentElementLev5,ATTR_href);
																				if(strStimulus.find("#")!=string::npos) {
																					strStimulus.erase(0,strStimulus.find("#")+1);
																				}

																			}
																		}
																	}
																}
																Stimulus* MyStimulus=MyAmaltheaSystem->GetStimulus(strStimulus);
																MyStimulus->AddSource(MyTask);
															}

														}
													}
												}
											}
										}
									}
							}
							else if( XMLString::equals(currentElementLev2->getTagName(), TAG_stimuli))
							{

								string strStimulus=GetAttributeAsString(currentElementLev2,ATTR_href);
								if(strStimulus.find("#")!=string::npos) {
									strStimulus.erase(0,strStimulus.find("#")+1);
								}

								Stimulus* MyStimulus=MyAmaltheaSystem->GetStimulus(strStimulus);
								MyStimulus->AddDestination(MyTask);


							}
						}

					}
					MyAmaltheaSystem->AddTask(MyTask);
				}
			}
		}


}

void AmaltheaParser::ParseAmaltheaFileLabels(DOMNodeList* const children , AmaltheaSystem* MyAmaltheaSystem) {

		unsigned int nodeCount = children->getLength();

		for( XMLSize_t xx = 0; xx < nodeCount; ++xx )
		{
			DOMNode* currentNode = children->item(xx);
			if( currentNode->getNodeType() &&  // true is not NULL
				currentNode->getNodeType() == DOMNode::ELEMENT_NODE ) // is element 
			{
				// Found node which is an Element. Re-cast node as element
				DOMElement* currentElement = dynamic_cast< xercesc::DOMElement* >( currentNode );

				if( XMLString::equals(currentElement->getTagName(), TAG_labels))
				{
					Label *MyLabel = new Label(GetAttributeAsString(currentElement,ATTR_name));
					MyLabel->SetID(GetAttributeAsString(currentElement,ATTR_xmi_id));


					DOMNodeList* childrenLev2 = currentElement->getChildNodes();
					const  XMLSize_t nodeCountLev2 = childrenLev2->getLength();
					for( XMLSize_t xxLev2 = 0; xxLev2 < nodeCountLev2; ++xxLev2 )
					{
						DOMNode* currentNodeLev2 = childrenLev2->item(xxLev2);
						if( currentNodeLev2->getNodeType() &&  // true is not NULL
							currentNodeLev2->getNodeType() == DOMNode::ELEMENT_NODE ) // is element 
						{
							DOMElement* currentElementLev2 = dynamic_cast< xercesc::DOMElement* >( currentNodeLev2 );
							if( XMLString::equals(currentElementLev2->getTagName(), TAG_size))
							{
								MyLabel->SetSize(atoi(GetAttributeAsString(currentElementLev2,ATTR_numberBits).c_str()));
							}

						}

					}
					if(MyLabel->GetID()!="") {
						MyAmaltheaSystem->AddLabel(MyLabel,MyLabel->GetID());
					}
					else {
						MyAmaltheaSystem->AddLabel(MyLabel);
					}
				}
			}
		}
}


void AmaltheaParser::ParseAmaltheaFile(string& FileName,AmaltheaSystem* MyAmaltheaSystem)
{
	clock_t start, end;
	start = clock();
 
	struct stat fileStatus;

	errno = 0;
	if(stat(FileName.c_str(), &fileStatus) == -1) // ==0 ok; ==-1 error
	{
		if( errno == ENOENT )      // errno declared by include file errno.h
			throw ( std::runtime_error("Path file_name does not exist, or path is an empty string.") );
		else if( errno == ENOTDIR )
			throw ( std::runtime_error("A component of the path is not a directory."));
		else if( errno == ELOOP )
          throw ( std::runtime_error("Too many symbolic links encountered while traversing the path."));
		else if( errno == EACCES )
          throw ( std::runtime_error("Permission denied."));
		else if( errno == ENAMETOOLONG )
          throw ( std::runtime_error("File can not be read\n"));
	}

   // Configure DOM parser.

	m_Parser->setValidationScheme( XercesDOMParser::Val_Never );
	m_Parser->setDoNamespaces( false );
	m_Parser->setDoSchema( false );
	m_Parser->setLoadExternalDTD( false );

	try
	{
		m_Parser->parse( FileName.c_str() );

		// no need to free this pointer - owned by the parent parser object
		DOMDocument* xmlDoc = m_Parser->getDocument();

		// Get the top-level element: Name is "root". No attributes for "root"
      
		DOMElement* elementRoot = xmlDoc->getDocumentElement();
		if( !elementRoot ) throw(std::runtime_error( "empty XML document" ));

		ParseAmaltheaFileHWModel(GetElementWithTaghwModel(elementRoot), MyAmaltheaSystem);
		ParseAmaltheaFileStimuli(GetElementWithTagStimuliModel(elementRoot), MyAmaltheaSystem);
		ParseAmaltheaFileLabels(GetElementWithTagswModel(elementRoot), MyAmaltheaSystem);
		ParseAmaltheaFileRunnable(GetElementWithTagswModel(elementRoot), MyAmaltheaSystem);
		ParseAmaltheaFileTasks(GetElementWithTagswModel(elementRoot),MyAmaltheaSystem);

		end = clock();
//    cout << "Time of Parse2: "
//    << (double)(end-start)/CLOCKS_PER_SEC
//    << " seconds." << "\n\n";


	}
	catch( xercesc::XMLException& e )
	{
		char* message = xercesc::XMLString::transcode( e.getMessage() );
		ostringstream errBuf;
		errBuf << "Error parsing file: " << message << flush;
		XMLString::release( &message );
	}
}

