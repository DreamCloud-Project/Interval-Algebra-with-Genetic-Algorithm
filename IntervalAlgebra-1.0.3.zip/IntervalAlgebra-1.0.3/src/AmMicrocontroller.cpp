#include "AmMicrocontroller.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

namespace IntervalAlgebra
{
		MicroController::MicroController(string NameIn): Name(NameIn), Size(0) {
		}

		void MicroController::SetName(string NameIn) {
			Name=NameIn;
		}

		string MicroController::GetName() {
			return Name;
		}

		void MicroController::SetSize(int SizeIn) {
			Size=SizeIn;
		}

		int MicroController::GetSize() {
			return Size;
		}

		void MicroController::SetID(string IDIn) {
			ID=IDIn;
		}

		string MicroController::GetID() {
			return ID;
		}


}
