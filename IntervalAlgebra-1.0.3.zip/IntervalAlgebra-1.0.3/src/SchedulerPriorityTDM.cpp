#include "SchedulerPriorityTDM.h"
#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

namespace IntervalAlgebra
{

	SchedulerPriorityTDM::SchedulerPriorityTDM(Time *QuantumIn) : Scheduler() {
		Quantum=QuantumIn;
		ResetDeadlineCounters();
	}


	Time* SchedulerPriorityTDM::GetQuantum() {
		return Quantum;
	}



	

	void SchedulerPriorityTDM::Schedule() {
		Job *j;
		string OriginalIDOfthePreviousJobID="";

		Time *TimeTmp;
		IAResource *DefaultCore = NULL;
		if(AllCores.empty()) {
			DefaultCore = new IAResource("Default");
			AllCores.push_back(DefaultCore);
			list<Job*>::iterator itJob;
			for(itJob=AllJobs.begin();itJob!=AllJobs.end();++itJob) {
				Time* ExecutionTime=(*itJob)->GetExecutionTimeForExecutingResource();
				(*itJob)->AddExecutingCore(DefaultCore);
				(*itJob)->SetExecutionTimeForResource(ExecutionTime,DefaultCore);
				delete ExecutionTime;
			}
		}

		CurrentTime.reserve(AllCores.size());
		for(unsigned int iCore=0;iCore<AllCores.size();iCore++) {
			CurrentTime.push_back(NULL);
		}

		//start task
		j=jt1->FindTheEarliestReadyJob(NULL,0);
			if(j==NULL) {
				cout << "Error. No start job!"<< endl;
				exit(-1);
			}
		Time *t=jt1->DetermineStartTime(j);
		j->SetStartAndEndTime(t);
		j->SetScheduled(true);
		int Index=1;



		for(unsigned int i=1;i<AllJobs.size()-1;) {
			int JobsAllocatedInPreviousStep=i;
			for(unsigned int iCore=0;iCore<AllCores.size();iCore++) {

				j = jt1->FindTheEarliestReadyJobOfTheHighestPriorityForCore(CurrentTime.at(iCore),NULL,GetCore(iCore),Index++);
				if(j==NULL) {
					j=jt1->FindTheEarliestReadyJobForCore(GetCore(iCore),NULL,Index++); 
				}
				if(j==NULL) {
					continue;
				}
				i++;

				Time *MyTime=j->GetExecutionTime(j->GetTheFirstExecutingCore());
				if(*MyTime > *Quantum) {
					Time *t=jt1->DetermineStartTime(j)->Clone();
					Job *PrefixJob;	
					PrefixJob=j->ExtractPrefix(Quantum,j->GetTheFirstExecutingCore());
					j->RemovePrefix(Quantum,j->GetTheFirstExecutingCore());
					string str=string(to_string(PrefixJob->GetNoOfSlice()));
					PrefixJob->SetName(PrefixJob->GetName()+"__$"+str);
					j->SetNoOfSlice(PrefixJob->GetNoOfSlice()+1);
					PrefixJob->SetStartAndEndTime(t);
					PrefixJob->SetPModeOfExecutingResources();			
					PrefixJob->SetScheduled(true);
					CurrentTime[iCore] = PrefixJob->GetEndTime();
					AllJobs.push_front(PrefixJob);
					jt1->AddNodeAsAParentTo(PrefixJob,j,Index++); 
					OriginalIDOfthePreviousJobID=j->GetOriginalName();
					delete t;

					list<IAResource*>::iterator it;
					Time* EndTime=PrefixJob->GetEndTime();
					for(it=PrefixJob->GetExecutingCores()->begin();it!=PrefixJob->GetExecutingCores()->end();++it) {
						delete mapCoreTime[*it];
						mapCoreTime[*it]=EndTime->Clone();
					}
				}
				else {
					Time *t=jt1->DetermineStartTime(j);
					j->SetStartAndEndTime(t);
					j->SetPModeOfExecutingResources();			
					j->SetScheduled(true);
					CurrentTime[iCore] = j->GetEndTime();

					if(*CurrentTime[iCore]<=*j->GetDeadline()) {
						IncreaseBeforeDeadlineCounter();
					}
					else {
						IncreaseAfterDeadlineCounter();
					}


					OriginalIDOfthePreviousJobID=j->GetOriginalName();

					list<IAResource*>::iterator it;
					Time* EndTime=j->GetEndTime();
					for(it=j->GetExecutingCores()->begin();it!=j->GetExecutingCores()->end();++it) {
						delete mapCoreTime[*it];
						mapCoreTime[*it]=EndTime->Clone();
					}

				}
				delete MyTime;
			}

			if (i==JobsAllocatedInPreviousStep) { //no jobs for the current time, we should look for the next time event
				j=jt1->FindTheEarliestReadyJob(NULL,Index++);
				if(j==NULL) {
					cout << "Error. Job not found!"<< endl;
					exit(-1);
				}
				Time *PossibleStartTime=jt1->DetermineStartTime(j);
				for(unsigned int iCore=0;iCore<AllCores.size();iCore++) {
					if(*CurrentTime[iCore]<*PossibleStartTime) {
						delete CurrentTime[iCore];
						Time *NewTime=  PossibleStartTime->Clone();
						CurrentTime[iCore] = NewTime;
					}
				}
			}


		}


//end job
		j=jt1->FindTheEarliestReadyJob(NULL,0);
			if(j==NULL) {
				cout << "Error. No end job!"<< endl;
				exit(-1);
			}
		t=jt1->DetermineStartTime(j);
		j->SetStartAndEndTime(t);
		j->SetScheduled(true);

		if(DefaultCore!=NULL) {
			list<Job*>::iterator itJob;
			for(itJob=AllJobs.begin();itJob!=AllJobs.end();++itJob) {
				(*itJob)->RemoveExecutingCores(DefaultCore);
			}
			delete DefaultCore;
		}


	}
}
