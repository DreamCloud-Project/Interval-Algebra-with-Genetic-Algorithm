#include <iostream>
#include <string>
#include <algorithm>
#include <numeric>
#include "AmTypes.h"

#include "AmAmaltheaSystem.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

namespace IntervalAlgebra
{
	AmaltheaSystem* AmaltheaSystem::pInstance=0;

	AmaltheaSystem* AmaltheaSystem::instance() {
		if(pInstance==0) {
			pInstance=new AmaltheaSystem;
		}
		return pInstance;
	}


		AmaltheaSystem::AmaltheaSystem() {
		}

		AmaltheaSystem::~AmaltheaSystem() {

			vector<Label*>::iterator itLabels;
			for(itLabels=Labels.begin();itLabels!=Labels.end();++itLabels) {
				delete *itLabels;
			}
			
			vector<Runnable*>::iterator itRunnables;
			for(itRunnables=Runnables.begin();itRunnables!=Runnables.end();++itRunnables) {
				delete *itRunnables;
			}

			vector<Stimulus*>::iterator itStimuli;
			for(itStimuli=Stimuli.begin();itStimuli!=Stimuli.end();++itStimuli) {
				delete *itStimuli;
			}

		   vector<Task*>::iterator itTasks;
			for(itTasks=Tasks.begin();itTasks!=Tasks.end();++itTasks) {
				delete *itTasks;
			}

		   vector<AmCore*>::iterator itCores;
			for(itCores=Cores.begin();itCores!=Cores.end();++itCores) {
				delete *itCores;
			}

			map<string,CoreType*>::iterator itCoreTypesMap;
			for(itCoreTypesMap=CoreTypesMap.begin();itCoreTypesMap!=CoreTypesMap.end();++itCoreTypesMap) {
				delete (*itCoreTypesMap).second;
			}

			map<string,Quartz*>::iterator itQuartzesMap;
			for(itQuartzesMap=QuartzsMap.begin();itQuartzesMap!=QuartzsMap.end();++itQuartzesMap) {
				delete (*itQuartzesMap).second;
			}



		}

		void AmaltheaSystem::AddLabel(Label* LabelIn){
			Labels.push_back(LabelIn);
		}

		void AmaltheaSystem::AddLabel(Label* LabelIn, string IDIn){
			Labels.push_back(LabelIn);
			LabelsMap[IDIn]=LabelIn;
			LabelsNameMap[LabelIn->GetName()]=LabelIn;
		}

		Label* AmaltheaSystem::GetLabel(int Index) {
			return Labels.at(Index);
		}

		int AmaltheaSystem::GetNoOfLabels() {
			return Labels.size();
		}

		void AmaltheaSystem::AddRunnable(Runnable* RunnableIn){
			Runnables.push_back(RunnableIn);
		}

		void AmaltheaSystem::AddRunnable(Runnable* RunnableIn,string IDIn){
			Runnables.push_back(RunnableIn);
			RunnablesByIDMap[IDIn]=RunnableIn;
			RunnablesByNameMap[RunnableIn->GetName()]=RunnableIn;
		}


		Runnable* AmaltheaSystem::GetRunnable(int Index) {
			return Runnables.at(Index);
		}

		int AmaltheaSystem::GetNoOfRunnables() {
			return Runnables.size();
		}

		void AmaltheaSystem::AddTask(Task* TaskIn){
			Tasks.push_back(TaskIn);
		}

		Task* AmaltheaSystem::GetTask(int Index) {
			return Tasks.at(Index);
		}

		int AmaltheaSystem::GetNoOfTasks() {
			return Tasks.size();
		}


		void AmaltheaSystem::PrintAllLabels() {
			vector<Label*>::iterator it;
			int i;
			for(i=0,it=Labels.begin(); it!=Labels.end() ; ++it,i++) {
				cout << i << " Name: " << (*it)->GetName() << " Size: " << (*it)->GetSize() << endl;
			}
		}

		void AmaltheaSystem::PrintAllTasks() {
			vector<Task*>::iterator it;
			int i;
			for(i=0,it=Tasks.begin(); it!=Tasks.end() ; ++it,i++) {
				cout << " Task no: " << i << endl;
				(*it)->Print();
			}
		}

		Runnable* AmaltheaSystem::GetRunnableByID(string IDIn) {
			return RunnablesByIDMap.at(IDIn);
		}

		Runnable* AmaltheaSystem::GetRunnableByName(string Name) {
			return RunnablesByNameMap.at(Name);
		}


		Label* AmaltheaSystem::GetLabel(string IDIn) {
			return LabelsMap.at(IDIn);
		}

		Label* AmaltheaSystem::GetLabelByName(string NameIn) {
			return LabelsNameMap.at(NameIn);
		}


		int AmaltheaSystem::GetIndexOfLabel(Label* LabelIn) {
			return find(Labels.begin(),Labels.end(),LabelIn)-Labels.begin();
			 
		}

		int AmaltheaSystem::GetIndexOfRunnable(Runnable* RunnableIn) {
			return find(Runnables.begin(),Runnables.end(),RunnableIn)-Runnables.begin();
		}


		void AmaltheaSystem::AddStimulus(Stimulus* StimulusIn){
			Stimuli.push_back(StimulusIn);
		}

		void AmaltheaSystem::AddStimulus(Stimulus* StimulusIn,string IDIn){
			Stimuli.push_back(StimulusIn);
			StimuliMap[IDIn]=StimulusIn;
		}

		Stimulus* AmaltheaSystem::GetStimulus(int Index) {
			return Stimuli.at(Index);
		}


		Stimulus* AmaltheaSystem::GetStimulus(string IDIn) {
			return StimuliMap.at(IDIn);
		}

		int AmaltheaSystem::GetNoOfStimuli() {
			return Stimuli.size();
		}

		void AmaltheaSystem::AddCoreType(CoreType* CoreTypeIn, string IDIn) {
			CoreTypesMap[IDIn]=CoreTypeIn;
		}

		CoreType* AmaltheaSystem::GetCoreType(string IDIn) {
			return CoreTypesMap.at(IDIn);
		}


		void AmaltheaSystem::AddQuartz(Quartz* QuartzIn, string IDIn) {
			QuartzsMap[IDIn]=QuartzIn;
		}

		Quartz* AmaltheaSystem::GetQuartz(string IDIn) {
			return QuartzsMap.at(IDIn);
		}

		void AmaltheaSystem::AddAmCore(AmCore* CoreIn, string IDIn) {
			CoresMap[IDIn]=CoreIn;
			Cores.push_back(CoreIn);
		}

		AmCore* AmaltheaSystem::GetAmCore(string IDIn) {
			return CoresMap.at(IDIn);
		}

		AmCore* AmaltheaSystem::GetAmCore(int Index) {
			return Cores[Index];
		}

		int AmaltheaSystem::GetNoOfAmCores() {
			return Cores.size();
		}


	void AmaltheaSystem::AddJobToStimuliSourcesIfNecessary(Task* TaskIn,Job* JobIn) {
		for(int i=0;i<GetNoOfStimuli();i++) {
			if(GetStimulus(i)->IsTaskInSources(TaskIn)) {
				GetStimulus(i)->AddSourceJob(JobIn);
			}
		}
	}

	void AmaltheaSystem::AddJobToStimuliDestinationsIfNecessary(Task* TaskIn,Job* JobIn) {
		for(int i=0;i<GetNoOfStimuli();i++) {
			if(GetStimulus(i)->IsTaskInDestinations(TaskIn)) {
				GetStimulus(i)->AddDestinationJob(JobIn);
			}
		}
	}



		void AmaltheaSystem::AddTaskDependencesFromStimuli() {
			int nHowMany=0;
			for(int i=0;i<GetNoOfStimuli();i++) {
				if(GetStimulus(i)->GetNoOfSourcesJob()>0 && GetStimulus(i)->GetNoOfDestinationsJob()>0) {
					for(int j=0;j<GetStimulus(i)->GetNoOfDestinationsJob();j++) {
						for(int k=0;k<GetStimulus(i)->GetNoOfSourcesJob();k++) {
							GetStimulus(i)->GetDestinationJob(j)->AddDependency(GetStimulus(i)->GetSourceJob(k));
						}

					}
				}

			}
		}


		void AmaltheaSystem::ClearJobs() {

			for(int i=0;i<GetNoOfStimuli();i++) {
					GetStimulus(i)->ClearSourceJobs();
					GetStimulus(i)->ClearDestinationJobs();
			}

		}


		Label* AmaltheaSystem::GetLabelWithIndex(int Index) {
			return Labels[Index];
		}

		void AmaltheaSystem::AddLabelsDest(Label* MyLabel, Runnable *MyRunnable) {
			LabelsDest[MyLabel]=MyRunnable;
		}

		void AmaltheaSystem::AddLabelsSource(Label* MyLabel, Runnable *MyRunnable) {
			LabelsSource[MyLabel]=MyRunnable;
		}

		Runnable* AmaltheaSystem::GetLabelsDest(Label* MyLabel) {
			if(LabelsDest.find(MyLabel)==LabelsDest.end()) {
				return NULL;
			}
			return LabelsDest.at(MyLabel);
		}


		Runnable* AmaltheaSystem::GetLabelsSource(Label* MyLabel) {
			if(LabelsSource.find(MyLabel)==LabelsSource.end()) {
				return NULL;
			}
			return LabelsSource.at(MyLabel);
		}


		string AmaltheaSystem::GetLowerAmUnit(string Unit1,string Unit2) {

			string result;

			if(Unit1 == "ns" || Unit2=="ns") {
				result="ns";
			}
			else if(Unit1 == "us" || Unit2=="us") {
				result="us";
			}
			else if(Unit1 == "ms" || Unit2=="ms") {
				result="ms";
			}
			else if(Unit1 == "s" || Unit2=="s") {
				result="s";
			}

			return result;
		}


		string AmaltheaSystem::GetLowestUnitAmTime(vector<pair<int,string> >* AmTimeIn) {
			vector<pair<int,string> >::const_iterator it;
			string MinUnit;
			for(it=AmTimeIn->begin();it!=AmTimeIn->end();++it) {
				MinUnit=GetLowerAmUnit((*it).second,MinUnit);
			}
			return MinUnit;
		}

		void AmaltheaSystem::ConvertAmTimeToUnit(pair<int,string> *AmTimeIn,string DestUnit) {
			if(AmTimeIn->second==DestUnit) {
				return;
			}
			if(DestUnit!="ns" && DestUnit!="us" && DestUnit!="ms" && DestUnit!="s") {
				return;
			}

			if(DestUnit=="ns") {
				if(AmTimeIn->second=="us") {
					AmTimeIn->first*=1000;
					AmTimeIn->second=DestUnit;
				}
				else if(AmTimeIn->second=="ms") {
					AmTimeIn->first*=1000*1000;
					AmTimeIn->second=DestUnit;
				}
				else if(AmTimeIn->second=="s") {
					AmTimeIn->first*=1000*1000*1000;
					AmTimeIn->second=DestUnit;
				}
			}
			else if(DestUnit=="us") {
				if(AmTimeIn->second=="ns") {
					AmTimeIn->first/=1000;
					AmTimeIn->second=DestUnit;
				}
				else if(AmTimeIn->second=="ms") {
					AmTimeIn->first*=1000;
					AmTimeIn->second=DestUnit;
				}
				else if(AmTimeIn->second=="s") {
					AmTimeIn->first*=1000*1000;
					AmTimeIn->second=DestUnit;
				}
			}
			else if(DestUnit=="ms") {
				if(AmTimeIn->second=="ns") {
					AmTimeIn->first/=1000*1000;
					AmTimeIn->second=DestUnit;
				}
				else if(AmTimeIn->second=="us") {
					AmTimeIn->first/=1000;
					AmTimeIn->second=DestUnit;
				}
				else if(AmTimeIn->second=="s") {
					AmTimeIn->first*=1000;
					AmTimeIn->second=DestUnit;
				}
			}
			else if(DestUnit=="s") {
				if(AmTimeIn->second=="ns") {
					AmTimeIn->first/=1000*1000*1000;
					AmTimeIn->second=DestUnit;
				}
				else if(AmTimeIn->second=="us") {
					AmTimeIn->first/=1000*1000;
					AmTimeIn->second=DestUnit;
				}
				else if(AmTimeIn->second=="ms") {
					AmTimeIn->first/=1000;
					AmTimeIn->second=DestUnit;
				}
			}



		}



		void AmaltheaSystem::ConvertAmTimeVectorToUnit(vector<pair<int,string> >* AmTimeVector,string Unit) {
			vector<pair<int,string> >::iterator it;
			for(it=AmTimeVector->begin();it!=AmTimeVector->end();++it) {
				if((*it).second!=Unit) {
					ConvertAmTimeToUnit(&(*it),Unit);
				}
			}
		}


		int AmaltheaSystem::ComputeGreatestDommonDivisor(int a, int b) {
			int c;
			while(b != 0) {
				c = a % b;
				a = b;
				b = c;
			}
			return a; 
		}

		int AmaltheaSystem::ComputeLeastCommonMultiple(int a, int b) {
			int result = ComputeGreatestDommonDivisor(a, b);
			return result ? (a / result * b) : 0;
		}

		int AmaltheaSystem::GetFirstElement( const std::pair<int, string> &p ) {
			return p.first;
		}

		pair<int,string> AmaltheaSystem::GetHyperPeriod() {
			int NoOfTasks=GetNoOfTasks();
			vector<pair<int,string> > PeriodVector;
			PeriodVector.reserve(NoOfTasks);
			vector<Task*>::iterator itTask;
			for(itTask=Tasks.begin();itTask!=Tasks.end();++itTask) {
				if((*itTask)->GetPeriod()!=AmNoTime) {
					PeriodVector.push_back((*itTask)->GetPeriod());
				}
			}

			string LowestUnit=GetLowestUnitAmTime(&PeriodVector);
			ConvertAmTimeVectorToUnit(&PeriodVector,LowestUnit);
			vector<int> PeriodValueVector;

			std::transform(PeriodVector.begin(),PeriodVector.end(),std::back_inserter(PeriodValueVector),GetFirstElement );

			int Hyperperiod = std::accumulate(PeriodValueVector.begin(), PeriodValueVector.end(), 1,  ComputeLeastCommonMultiple);

			return pair<int,string>(Hyperperiod,LowestUnit);
		}



} 
