#include "TimeDeterministic.h"
#include "TimeStochastic.h"
#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

namespace IntervalAlgebra
{

TimeUnit Time::GetLowerUnit(Time* TimeIn) {
	TimeUnit result;
	if(TimeIn->GetUnit() < GetUnit()) {
		 result=TimeIn->GetUnit();
	}
	else {
		result=GetUnit();
	}
	return result;
}



TimeDeterministic* AddDeterministic (TimeDeterministic &t1,TimeDeterministic &t2) {
			TimeDeterministic *result=NULL;
			if(t1.GetUnit()!=t2.GetUnit()) {
				TimeUnit LowerTimeUnit;
				LowerTimeUnit=t1.GetLowerUnit(&t2);

				if(t1.GetUnit()!=LowerTimeUnit) {
					Time *t3;
					t3=new TimeDeterministic(t1.GetValue(),t1.GetUnit());
					t3->ConvertTo(LowerTimeUnit);
					result=new TimeDeterministic(t3->GetValue() + t2.GetValue(),LowerTimeUnit);
					delete t3;
					return result;
				}
				else {
					Time *t3;
					t3=new TimeDeterministic(t2.GetValue(),t2.GetUnit());
					t3->ConvertTo(LowerTimeUnit);
					result=new TimeDeterministic(t1.GetValue()+t3->GetValue(),LowerTimeUnit);
					delete t3;
					return result;
				}
			}
			else {
				result=new TimeDeterministic(t1.GetValue() + t2.GetValue(),t1.GetUnit());
				return result;
			}
		}


TimeDeterministic* SubDeterministic (TimeDeterministic &t1,TimeDeterministic &t2) {
			TimeDeterministic *result=NULL;
			if(t1.GetUnit()!=t2.GetUnit()) {
				TimeUnit LowerTimeUnit;
				LowerTimeUnit=t1.GetLowerUnit(&t2);

				if(t1.GetUnit()!=LowerTimeUnit) {
					Time *t3;
					t3=new TimeDeterministic(t1.GetValue(),t1.GetUnit());
					t3->ConvertTo(LowerTimeUnit);
					result=new TimeDeterministic(t3->GetValue() - t2.GetValue(),LowerTimeUnit);
					delete t3;
					return result;
				}
				else {
					Time *t3;
					t3=new TimeDeterministic(t2.GetValue(),t2.GetUnit());
					t3->ConvertTo(LowerTimeUnit);
					result=new TimeDeterministic(t1.GetValue()-t3->GetValue(),LowerTimeUnit);
					delete t3;
					return result;
				}
			}
			else {
				result=new TimeDeterministic(t1.GetValue() - t2.GetValue(),t1.GetUnit());
				return result;
			}
		}

TimeStochastic* SubStochastic (TimeStochastic &t1,TimeStochastic &t2) {
			cerr << "Subtraction of stochastic time not implemented." << endl;
			exit(1);
}


TimeStochastic* AddStochastic (TimeStochastic &t1,TimeStochastic &t2) {
			if(t1.GetUnit()!=t2.GetUnit()) {
				cerr << "Unit conversion of time with aleatory variables is unimplemented." << endl;
				exit(1);
			}

			TimeStochastic *result=NULL;
			result=new TimeStochastic(t1.GetUnit());
			result->Convolute(&t1,&t2);
				
			return result;
		}


TimeStochastic* Shift(TimeStochastic &t1,TimeDeterministic &t2) {
			TimeStochastic *result=NULL;
			if(t1.GetUnit()!=t2.GetUnit()) {
					TimeDeterministic *t3;
					t3=new TimeDeterministic(t2.GetValue(),t2.GetUnit());
					t3->ConvertTo(t1.GetUnit());
					result=new TimeStochastic(t1.GetUnit());
					result->AddConstantTime(&t1,t3);
					delete t3;
					return result;
			}


			result=new TimeStochastic(t1.GetUnit());
			result->AddConstantTime(&t1,&t2);
			return result;
		}


TimeStochastic* ShiftLeft(TimeStochastic &t1,TimeDeterministic &t2) {
			TimeStochastic *result=NULL;
			if(t1.GetUnit()!=t2.GetUnit()) {
					TimeDeterministic *t3;
					t3=new TimeDeterministic(t2.GetValue(),t2.GetUnit());
					t3->ConvertTo(t1.GetUnit());
					result=new TimeStochastic(t1.GetUnit());
					result->SubConstantTime(&t1,t3);
					delete t3;
					return result;
			}
			result=new TimeStochastic(t1.GetUnit());
			result->SubConstantTime(&t1,&t2);
			return result;
		}

		Time* Add (Time &t1,Time &t2) {
			if(!t1.IsStochastic() && ! t2.IsStochastic()) {
				TimeDeterministic *result=NULL;
				result=AddDeterministic(dynamic_cast<TimeDeterministic&>(t1),dynamic_cast<TimeDeterministic&>(t2));
				return result;
			}
			else if(t1.IsStochastic() && t2.IsStochastic()) {
				TimeStochastic *result=NULL;
				result=AddStochastic(dynamic_cast<TimeStochastic&>(t1),dynamic_cast<TimeStochastic&>(t2));
				return result;
			}
			else if(t1.IsStochastic() && !t2.IsStochastic()) {
				TimeStochastic *result=NULL;
				result=Shift(dynamic_cast<TimeStochastic&>(t1),dynamic_cast<TimeDeterministic&>(t2));
				return result;

			}
			else if(!t1.IsStochastic() && t2.IsStochastic()) {
				TimeStochastic *result=NULL;
				result=Shift(dynamic_cast<TimeStochastic&>(t2),dynamic_cast<TimeDeterministic&>(t1));
				return result;

			}
			else {
				TimeDeterministic *result=NULL;
				return result;
			}
		}

		Time* Sub (Time &t1,Time &t2) {
			if(!t1.IsStochastic() && ! t2.IsStochastic()) {
				TimeDeterministic *result=NULL;
				result=SubDeterministic(dynamic_cast<TimeDeterministic&>(t1),dynamic_cast<TimeDeterministic&>(t2));
				return result;
			}
			else if(t1.IsStochastic() && t2.IsStochastic()) {
				TimeStochastic *result=NULL;
				result=SubStochastic(dynamic_cast<TimeStochastic&>(t1),dynamic_cast<TimeStochastic&>(t2));
				return result;
			}
			else if(t1.IsStochastic() && !t2.IsStochastic()) {
				TimeStochastic *result=NULL;
				result=ShiftLeft(dynamic_cast<TimeStochastic&>(t1),dynamic_cast<TimeDeterministic&>(t2));
				return result;

			}
			else if(!t1.IsStochastic() && t2.IsStochastic()) {
				TimeStochastic *result=NULL;
				result=ShiftLeft(dynamic_cast<TimeStochastic&>(t2),dynamic_cast<TimeDeterministic&>(t1));
				return result;

			}
			else {
				TimeDeterministic *result=NULL;
				return result;
			}
		}

	 long long Time::ComputeValueToUnit(long long ValueSrc,TimeUnit UnitSrc,TimeUnit UnitDst) {
			TimeUnit MyUnit=UnitSrc;
			long long MyValue=ValueSrc;

			while(MyUnit<UnitDst) {
			MyUnit = static_cast<TimeUnit>( static_cast<int>(MyUnit) + 1 );
			MyValue/=1000;
		}
		while(MyUnit>UnitDst) {
			MyUnit = static_cast<TimeUnit>( static_cast<int>(MyUnit) - 1 );
			MyValue*=1000;
		}
		return MyValue;

	}

string Time::GetUnitAsString() {
	if(Unit==fs) {
		return "fs";
	}
	else if(Unit==ps) {
		return "ps";
	}
	else if(Unit==ns) {
		return "ns";
	}
	else if(Unit==us) {
		return "us";
	}
	else if(Unit==ms) {
		return "ms";
	}
	else  {
		return "s";
	}
}


}
