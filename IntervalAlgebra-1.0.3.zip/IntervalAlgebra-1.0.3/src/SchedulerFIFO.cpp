#include "SchedulerFIFO.h"
#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

namespace IntervalAlgebra
{

	SchedulerFIFO::SchedulerFIFO(): Scheduler() {
		ResetDeadlineCounters();
	}




	

	void SchedulerFIFO::Schedule() {
		Job *j;

		Time *CurrentTime;
		CurrentTime=NULL;

		clock_t start, end;
		start = clock();

		for(unsigned int i=0;i<AllJobs.size();i++) {
			j=jt1->FindTheEarliestReadyJob(NULL,i);
			if(j==NULL) {
				cout << "Error. No more ready jobs. Tasks allocated so far: " << i << "/" << AllJobs.size() << endl;
				exit(-1);
			}

			if(GetAllocateTasksUsingPModes() && i<=GetNumberofTaskPModesVectorElements()) {
				list<IAResource*>::iterator itResource;
				for(itResource=j->GetExecutingCores()->begin();itResource!=j->GetExecutingCores()->end() ; ++itResource) {
					(*itResource)->SetCurrentPMode(GetElementFromTaskPModesVectorElements(i));
				}
			}

			Time *t=jt1->DetermineStartTime(j);
			j->SetStartAndEndTime(t);
			j->SetPModeOfExecutingResources();			
			j->SetScheduled(true);

			CurrentTime=j->GetEndTime();
			if(j->GetName()!="End"&&*CurrentTime<=*j->GetDeadline()) {
				IncreaseBeforeDeadlineCounter();
			}
			else if(j->GetName()!="End") {
				IncreaseAfterDeadlineCounter();
			}


			TreeNode* MyRootTreeNode = jt1->GetRootTreeNode();




			list<IAResource*>::iterator it;
			Time* EndTime=j->GetEndTime();
			if(j->GetExecutingCores()->empty()) {
					delete mapCoreTime[NULL];
					mapCoreTime[NULL]=EndTime->Clone();
			}
			else {
				for(it=j->GetExecutingCores()->begin();it!=j->GetExecutingCores()->end();++it) {
					delete mapCoreTime[*it];
					mapCoreTime[*it]=EndTime->Clone();
				}
			}

		}
	}











}
